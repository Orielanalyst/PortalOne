// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
export class APIResource {
    constructor(client) {
        Object.defineProperty(this, "_client", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map