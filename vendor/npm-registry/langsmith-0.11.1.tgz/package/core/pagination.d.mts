import { FinalRequestOptions } from "../internal/request-options.mjs";
import { type Langsmith } from "../client.mjs";
import { APIPromise } from "./api-promise.mjs";
import { type APIResponseProps } from "../internal/parse.mjs";
export type PageRequestOptions = Pick<FinalRequestOptions, 'query' | 'headers' | 'body' | 'path' | 'method'>;
export declare abstract class AbstractPage<Item> implements AsyncIterable<Item> {
    #private;
    protected options: FinalRequestOptions;
    protected response: Response;
    protected body: unknown;
    constructor(client: Langsmith, response: Response, body: unknown, options: FinalRequestOptions);
    abstract nextPageRequestOptions(): PageRequestOptions | null;
    abstract getPaginatedItems(): Item[];
    hasNextPage(): boolean;
    getNextPage(): Promise<this>;
    iterPages(): AsyncGenerator<this>;
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
export declare class PagePromise<PageClass extends AbstractPage<Item>, Item = ReturnType<PageClass['getPaginatedItems']>[number]> extends APIPromise<PageClass> implements AsyncIterable<Item> {
    constructor(client: Langsmith, request: Promise<APIResponseProps>, Page: new (...args: ConstructorParameters<typeof AbstractPage>) => PageClass);
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
export type OffsetPaginationTopLevelArrayResponse<Item> = Item[];
export interface OffsetPaginationTopLevelArrayParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationTopLevelArray<Item> extends AbstractPage<Item> {
    items: Array<Item>;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationTopLevelArrayResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export type OffsetPaginationIssuesResponse<Item> = Item[];
export interface OffsetPaginationIssuesParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationIssues<Item> extends AbstractPage<Item> {
    items: Array<Item>;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationIssuesResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface OffsetPaginationReposResponse<Item> {
    repos: Array<Item>;
    total: number;
}
export interface OffsetPaginationReposParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationRepos<Item> extends AbstractPage<Item> implements OffsetPaginationReposResponse<Item> {
    repos: Array<Item>;
    total: number;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationReposResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface OffsetPaginationCommitsResponse<Item> {
    commits: Array<Item>;
    total: number;
}
export interface OffsetPaginationCommitsParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationCommits<Item> extends AbstractPage<Item> implements OffsetPaginationCommitsResponse<Item> {
    commits: Array<Item>;
    total: number;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationCommitsResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface OffsetPaginationOnlineEvaluatorsResponse<Item> {
    evaluators: Array<Item>;
    total: number;
}
export interface OffsetPaginationOnlineEvaluatorsParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationOnlineEvaluators<Item> extends AbstractPage<Item> implements OffsetPaginationOnlineEvaluatorsResponse<Item> {
    evaluators: Array<Item>;
    total: number;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationOnlineEvaluatorsResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface OffsetPaginationInsightsClusteringJobsResponse<Item> {
    clustering_jobs: Array<Item>;
}
export interface OffsetPaginationInsightsClusteringJobsParams {
    offset?: number;
    limit?: number;
}
export declare class OffsetPaginationInsightsClusteringJobs<Item> extends AbstractPage<Item> implements OffsetPaginationInsightsClusteringJobsResponse<Item> {
    clustering_jobs: Array<Item>;
    constructor(client: Langsmith, response: Response, body: OffsetPaginationInsightsClusteringJobsResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface CursorPaginationResponse<Item> {
    runs: Array<Item>;
    cursors: CursorPaginationResponse.Cursors;
}
export declare namespace CursorPaginationResponse {
    interface Cursors {
        next?: string;
    }
}
export interface CursorPaginationParams {
    cursor?: string;
    limit?: number;
}
export declare class CursorPagination<Item> extends AbstractPage<Item> implements CursorPaginationResponse<Item> {
    runs: Array<Item>;
    cursors: CursorPaginationResponse.Cursors;
    constructor(client: Langsmith, response: Response, body: CursorPaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface ItemsCursorPostPaginationResponse<Item> {
    items: Array<Item>;
    next_cursor: string;
}
export interface ItemsCursorPostPaginationParams {
    cursor?: string;
    page_size?: number;
}
export declare class ItemsCursorPostPagination<Item> extends AbstractPage<Item> implements ItemsCursorPostPaginationResponse<Item> {
    items: Array<Item>;
    next_cursor: string;
    constructor(client: Langsmith, response: Response, body: ItemsCursorPostPaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface ItemsCursorGetPaginationResponse<Item> {
    items: Array<Item>;
    next_cursor: string;
}
export interface ItemsCursorGetPaginationParams {
    cursor?: string;
    page_size?: number;
}
export declare class ItemsCursorGetPagination<Item> extends AbstractPage<Item> implements ItemsCursorGetPaginationResponse<Item> {
    items: Array<Item>;
    next_cursor: string;
    constructor(client: Langsmith, response: Response, body: ItemsCursorGetPaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
//# sourceMappingURL=pagination.d.mts.map