"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
var _AbstractPage_client;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ItemsCursorGetPagination = exports.ItemsCursorPostPagination = exports.CursorPagination = exports.OffsetPaginationInsightsClusteringJobs = exports.OffsetPaginationOnlineEvaluators = exports.OffsetPaginationCommits = exports.OffsetPaginationRepos = exports.OffsetPaginationIssues = exports.OffsetPaginationTopLevelArray = exports.PagePromise = exports.AbstractPage = void 0;
const tslib_1 = require("../internal/tslib.js");
const error_1 = require("./error.js");
const parse_1 = require("../internal/parse.js");
const api_promise_1 = require("./api-promise.js");
const values_1 = require("../internal/utils/values.js");
class AbstractPage {
    constructor(client, response, body, options) {
        _AbstractPage_client.set(this, void 0);
        Object.defineProperty(this, "options", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "response", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "body", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        tslib_1.__classPrivateFieldSet(this, _AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
    }
    hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
            return false;
        return this.nextPageRequestOptions() != null;
    }
    async getNextPage() {
        const nextOptions = this.nextPageRequestOptions();
        if (!nextOptions) {
            throw new error_1.LangsmithError('No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.');
        }
        return await tslib_1.__classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
        let page = this;
        yield page;
        while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
        }
    }
    async *[(_AbstractPage_client = new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
                yield item;
            }
        }
    }
}
exports.AbstractPage = AbstractPage;
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
class PagePromise extends api_promise_1.APIPromise {
    constructor(client, request, Page) {
        super(client, request, async (client, props) => new Page(client, props.response, await (0, parse_1.defaultParseResponse)(client, props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
            yield item;
        }
    }
}
exports.PagePromise = PagePromise;
class OffsetPaginationTopLevelArray extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.items = body || [];
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationTopLevelArray = OffsetPaginationTopLevelArray;
class OffsetPaginationIssues extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.items = body || [];
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationIssues = OffsetPaginationIssues;
class OffsetPaginationRepos extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "repos", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "total", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.repos = body.repos || [];
        this.total = body.total || 0;
    }
    getPaginatedItems() {
        return this.repos ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationRepos = OffsetPaginationRepos;
class OffsetPaginationCommits extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "commits", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "total", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.commits = body.commits || [];
        this.total = body.total || 0;
    }
    getPaginatedItems() {
        return this.commits ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationCommits = OffsetPaginationCommits;
class OffsetPaginationOnlineEvaluators extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "evaluators", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "total", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.evaluators = body.evaluators || [];
        this.total = body.total || 0;
    }
    getPaginatedItems() {
        return this.evaluators ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationOnlineEvaluators = OffsetPaginationOnlineEvaluators;
class OffsetPaginationInsightsClusteringJobs extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "clustering_jobs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.clustering_jobs = body.clustering_jobs || [];
    }
    getPaginatedItems() {
        return this.clustering_jobs ?? [];
    }
    nextPageRequestOptions() {
        const offset = this.options.query.offset ?? 0;
        const length = this.getPaginatedItems().length;
        const currentCount = offset + length;
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                offset: currentCount,
            },
        };
    }
}
exports.OffsetPaginationInsightsClusteringJobs = OffsetPaginationInsightsClusteringJobs;
class CursorPagination extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "runs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "cursors", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.runs = body.runs || [];
        this.cursors = body.cursors || {};
    }
    getPaginatedItems() {
        return this.runs ?? [];
    }
    nextPageRequestOptions() {
        const cursor = this.cursors?.next;
        if (!cursor) {
            return null;
        }
        return {
            ...this.options,
            body: {
                ...(0, values_1.maybeObj)(this.options.body),
                cursor,
            },
        };
    }
}
exports.CursorPagination = CursorPagination;
class ItemsCursorPostPagination extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "next_cursor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.items = body.items || [];
        this.next_cursor = body.next_cursor || '';
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    nextPageRequestOptions() {
        const cursor = this.next_cursor;
        if (!cursor) {
            return null;
        }
        return {
            ...this.options,
            body: {
                ...(0, values_1.maybeObj)(this.options.body),
                cursor,
            },
        };
    }
}
exports.ItemsCursorPostPagination = ItemsCursorPostPagination;
class ItemsCursorGetPagination extends AbstractPage {
    constructor(client, response, body, options) {
        super(client, response, body, options);
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "next_cursor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.items = body.items || [];
        this.next_cursor = body.next_cursor || '';
    }
    getPaginatedItems() {
        return this.items ?? [];
    }
    nextPageRequestOptions() {
        const cursor = this.next_cursor;
        if (!cursor) {
            return null;
        }
        return {
            ...this.options,
            query: {
                ...(0, values_1.maybeObj)(this.options.query),
                cursor,
            },
        };
    }
}
exports.ItemsCursorGetPagination = ItemsCursorGetPagination;
//# sourceMappingURL=pagination.js.map