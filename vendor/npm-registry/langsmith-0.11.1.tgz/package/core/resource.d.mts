import type { Langsmith } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: Langsmith;
    constructor(client: Langsmith);
}
//# sourceMappingURL=resource.d.mts.map