// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
export * from "../lib/wrappers/openai_agents.mjs";
//# sourceMappingURL=openai_agents.mjs.map