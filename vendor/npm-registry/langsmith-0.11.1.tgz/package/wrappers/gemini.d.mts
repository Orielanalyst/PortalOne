export * from "../lib/wrappers/gemini.mjs";
export { default } from "../lib/wrappers/gemini.mjs";
//# sourceMappingURL=gemini.d.mts.map