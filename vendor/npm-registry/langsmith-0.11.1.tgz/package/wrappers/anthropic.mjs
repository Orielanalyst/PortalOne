// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
export * from "../lib/wrappers/anthropic.mjs";
//# sourceMappingURL=anthropic.mjs.map