// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
export * from "../lib/wrappers/gemini.mjs";
export { default } from "../lib/wrappers/gemini.mjs";
//# sourceMappingURL=gemini.mjs.map