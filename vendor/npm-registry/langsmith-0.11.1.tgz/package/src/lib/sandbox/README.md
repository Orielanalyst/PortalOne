# LangSmith Sandbox (JavaScript/TypeScript)

Sandboxed code execution for LangSmith. Run untrusted code safely in isolated containers.

## Quick Start

By default, sandboxes are created with the server's standard runtime. You only
need a snapshot when you want to boot from a reusable custom filesystem image.

```typescript
import { SandboxClient } from "langsmith/sandbox";

// Client uses LANGSMITH_ENDPOINT and LANGSMITH_API_KEY from environment
const client = new SandboxClient();

// Create a sandbox with the default runtime and run code
const sandbox = await client.createSandbox();
try {
  const result = await sandbox.run("python -c 'print(2 + 2)'");
  console.log(result.stdout); // "4\n"
  console.log(result.exit_code); // 0
} finally {
  await sandbox.delete();
}

// Or reuse an existing sandbox by name
const existingSb = await client.getSandbox("your-sandbox");
const res = await existingSb.run("python -c 'print(2 + 2)'");
```

If you have a reusable snapshot ID, pass it to `client.createSandbox(snapshotId)`.

## Tracing

Sandbox operations add `sandbox_id` metadata to the current LangSmith run when
called inside a traced function. They do not create additional runs or enable
tracing. Existing metadata is preserved; when a run uses several sandboxes, the
most recently used sandbox ID is recorded.

The ID comes from the sandbox handle, a create/get/update response, or a UUID
passed to a client method. Name-based client calls reuse IDs learned by that
client from create/get/update. Unknown IDs are omitted rather than replaced with
display names or resolved with extra requests; call `getSandbox()` first to
resolve a name. Listing sandboxes does not annotate the active run.

## Configuration

The client automatically uses LangSmith environment variables:

```typescript
import { SandboxClient } from "langsmith/sandbox";

// Uses LANGSMITH_ENDPOINT and LANGSMITH_API_KEY
const client = new SandboxClient();

// Or configure explicitly
const client = new SandboxClient({
  apiEndpoint: "https://api.smith.langchain.com/v2/sandboxes",
  apiKey: "your-api-key",
  maxRetries: 3, // Retries for transient failures (default: 3)
  maxConcurrency: 10, // Max concurrent requests (default: Infinity)
});
```

## AWS Auth Proxy

Use the AWS auth proxy when sandbox code needs to call AWS services such as S3,
Bedrock, or another supported AWS HTTPS endpoint. You configure the AWS
credentials on the sandbox proxy, and the proxy signs outbound AWS requests with
SigV4. The real credentials stay outside the sandbox.

Store AWS credentials as LangSmith workspace secrets using names that make sense
for your workspace. Then reference those secret names in the proxy config:

```typescript
import {
  SandboxClient,
  awsAuth,
  proxyConfig,
  workspaceSecret,
} from "langsmith/sandbox";

const client = new SandboxClient();
const authConfig = proxyConfig({
  rules: [
    awsAuth({
      accessKeyId: workspaceSecret("SANDBOX_AWS_ACCESS_KEY_ID"),
      secretAccessKey: workspaceSecret("SANDBOX_AWS_SECRET_ACCESS_KEY"),
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "aws-sandbox",
  proxyConfig: authConfig,
});

try {
  const result = await sandbox.run("node your-aws-script.js");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

Inside `your-aws-script.js`, use AWS SDKs normally. For example, if
`@aws-sdk/client-s3` is installed in the sandbox snapshot:

```typescript
import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";

const s3 = new S3Client({});
const response = await s3.send(new ListBucketsCommand({}));
console.log(response.Buckets?.map((bucket) => bucket.Name));
```

If your application mints short-lived AWS credentials, pass them as write-only
opaque values instead:

```typescript
import { awsAuth, opaqueSecret, proxyConfig } from "langsmith/sandbox";

const authConfig = proxyConfig({
  rules: [
    awsAuth({
      accessKeyId: opaqueSecret(accessKeyId),
      secretAccessKey: opaqueSecret(secretAccessKey),
    }),
  ],
});
```

Do not put real AWS credentials in sandbox environment variables. Plaintext AWS
credential values are not accepted directly by the AWS auth proxy; wrap
short-lived write-only values with `opaqueSecret(...)`.

## GCP Auth Proxy

Use the GCP auth proxy when sandbox code needs to call Google APIs. You
configure service account JSON on the sandbox proxy, and the proxy injects OAuth
bearer tokens for Google API hosts matched automatically by the sandbox proxy.
The real service account JSON stays outside the sandbox.

Store the service account JSON as a LangSmith workspace secret, then reference
that secret name in the proxy config:

```typescript
import {
  SandboxClient,
  gcpAuth,
  proxyConfig,
  workspaceSecret,
} from "langsmith/sandbox";

const client = new SandboxClient();
const authConfig = proxyConfig({
  rules: [
    gcpAuth({
      serviceAccountJson: workspaceSecret("SANDBOX_GCP_SERVICE_ACCOUNT_JSON"),
      scopes: ["https://www.googleapis.com/auth/devstorage.read_write"],
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "gcp-sandbox",
  proxyConfig: authConfig,
});

try {
  const result = await sandbox.run("node your-gcp-script.js");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

Use `opaqueSecret("...")` for short-lived write-only service account JSON.
Plaintext service account JSON is not accepted directly.

## Sandbox Mounts

Use mounts when sandbox code needs filesystem access to external data such as
object storage buckets or public Git repositories. Mount specs contain only the
mount target. Provider credentials stay in `mountConfig.auth`; the backend
expands them into runtime proxy auth rules. You can also pass `proxyConfig` for
non-mount proxy behavior such as custom headers, callbacks, or access control.
Explicit AWS/GCP proxy auth rules conflict with `mountConfig` auth for the same
provider.

S3 mounts require AWS auth:

```typescript
import {
  awsAuth,
  mountConfig,
  s3Mount,
  workspaceSecret,
} from "langsmith/sandbox";

const mountCfg = mountConfig({
  auth: [
    awsAuth({
      accessKeyId: workspaceSecret("SANDBOX_AWS_ACCESS_KEY_ID"),
      secretAccessKey: workspaceSecret("SANDBOX_AWS_SECRET_ACCESS_KEY"),
    }),
  ],
  mounts: [
    s3Mount({
      id: "customer_data",
      mountPath: "/mnt/mounts/customer-data",
      bucket: "example-bucket",
      prefix: "datasets/customer-data",
      region: "us-east-1",
      endpointUrl: "https://s3.amazonaws.com",
      pathStyle: false,
      readOnly: false,
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "s3-mount-sandbox",
  mountConfig: mountCfg,
});

try {
  const result = await sandbox.run("ls /mnt/mounts/customer-data");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

GCS mounts require GCP auth:

```typescript
import {
  gcpAuth,
  gcsMount,
  mountConfig,
  workspaceSecret,
} from "langsmith/sandbox";

const mountCfg = mountConfig({
  auth: [
    gcpAuth({
      serviceAccountJson: workspaceSecret("SANDBOX_GCP_SERVICE_ACCOUNT_JSON"),
    }),
  ],
  mounts: [
    gcsMount({
      id: "customer_data",
      mountPath: "/mnt/mounts/customer-data",
      bucket: "example-bucket",
      prefix: "datasets/customer-data",
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "gcs-mount-sandbox",
  mountConfig: mountCfg,
});

try {
  const result = await sandbox.run("ls /mnt/mounts/customer-data");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

Public Git mounts do not require AWS or GCP auth:

```typescript
import { gitMount, mountConfig } from "langsmith/sandbox";

const mountCfg = mountConfig({
  mounts: [
    gitMount({
      id: "repo",
      mountPath: "/mnt/repo",
      remoteUrl: "https://github.com/langchain-ai/langsmith-sdk.git",
      ref: { type: "branch", name: "main" },
      refreshIntervalSeconds: 60,
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "git-mount-sandbox",
  mountConfig: mountCfg,
});

try {
  const result = await sandbox.run("ls /mnt/repo");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

Private Git repositories can use low-level `proxyConfig` rules when the remote
requires proxy-managed auth. There is not yet a high-level private Git auth
helper.

Context Hub mounts are **read-only**: the repo's latest commit tree is mirrored
into the mount path and kept in sync for the sandbox's lifetime, but the sync is
one-way. Files written under the mount path inside the sandbox are never pushed
back to the repo, and the next sync overwrites them. Write sandbox output
somewhere else and push it with the Context Hub SDK if it belongs in the repo.

They do not require AWS or GCP auth, and unlike bucket and Git mounts they can
target any path outside the system directories — not just paths under
`/mnt/mounts`. The caller's API key must have access to the repo:

```typescript
import { contextHubMount, mountConfig } from "langsmith/sandbox";

const mountCfg = mountConfig({
  mounts: [
    contextHubMount({
      id: "memories",
      mountPath: "/memories",
      repo: "-/my-agent",
    }),
  ],
});

const sandbox = await client.createSandbox({
  name: "context-hub-mount-sandbox",
  mountConfig: mountCfg,
});

try {
  const result = await sandbox.run("ls /memories");
  console.log(result.stdout);
} finally {
  await sandbox.delete();
}
```

Pass `initialPullOnly: true` to sync once at startup instead of polling for repo
updates.

If one sandbox needs S3, GCS, and Git mounts, build one `mountConfig` with the
bucket provider auth blocks and all mount specs:

```typescript
import {
  awsAuth,
  gitMount,
  gcpAuth,
  gcsMount,
  mountConfig,
  s3Mount,
  workspaceSecret,
} from "langsmith/sandbox";

const mountCfg = mountConfig({
  auth: [
    awsAuth({
      accessKeyId: workspaceSecret("SANDBOX_AWS_ACCESS_KEY_ID"),
      secretAccessKey: workspaceSecret("SANDBOX_AWS_SECRET_ACCESS_KEY"),
    }),
    gcpAuth({
      serviceAccountJson: workspaceSecret("SANDBOX_GCP_SERVICE_ACCOUNT_JSON"),
    }),
  ],
  mounts: [
    s3Mount({
      id: "s3_data",
      mountPath: "/mnt/mounts/s3-data",
      bucket: "example-s3-bucket",
    }),
    gcsMount({
      id: "gcs_data",
      mountPath: "/mnt/mounts/gcs-data",
      bucket: "example-gcs-bucket",
    }),
    gitMount({
      id: "repo",
      mountPath: "/mnt/repo",
      remoteUrl: "https://github.com/langchain-ai/langsmith-sdk.git",
    }),
  ],
});
```

## Running Commands

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Run a command
  const result = await sandbox.run("echo 'Hello, World!'");

  console.log(result.stdout); // "Hello, World!\n"
  console.log(result.stderr); // ""
  console.log(result.exit_code); // 0

  // Commands that fail return non-zero exit codes
  const failed = await sandbox.run("exit 1");
  console.log(failed.exit_code); // 1

  // Pass environment variables and working directory
  const envResult = await sandbox.run("echo $MY_VAR", {
    env: { MY_VAR: "test-value" },
    cwd: "/tmp",
  });
} finally {
  await sandbox.delete();
}
```

## Streaming Execution (WebSocket)

For long-running commands, you can stream output in real-time using WebSocket-based execution. This requires the optional `ws` package:

```bash
npm install ws
```

### Stream with callbacks

```typescript
// Stream stdout/stderr via callbacks (blocks until complete)
const result = await sandbox.run("make build", {
  onStdout: (data) => process.stdout.write(data),
  onStderr: (data) => process.stderr.write(data),
});
console.log(`Exit code: ${result.exit_code}`);
```

### Non-blocking with CommandHandle

```typescript
// Get a CommandHandle for full control over the stream
const handle = await sandbox.run("python train.py", {
  wait: false,
  timeout: 600,
});

console.log(`Command ID: ${handle.commandId}`);
console.log(`PID: ${handle.pid}`);

// Iterate over output chunks (auto-reconnects on transient errors)
for await (const chunk of handle) {
  if (chunk.stream === "stdout") {
    process.stdout.write(chunk.data);
  } else {
    process.stderr.write(chunk.data);
  }
}

// Get the final result
const result = await handle.result;
console.log(`Exit code: ${result.exit_code}`);
```

### Sending stdin and killing commands

```typescript
const handle = await sandbox.run("python -i", { wait: false });

// Send input to stdin
handle.sendInput("print(2 + 2)\n");
handle.sendInput("exit()\n");

for await (const chunk of handle) {
  process.stdout.write(chunk.data);
}
```

```typescript
const handle = await sandbox.run("sleep 300", { wait: false });

// Kill the running command
handle.kill();

const result = await handle.result;
console.log(result.exit_code); // non-zero
```

### Reconnecting to a running command

```typescript
// If a client disconnects, you can reconnect using the command ID
const handle = await sandbox.run("long-task", { wait: false });
const commandId = handle.commandId;

// ... later, or from a different client ...
const newHandle = await sandbox.reconnect(commandId);
for await (const chunk of newHandle) {
  process.stdout.write(chunk.data);
}
```

> **Note:** When `wait` is `true` (default) with no callbacks, `run()` automatically tries WebSocket first and falls back to HTTP POST if the `ws` package is not installed or the server doesn't support it.

## Command Lifecycle & TTL

The sandbox daemon automatically manages command session lifecycles with two
timeout mechanisms:

### Session TTL (finished commands)

After a command finishes (exits), its session remains in memory for a TTL
period. During this window you can still reconnect to retrieve output. After the
TTL expires, the session is cleaned up and `reconnect()` will throw an error.

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  const handle = await sandbox.run("make build", { wait: false });
  const commandId = handle.commandId;

  // Even after the command finishes, you can reconnect within the TTL window
  const newHandle = await sandbox.reconnect(commandId);
  const result = await newHandle.result;
  console.log(result.stdout);

  // After TTL expires, reconnect throws LangSmithSandboxOperationError
} finally {
  await sandbox.delete();
}
```

### Idle Timeout (running commands)

Running commands with no connected clients are killed after an idle timeout
(default: 5 minutes). The idle timer resets each time a client connects. This
prevents orphaned long-running processes from consuming resources indefinitely.

You can set a per-command idle timeout via the `idleTimeout` option.
Set to `-1` for no idle timeout (the command runs indefinitely until explicitly
killed or it exits on its own).

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Start a long-running command with a 30-minute idle timeout
  const handle = await sandbox.run("python server.py", {
    timeout: 0,
    idleTimeout: 1800,
    wait: false,
  });

  // As long as a client is connected (iterating), the idle timer is paused
  for await (const chunk of handle) {
    process.stdout.write(chunk.data);
    if (chunk.data.includes("Ready")) break;
  }

  // After disconnecting, the idle timer starts
  // If no client reconnects within idleTimeout seconds, the process is killed
} finally {
  await sandbox.delete();
}
```

### Kill on Disconnect

By default, commands continue running after a client disconnects and can be
reconnected to later. Set `killOnDisconnect: true` to kill the command
immediately when the last client disconnects:

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Command is killed as soon as the client disconnects
  const handle = await sandbox.run("python server.py", {
    killOnDisconnect: true,
    wait: false,
  });

  for await (const chunk of handle) {
    process.stdout.write(chunk.data);
    if (chunk.data.includes("Ready")) break;
  }
  // Command is killed here when iteration stops and the WS disconnects
} finally {
  await sandbox.delete();
}
```

### Combining Lifecycle Options

All lifecycle options can be combined:

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Long-running task: 30-min idle timeout, 1-hour session TTL
  const handle = await sandbox.run("python train.py", {
    timeout: 0, // No command timeout
    idleTimeout: 1800, // Kill after 30min with no clients
    ttlSeconds: 3600, // Keep session for 1 hour after exit
    wait: false,
  });

  // Fire-and-forget: no idle timeout, infinite TTL
  const bg = await sandbox.run("python background_job.py", {
    timeout: 0,
    idleTimeout: -1, // Never kill due to idle
    ttlSeconds: -1, // Keep session forever
    wait: false,
  });
} finally {
  await sandbox.delete();
}
```

## PTY (Pseudo-Terminal)

Set `pty: true` to allocate a pseudo-terminal for the command. This is useful
for interactive programs and commands that detect terminal capabilities:

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Run an interactive Python REPL with PTY
  const handle = await sandbox.run("python", { pty: true, wait: false });

  for await (const chunk of handle) {
    if (chunk.data.includes(">>>")) {
      handle.sendInput("print('hello')\n");
      break;
    }
  }

  for await (const chunk of handle) {
    if (chunk.data.includes(">>>")) {
      handle.sendInput("exit()\n");
      break;
    }
  }

  const result = await handle.result;

  // Commands that require a TTY
  const topResult = await sandbox.run("top -b -n 1", { pty: true });
} finally {
  await sandbox.delete();
}
```

> **Note:** PTY mode merges stdout and stderr into a single stream (stdout).
> Only use PTY when the command requires it — most commands work fine without it.

## File Operations

Read and write files in the sandbox:

```typescript
const sandbox = await client.createSandbox(snapshot.id);
try {
  // Write a file (string content)
  await sandbox.write("/app/script.py", "print('Hello from file!')");

  // Run the script
  const result = await sandbox.run("python /app/script.py");
  console.log(result.stdout); // "Hello from file!\n"

  // Read a file (returns Uint8Array)
  const content = await sandbox.read("/app/script.py");
  console.log(new TextDecoder().decode(content)); // "print('Hello from file!')"

  // Write binary files
  await sandbox.write(
    "/app/data.bin",
    new Uint8Array([0x00, 0x01, 0x02, 0x03]),
  );
} finally {
  await sandbox.delete();
}
```

## Verifying Requests from LangSmith

`SandboxTokenVerifier` checks signatures against LangSmith's JWKS (derived from
`LANGSMITH_ENDPOINT`, cached); user tokens may use any JOSE asymmetric algorithm
(RS*, PS*, ES\*, EdDSA), chosen by the JWKS key. It uses Web Crypto, so it needs a
runtime with Ed25519 support (Node.js 20+, Deno, Bun, Cloudflare Workers). The
JWKS must be served over HTTPS (localhost is exempt); for a plain-HTTP
self-hosted deployment on a trusted network, pass `allowInsecureJwks: true`.

### Service URL Users

Apps served from a service URL with LangSmith login receive the caller's
identity in `X-Langsmith-User-Id` / `X-Langsmith-User-Email`. The sandbox
runtime strips these from inbound requests and sets them itself, so code that
knows it is running in a sandbox can trust them as-is. This holds only for
requests that arrive through the service URL: TCP tunnels and other processes in
the sandbox calling the port over localhost reach the app with whatever headers
they choose. Otherwise, verify the signed `X-Langsmith-User-Token` header, which
carries the same identity:

```typescript
import { SandboxTokenVerifier, USER_TOKEN_HEADER } from "langsmith/sandbox";

const verifier = new SandboxTokenVerifier();

const user = await verifier.verifyUserToken(
  req.headers.get(USER_TOKEN_HEADER)!,
  {
    audience: req.headers.get("host")!, // the service URL host
  },
);
console.log(user.subject, user.email);
```

### Proxy Callbacks

Callback endpoints receive a body signed via the `X-LangSmith-Signature-JWT`
header. Pass the raw body. Optionally pass `aud` to check the signature was
minted for this endpoint: either the callback URL exactly as configured, or a
predicate called with the signature's audience:

```typescript
import { CALLBACK_SIGNATURE_HEADER } from "langsmith/sandbox";

const callback = await verifier.verifyCallback({
  body: await req.text(),
  signature: req.headers.get(CALLBACK_SIGNATURE_HEADER)!,
  aud: "https://example.com/sandbox-callback",
});
console.log(callback.identity.sandbox_id, callback.host);
```

Both throw `LangSmithSandboxTokenVerificationError` on failure.

## Snapshots

Snapshots are the filesystem images sandboxes boot from. You can build one from
a Docker image or capture the state of a running sandbox.

```typescript
// Build a snapshot from a public Docker image
const snapshot = await client.createSnapshot(
  "python",
  "python:3.12-slim",
  1_073_741_824, // 1 GiB
);

// Create a private registry once, then reference it by id. Store the password
// in a secret, not in source.
const registry = await client.sandboxes.registries.create({
  name: "internal",
  url: "registry.example.com",
  username: "robot",
  password: "...",
});

// Build from a private registry
const privateSnapshot = await client.createSnapshot(
  "internal-python",
  "registry.example.com/internal/python:3.12",
  2_147_483_648,
  { registryId: registry.id },
);

// Capture the state of a running sandbox for later reuse. Persistent paths
// (`/usr/local`, `/root`, `/opt`, the home directory, etc.) are preserved;
// `/tmp` is a tmpfs and is NOT part of the capture.
const running = await client.createSandbox(snapshot.id);
await running.run("pip install --quiet requests", { timeout: 180 });
await running.write("/opt/prepared.txt", "preloaded");

// Either form works; the instance method just forwards to the client.
const captured = await running.captureSnapshot("with-data", { timeout: 300 });
// const captured = await client.captureSnapshot(running.name, "with-data");

console.log(captured.id, captured.source_sandbox_id);

// Boot a new sandbox from the captured snapshot
const resumed = await client.createSandbox(captured.id);

// Or resolve by snapshot name instead of ID. This is optional; omitting both
// snapshotId and snapshotName uses the default runtime.
const byName = await client.createSandbox({
  snapshotName: "with-data",
});

// List / fetch / delete snapshots. listSnapshots() accepts optional
// server-side filters and pagination; when omitted the server applies a
// default page size of 50, so calling it once will not necessarily return
// every snapshot. `limit` must be between 1 and 500 and `offset` must be
// >= 0.
const firstPage = await client.listSnapshots();
const firstPython = await client.listSnapshots({
  nameContains: "python",
  limit: 100,
  offset: 0,
});
const loaded = await client.getSnapshot(snapshot.id);
await client.deleteSnapshot(snapshot.id);
```

> **Note:** `captureSnapshot` preserves only the persistent filesystem. Running
> processes, open sockets, in-memory state, and anything under `/tmp` are not
> carried over — restart the processes you need in the new sandbox.

### Sizing and Resources

`createSandbox` accepts optional per-sandbox resource limits. If omitted, the
server-side defaults are used — prefer that unless you have a specific need.

```typescript
const sandbox = await client.createSandbox({
  fsCapacityBytes: 5_368_709_120, // 5 GiB
});
```

`vCpus` and `memBytes` may also be set, but they are validated together:
`memBytes` must be within 50% of 4 GiB per vCPU, so a 2-vCPU sandbox accepts
4–12 GiB. Requests outside that range are rejected.

```typescript
const sandbox = await client.createSandbox({
  vCpus: 2,
  memBytes: 8_589_934_592, // 8 GiB
});
```

## Reusing Existing Sandboxes

Get a sandbox that's already running:

```typescript
// Create a sandbox (requires explicit cleanup)
const sb = await client.createSandbox(snapshot.id);
console.log(sb.name); // e.g., "sandbox-abc123"

// Later, get the same sandbox
const existingSb = await client.getSandbox("sandbox-abc123");
const result = await existingSb.run("echo 'Still running!'");

// Clean up when done
await client.deleteSandbox("sandbox-abc123");
```

## Error Handling

The module provides typed exceptions for specific error handling:

```typescript
import {
  SandboxClient,
  LangSmithSandboxError, // Base exception for all sandbox errors
  LangSmithResourceNotFoundError, // Resource doesn't exist (check resourceType)
  LangSmithResourceTimeoutError, // Operation timed out (check resourceType)
  LangSmithSandboxConnectionError, // Network error
  LangSmithSandboxServerReloadError, // Server hot-reload (auto-reconnects)
  LangSmithCommandTimeoutError, // Command exceeded its timeout
  LangSmithQuotaExceededError, // Quota limit reached
  LangSmithValidationError, // Invalid input
} from "langsmith/sandbox";

const client = new SandboxClient();

try {
  // This will fail if the snapshot doesn't exist
  const sandbox = await client.createSandbox("nonexistent");
  await sandbox.delete();
} catch (e) {
  if (e instanceof LangSmithResourceNotFoundError) {
    // e.resourceType tells you what wasn't found: "sandbox", "snapshot", "file"
    console.log(`${e.resourceType} not found: ${e.message}`);
  } else if (e instanceof LangSmithResourceTimeoutError) {
    console.log(`Timeout waiting for ${e.resourceType}: ${e.message}`);
  } else if (e instanceof LangSmithSandboxError) {
    console.log(`Error: ${e.message}`);
  }
}
```

## API Reference

### SandboxClient

| Method                                                             | Description                                                                                                              |
| ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------ |
| `createSandbox(options?)` / `createSandbox(snapshotId?, options?)` | Create a sandbox. Pass `snapshotId` or `options.snapshotName` to boot from a reusable snapshot.                          |
| `getSandbox(name)`                                                 | Get an existing sandbox by name                                                                                          |
| `listSandboxes()`                                                  | List all sandboxes                                                                                                       |
| `updateSandbox(name, options)`                                     | Rename or adjust retention (idle stop, delete-after-stop) on a sandbox                                                   |
| `deleteSandbox(name)`                                              | Delete a sandbox                                                                                                         |
| `startSandbox(name, options?)`                                     | Start a stopped sandbox and wait until ready                                                                             |
| `stopSandbox(name)`                                                | Stop a running sandbox (preserves files)                                                                                 |
| `getSandboxStatus(name)`                                           | Lightweight status poll for async creation                                                                               |
| `waitForSandbox(name, options?)`                                   | Poll until a sandbox becomes ready                                                                                       |
| `createSnapshot(name, dockerImage, fsCapacityBytes, options?)`     | Build a snapshot from a Docker image                                                                                     |
| `captureSnapshot(sandboxName, name, options?)`                     | Capture a snapshot from a running sandbox                                                                                |
| `getSnapshot(snapshotId)`                                          | Get a snapshot by ID                                                                                                     |
| `listSnapshots(options?)`                                          | List a page of snapshots with optional server-side filters and pagination (server paginates, default limit 50, max 500). |
| `deleteSnapshot(snapshotId)`                                       | Delete a snapshot                                                                                                        |
| `waitForSnapshot(snapshotId, options?)`                            | Poll until a snapshot becomes ready                                                                                      |

### Sandbox

| Method                            | Description                                                                                            |
| --------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `run(command, options?)`          | Execute a shell command (returns `ExecutionResult` or `CommandHandle`). Supports `idleTimeout` option. |
| `reconnect(commandId, options?)`  | Reconnect to a running command by ID                                                                   |
| `write(path, content, timeout?)`  | Write file (string or Uint8Array)                                                                      |
| `read(path, timeout?)`            | Read file (returns Uint8Array)                                                                         |
| `start(options?)`                 | Start this sandbox (if stopped)                                                                        |
| `stop()`                          | Stop this sandbox                                                                                      |
| `captureSnapshot(name, options?)` | Capture a snapshot from this sandbox                                                                   |
| `delete()`                        | Delete the sandbox                                                                                     |

### CommandHandle

| Property/Method          | Description                                       |
| ------------------------ | ------------------------------------------------- |
| `commandId`              | Server-assigned command ID                        |
| `pid`                    | Process ID on the sandbox                         |
| `result`                 | Final `ExecutionResult` (drains stream if needed) |
| `kill()`                 | Send SIGKILL to the running command               |
| `sendInput(data)`        | Write string data to the command's stdin          |
| `reconnect()`            | Reconnect from the last known offsets             |
| `lastStdoutOffset`       | Last stdout byte offset (for manual reconnection) |
| `lastStderrOffset`       | Last stderr byte offset (for manual reconnection) |
| `[Symbol.asyncIterator]` | Yields `OutputChunk` objects with auto-reconnect  |

### ExecutionResult

| Property    | Description              |
| ----------- | ------------------------ |
| `stdout`    | Standard output (string) |
| `stderr`    | Standard error (string)  |
| `exit_code` | Exit code (number)       |

### OutputChunk

| Property | Description                   |
| -------- | ----------------------------- |
| `stream` | `"stdout"` or `"stderr"`      |
| `data`   | Text content of the chunk     |
| `offset` | Byte offset within the stream |

### CreateSandboxOptions

| Property                  | Description                                                                                                                                                                |
| ------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `snapshotName?`           | Optional snapshot name to boot from. Mutually exclusive with the positional `snapshotId`.                                                                                  |
| `name?`                   | Custom sandbox name                                                                                                                                                        |
| `timeout?`                | Wait timeout in seconds                                                                                                                                                    |
| `waitForReady?`           | Wait for the sandbox to be ready before returning (default: `true`)                                                                                                        |
| `idleTtlSeconds?`         | Idle timeout in seconds (multiple of 60; `0` disables idle stop). When omitted, the server applies a default of `600` seconds (10 minutes).                                |
| `deleteAfterStopSeconds?` | Seconds after the sandbox enters `stopped` before deletion (multiple of 60; `0` disables stop-anchored deletion). When omitted, the server applies its configured default. |
| `vCpus?`                  | Number of vCPUs                                                                                                                                                            |
| `memBytes?`               | Memory allocation in bytes                                                                                                                                                 |
| `fsCapacityBytes?`        | Root filesystem capacity in bytes                                                                                                                                          |
| `mountConfig?`            | High-level mount config from `mountConfig({ mounts, auth })`; sent as `mount_config` and expanded by the backend at runtime                                                |
| `proxyConfig?`            | Per-sandbox proxy configuration (access control, rules, callbacks)                                                                                                         |

### ListSnapshotsOptions

| Property        | Description                                                                               |
| --------------- | ----------------------------------------------------------------------------------------- |
| `nameContains?` | Case-insensitive substring filter applied server-side to snapshot names                   |
| `limit?`        | Page size; must be in `[1, 500]`. Server defaults to 50 when omitted                      |
| `offset?`       | Number of snapshots to skip before returning results (must be `>= 0`, pairs with `limit`) |
| `signal?`       | `AbortSignal` for cancellation                                                            |

### CreateSnapshotOptions

| Property      | Description                           |
| ------------- | ------------------------------------- |
| `registryId?` | Private registry ID                   |
| `timeout?`    | Wait timeout in seconds (default: 60) |
| `signal?`     | `AbortSignal` for cancellation        |

### UpdateSandboxOptions

| Property                  | Description                                                                                                                            |
| ------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `newName?`                | New display name                                                                                                                       |
| `idleTtlSeconds?`         | Idle timeout in seconds (multiple of 60; `0` disables idle stop). Omit to leave the existing value unchanged.                          |
| `deleteAfterStopSeconds?` | Seconds after the sandbox enters `stopped` before deletion (multiple of 60; `0` disables). Omit to leave the existing value unchanged. |

### RunOptions

| Property            | Description                                                                                                                       |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `timeout?`          | Execution timeout in seconds (default: 60)                                                                                        |
| `env?`              | Environment variables for the command                                                                                             |
| `cwd?`              | Working directory                                                                                                                 |
| `shell?`            | Shell to use (default: `"/bin/bash"`)                                                                                             |
| `wait?`             | Wait for completion (default: `true`). When `false`, returns `CommandHandle`                                                      |
| `onStdout?`         | Callback invoked with each stdout chunk (triggers WS streaming)                                                                   |
| `onStderr?`         | Callback invoked with each stderr chunk (triggers WS streaming)                                                                   |
| `idleTimeout?`      | Idle timeout in seconds (default: 300). Set to -1 for no timeout. Kills the command if no clients are connected for this duration |
| `killOnDisconnect?` | If true, kill the command immediately when the last client disconnects (default: false)                                           |
| `ttlSeconds?`       | How long a finished command's session is kept for reconnection (default: 600). Set to -1 to keep indefinitely                     |
| `pty?`              | Allocate a pseudo-terminal (default: false). Merges stderr into stdout                                                            |
