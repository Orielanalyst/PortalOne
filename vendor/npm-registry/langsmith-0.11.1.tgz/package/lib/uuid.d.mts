export { uuid7FromTime } from "./utils/_uuid.mjs";
/**
 * Generate a random UUID v7 string.
 */
export declare function uuid7(): string;
/**
 * Compute the run ID used for a secondary tracing replica.
 *
 * @param runId - The original UUID v7 run ID.
 * @param projectName - The secondary replica's destination project name.
 * @returns The run ID used in the secondary replica destination.
 */
export declare function computeRunIdForSecondaryReplica(runId: string, projectName: string): string;
//# sourceMappingURL=uuid.d.mts.map