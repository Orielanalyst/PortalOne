import { Client } from "../index.mjs";
import { ComparativeExperiment, ComparisonEvaluationResult as ComparisonEvaluationResultRow, Example, Run, TracerSession } from "../schemas.mjs";
import { evaluate } from "./index.mjs";
type ExperimentResults = Awaited<ReturnType<typeof evaluate>>;
export declare function loadTracesForExperiment(client: Client, project: TracerSession, options: {
    loadNested: boolean;
}): Promise<Run[]>;
/** @deprecated Use ComparativeEvaluatorNew instead: (args: { runs, example, inputs, outputs, referenceOutputs }) => ... */
export type _ComparativeEvaluatorLegacy = (runs: Run[], example: Example) => ComparisonEvaluationResultRow | Promise<ComparisonEvaluationResultRow>;
export type _ComparativeEvaluator = (args: {
    runs: Run[];
    example: Example;
    inputs: Record<string, any>;
    outputs: Record<string, any>[];
    referenceOutputs?: Record<string, any>;
}) => ComparisonEvaluationResultRow | Promise<ComparisonEvaluationResultRow>;
export type ComparativeEvaluator = _ComparativeEvaluatorLegacy | _ComparativeEvaluator;
export interface EvaluateComparativeOptions {
    /**
     * A list of evaluators to use for comparative evaluation.
     */
    evaluators: Array<ComparativeEvaluator>;
    /**
     * Randomize the order of outputs for each evaluation
     * @default false
     */
    randomizeOrder?: boolean;
    /**
     * The LangSmith client to use.
     * @default undefined
     */
    client?: Client;
    /**
     * Metadata to attach to the experiment.
     * @default undefined
     */
    metadata?: Record<string, unknown>;
    /**
     * A prefix to use for your experiment name.
     * @default undefined
     */
    experimentPrefix?: string;
    /**
     * A free-form description of the experiment.
     * @default undefined
     */
    description?: string;
    /**
     * Whether to load all child runs for the experiment.
     * @default false
     */
    loadNested?: boolean;
    /**
     * The maximum number of concurrent evaluators to run.
     * @default undefined
     */
    maxConcurrency?: number;
}
export interface ComparisonEvaluationResults {
    /** The name of the comparative experiment. */
    experimentName: string;
    /** The per-example comparison results. */
    results: ComparisonEvaluationResultRow[];
    /** URL of the pairwise comparison view in the LangSmith UI, if available. */
    url: string | null;
    /** The comparative experiment, exposing its id, dataset, and metadata. */
    comparativeExperiment: ComparativeExperiment;
}
/** @deprecated Use `evaluate` and pass two experiments as targets. */
export declare function evaluateComparative(experiments: Array<string> | Array<Promise<ExperimentResults> | ExperimentResults>, options: EvaluateComparativeOptions): Promise<ComparisonEvaluationResults>;
export {};
//# sourceMappingURL=evaluate_comparative.d.mts.map