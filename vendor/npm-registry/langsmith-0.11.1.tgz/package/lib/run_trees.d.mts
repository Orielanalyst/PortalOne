import { Client } from "./client.mjs";
import { Attachments, BaseRun, KVMap, RunCreate } from "./schemas.mjs";
import { type AgentAddress } from "./address.mjs";
export declare function convertToDottedOrderFormat(epoch: number, runId: string, executionOrder?: number): {
    dottedOrder: string;
    microsecondPrecisionDatestring: string;
};
export interface RunTreeConfig {
    name: string;
    run_type?: string;
    id?: string;
    project_name?: string;
    /** (beta) Send the run to this address instead of a project. */
    address?: AgentAddress;
    parent_run?: RunTree;
    parent_run_id?: string;
    child_runs?: RunTree[];
    start_time?: number | string;
    end_time?: number | string;
    extra?: KVMap;
    metadata?: KVMap;
    tags?: string[];
    error?: string;
    serialized?: object;
    inputs?: KVMap;
    outputs?: KVMap;
    reference_example_id?: string;
    client?: Client;
    tracingEnabled?: boolean;
    on_end?: (runTree: RunTree) => void;
    execution_order?: number;
    child_execution_order?: number;
    trace_id?: string;
    dotted_order?: string;
    attachments?: Attachments;
    replicas?: Replica[];
    distributedParentId?: string;
}
export interface RunnableConfigLike {
    /**
     * Tags for this call and any sub-calls (eg. a Chain calling an LLM).
     * You can use these to filter calls.
     */
    tags?: string[];
    /**
     * Metadata for this call and any sub-calls (eg. a Chain calling an LLM).
     * Keys should be strings, values should be JSON-serializable.
     */
    metadata?: Record<string, unknown>;
    /**
     * Callbacks for this call and any sub-calls (eg. a Chain calling an LLM).
     * Tags are passed to all callbacks, metadata is passed to handle*Start callbacks.
     */
    callbacks?: Record<string, any> | any[];
}
interface HeadersLike {
    get(name: string): string | null;
    set(name: string, value: string): void;
}
type ProjectReplica = [string, KVMap | undefined];
export type WriteReplica = {
    apiUrl?: string;
    apiKey?: string;
    workspaceId?: string;
    projectName?: string;
    /** (beta) Send the replica to this address instead of a project. */
    address?: AgentAddress;
    /** Whether this replica keeps the original run IDs. */
    primary?: boolean;
    updates?: KVMap | undefined;
    fromEnv?: boolean;
    reroot?: boolean;
    /**
     * Optional dedicated Client for this replica.
     * When set, the replica's runs are dispatched through this client
     * (and its tracing mode) instead of the RunTree's default client.
     * Not serialized in distributed-tracing baggage headers.
     */
    client?: Client;
};
type Replica = ProjectReplica | WriteReplica;
export declare class RunTree implements BaseRun {
    private static sharedClient;
    id: string;
    name: RunTreeConfig["name"];
    run_type: string;
    /** Unset for a run sent to an `address`. */
    project_name?: string;
    /** (beta) Set instead of `project_name` for an addressed run. */
    address?: AgentAddress;
    parent_run?: RunTree;
    parent_run_id?: string;
    child_runs: RunTree[];
    start_time: number;
    end_time?: number;
    extra: KVMap;
    tags?: string[];
    error?: string;
    serialized: object;
    inputs: KVMap;
    outputs?: KVMap;
    reference_example_id?: string;
    client: Client;
    events?: KVMap[] | undefined;
    trace_id: string;
    dotted_order: string;
    tracingEnabled?: boolean;
    execution_order: number;
    child_execution_order: number;
    /**
     * Attachments associated with the run.
     * Each entry is a tuple of [mime_type, bytes]
     */
    attachments?: Attachments;
    /**
     * Projects to replicate this run to with optional updates.
     */
    replicas?: WriteReplica[];
    distributedParentId?: string;
    /**
     * @interface
     */
    private _serialized_start_time;
    constructor(originalConfig: RunTreeConfig | RunTree);
    /** Falls back to the env; a bad env leaves the run untraced. */
    private _resolveAddressing;
    set metadata(metadata: KVMap);
    get metadata(): KVMap;
    private static getDefaultConfig;
    static getSharedClient(): Client;
    createChild(config: RunTreeConfig): RunTree;
    end(outputs?: KVMap, error?: string, endTime?: number, metadata?: KVMap): Promise<void>;
    private _convertToCreate;
    private _sliceParentId;
    private _setReplicaTraceRoot;
    /** A replica naming neither inherits the run tree's destination. */
    private _replicaAddressing;
    private _remapForProject;
    postRun(excludeChildRuns?: boolean): Promise<void>;
    /**
     * Patch the run tree to the API.
     *
     * @param options.excludeInputs - Whether to exclude inputs from the patch
     * request. Defaults to the value of `LANGSMITH_EXCLUDE_INPUTS_ON_PATCH`
     * (or its `LANGCHAIN_` equivalent), which itself defaults to `true`.
     * An explicit value overrides the environment variable for this call.
     *
     * Unless the environment variable is disabled, inputs added after the
     * initial `postRun()` are not persisted unless this option is explicitly set
     * to `false`.
     */
    patchRun(options?: {
        excludeInputs?: boolean;
    }): Promise<void>;
    toJSON(): RunCreate & {
        id: string;
    };
    /**
     * Add an event to the run tree.
     * @param event - A single event or string to add
     */
    addEvent(event: RunEvent | string): void;
    static fromRunnableConfig(parentConfig: RunnableConfigLike, props: RunTreeConfig): RunTree;
    static fromDottedOrder(dottedOrder: string): RunTree | undefined;
    static fromHeaders(headers: Record<string, string | string[]> | HeadersLike, inheritArgs?: Partial<RunTreeConfig>): RunTree | undefined;
    toHeaders(headers?: HeadersLike): {
        "langsmith-trace": string;
        baggage: string;
    };
}
export declare function isRunTree(x?: unknown): x is RunTree;
export interface RunEvent {
    name?: string;
    time?: string;
    message?: string;
    kwargs?: Record<string, unknown>;
    [key: string]: unknown;
}
export declare function isRunnableConfigLike(x?: unknown): x is RunnableConfigLike;
export {};
//# sourceMappingURL=run_trees.d.mts.map