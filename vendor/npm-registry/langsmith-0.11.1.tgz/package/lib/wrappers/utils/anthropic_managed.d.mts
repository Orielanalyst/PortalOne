import type { RunTreeConfig } from "../../index.mjs";
export declare function wrapManagedAgentSessionEvents({ originalBeta, tracedBeta, cleanedOptions, prepopulatedInvocationParams, }: {
    originalBeta: any;
    tracedBeta: any;
    cleanedOptions: Partial<RunTreeConfig>;
    prepopulatedInvocationParams: unknown;
}): void;
//# sourceMappingURL=anthropic_managed.d.mts.map