import type { GenerateContentResponseUsageMetadata, UsageMetadata } from "@google/genai";
import { KVMap } from "../schemas.mjs";
export declare const createGeminiUsageMetadata: (usage: UsageMetadata | GenerateContentResponseUsageMetadata) => KVMap;
//# sourceMappingURL=gemini.utils.d.mts.map