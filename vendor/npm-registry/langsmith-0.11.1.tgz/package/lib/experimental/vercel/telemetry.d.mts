import { RunTreeConfig } from "../../run_trees.mjs";
import type { KVMap } from "../../schemas.mjs";
/**
 * Configuration options for creating a LangSmith telemetry integration
 * for the Vercel AI SDK.
 */
export interface LangSmithTelemetryConfig {
    /**
     * Custom name for the root span. If not provided, defaults to the
     * model display name or "generateText"/"streamText".
     */
    name?: string;
    /**
     * Run type for the root span. Defaults to "chain".
     */
    runType?: string;
    /**
     * Additional metadata to attach to all spans.
     */
    metadata?: KVMap;
    /**
     * Tags to attach to all spans.
     */
    tags?: string[];
    /**
     * Custom LangSmith client configuration.
     */
    client?: RunTreeConfig["client"];
    /**
     * Project name to log runs to.
     */
    projectName?: string;
    /**
     * Transform inputs before logging on the root span.
     */
    processInputs?: (inputs: KVMap) => KVMap;
    /**
     * Transform outputs before logging on the root span.
     */
    processOutputs?: (outputs: KVMap) => KVMap;
    /**
     * Transform inputs before logging on child LLM step spans.
     */
    processChildLLMRunInputs?: (inputs: KVMap) => KVMap;
    /**
     * Transform outputs before logging on child LLM step spans.
     */
    processChildLLMRunOutputs?: (outputs: KVMap) => KVMap;
    /**
     * Whether to include intermediate step details in the output.
     */
    traceResponseMetadata?: boolean;
    /**
     * Whether to include raw HTTP request/response bodies.
     */
    traceRawHttp?: boolean;
    /**
     * Additional RunTree configuration to pass through.
     */
    extra?: KVMap;
    /**
     * Whether to enable tracing.
     * @default true if LANGSMITH_TRACING is set to "true"
     */
    tracingEnabled?: boolean;
}
/**
 * Creates a LangSmith `Telemetry` for the Vercel AI SDK.
 *
 * This adapter implements the Vercel AI SDK's `Telemetry` interface
 * and maps lifecycle events to LangSmith traces. It creates a root span for
 * the entire generation, child LLM spans for each step, and tool spans for
 * tool calls.
 *
 * ```ts
 * import { generateText, registerTelemetry } from "ai";
 * import { LangSmithTelemetry } from "langsmith/experimental/vercel";
 *
 * registerTelemetry(LangSmithTelemetry());
 *
 * const result = await generateText({
 *   model: openai("gpt-4o"),
 *   prompt: "Hello!",
 * });
 * ```
 *
 * @experimental Only available in Vercel AI SDK 7.
 */
export declare function LangSmithTelemetry(config?: LangSmithTelemetryConfig): any;
//# sourceMappingURL=telemetry.d.mts.map