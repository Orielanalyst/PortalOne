import { LsAgentType } from "../../utils/ls_agent_type.js";
export declare function resolveVercelLsAgentType(parentRunTree?: unknown): LsAgentType | undefined;
export declare function vercelLsAgentTypeMetadata(parentRunTree?: unknown): {
    ls_agent_type?: LsAgentType;
};
//# sourceMappingURL=_agent_type.d.ts.map