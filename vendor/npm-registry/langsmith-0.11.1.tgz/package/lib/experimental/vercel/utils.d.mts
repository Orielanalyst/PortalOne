import type { LanguageModelV2DataContent, LanguageModelV2Usage, SharedV2ProviderMetadata } from "@ai-sdk/provider";
import { RunTree } from "../../run_trees.mjs";
type AISDKDataContent = string | Uint8Array | ArrayBuffer | Buffer;
type AISDKProviderReference = {
    [provider: string]: string;
} & {
    type?: never;
};
type AISDKFileData = {
    type: "data";
    data: AISDKDataContent;
} | {
    type: "url";
    url: URL;
} | {
    type: "reference";
    reference: AISDKProviderReference;
} | {
    type: "text";
    text: string;
};
export declare const normalizeFileDataAsDataURL: (fileData: AISDKFileData | AISDKDataContent | LanguageModelV2DataContent | AISDKProviderReference | URL, mimeType: string | undefined) => string;
export declare const convertMessageToTracedFormat: (rawMessage: Record<string, unknown>, responseMetadata?: Record<string, unknown>) => Record<string, unknown>;
export declare const setUsageMetadataOnRunTree: (result: {
    usage?: LanguageModelV2Usage;
    providerMetadata?: SharedV2ProviderMetadata;
}, runTree: RunTree) => void;
export {};
//# sourceMappingURL=utils.d.mts.map