import type { SDKMessage } from "./types.mjs";
export declare function extractUsageFromMessage(message: SDKMessage): Record<string, unknown>;
//# sourceMappingURL=usage.d.mts.map