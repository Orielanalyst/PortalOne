/** (beta) An agent environment. */
export type Environment = "local" | "development" | "staging" | "production";
/** (beta) The address of an agent's environment. */
export interface AgentAddress {
    kind: "AGENT";
    id: string;
    environment: Uppercase<Environment>;
}
/** (beta) Construct and validate an agent address; plain objects are also accepted. */
export declare class AgentAddress {
    constructor(id: string, environment: Environment | (string & {}));
}
/** (beta) The address of an experiment's tracing project. */
export interface ExperimentAddress {
    kind: "EXPERIMENT";
    id: string;
}
/** (beta) Construct and validate an experiment address. */
export declare class ExperimentAddress {
    constructor(id: string);
}
/** (beta) The address of the workspace's shared evaluators project. */
export interface EvaluatorAddress {
    kind: "EVALUATOR";
}
/** (beta) Construct the workspace's evaluators address. */
export declare class EvaluatorAddress {
    constructor();
}
/** (beta) A feature that holds traces in a tracing project. */
export type Address = AgentAddress | ExperimentAddress | EvaluatorAddress;
/** (beta) An address as the resolve endpoint takes it. */
export type ApiAddress = Address;
/** (beta) The `LANGSMITH_AGENT_*` / project env vars name half an address, or both. */
export declare class EnvAddressError extends Error {
    constructor(message: string);
}
/** Validate an address at an SDK entrypoint and return a normalized copy. */
export declare function ensureAddress<K extends Address["kind"]>(value: {
    kind: K;
    id?: unknown;
    environment?: unknown;
}): Extract<Address, {
    kind: K;
}>;
export declare function ensureAddress(value: unknown): Address | undefined;
export declare function ensureAgent(value: unknown): AgentAddress | undefined;
//# sourceMappingURL=address.d.ts.map