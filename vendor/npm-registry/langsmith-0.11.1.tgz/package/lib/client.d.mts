import type { OTELContext } from "./experimental/otel/types.mjs";
import { AsyncCallerParams } from "./utils/async_caller.mjs";
import { ComparativeExperiment, DataType, Dataset, DatasetDiffInfo, DatasetShareSchema, Example, ExampleCreate, ExampleUpdate, ExampleUpdateWithoutId, SparseExample, Feedback, FeedbackConfig, FeedbackIngestToken, KVMap, LangChainBaseMessage, LangSmithSettings, LikePromptResponse, Prompt, PromptCommit, PromptSortField, Run, RunCreate, RunUpdate, ScoreType, TimeDelta, TracerSession, TracerSessionResult, ValueType, AnnotationQueue, RunWithAnnotationQueueInfo, Attachments, UploadExamplesResponse, UpdateExamplesResponse, DatasetVersion, AnnotationQueueWithDetails, AnnotationQueueRubricItem, RunKey, FeedbackConfigSchema, AgentContext, SkillContext, Entry } from "./schemas.mjs";
import { type TracingMode } from "./utils/env.mjs";
import { EvaluationResult, EvaluationResults } from "./evaluation/evaluator.mjs";
import { OnlineEvaluators as Evaluators } from "../resources/online-evaluators.mjs";
import { Runs as OpenAPIRuns } from "../resources/runs.mjs";
import { Sandboxes } from "../resources/sandboxes/sandboxes.mjs";
import { Datasets } from "../resources/datasets/datasets.mjs";
import { AnnotationQueues } from "../resources/annotation-queues/annotation-queues.mjs";
import { Agents } from "../resources/agents.mjs";
import { Threads } from "../resources/threads.mjs";
import { Traces } from "../resources/traces.mjs";
import { Sessions } from "../resources/sessions.mjs";
import { Public } from "../resources/public/public.mjs";
import { type Address, type AgentAddress } from "./address.mjs";
import { PromptCache } from "./utils/prompt_cache/index.mjs";
import { ProfileAuth } from "./utils/profiles.mjs";
export interface ClientConfig {
    apiUrl?: string;
    apiKey?: string;
    callerOptions?: AsyncCallerParams;
    timeout_ms?: number;
    webUrl?: string;
    /**
     * A function applied for masking serialized run inputs, outputs and
     * metadata, before sending to the API. Can be called with raw inputs, raw
     * outputs, raw metadata, or a nested `{ error: string }` object for errors.
     *
     * If a `hideInputs`, `hideOutputs` or `hideMetadata` function is present,
     * the client will call it instead of the anonymizer as appropriate.
     */
    anonymizer?: (values: KVMap) => KVMap | Promise<KVMap>;
    hideInputs?: boolean | ((inputs: KVMap) => KVMap | Promise<KVMap>);
    hideOutputs?: boolean | ((outputs: KVMap) => KVMap | Promise<KVMap>);
    hideMetadata?: boolean | ((metadata: KVMap) => KVMap | Promise<KVMap>);
    /**
     * Whether to omit runtime information from traced runs.
     * If true, runtime information (SDK version, platform, etc.) and
     * LangChain environment variable metadata will not be stored in runs.
     * Defaults to false.
     */
    omitTracedRuntimeInfo?: boolean;
    autoBatchTracing?: boolean;
    /** Maximum size of a batch of runs in bytes. */
    batchSizeBytesLimit?: number;
    /** Maximum number of operations to batch in a single request. */
    batchSizeLimit?: number;
    /**
     * Maximum total memory (in bytes) for both the AutoBatchQueue and batchIngestCaller queue.
     * When exceeded, runs/batches are dropped. Defaults to 1GB.
     */
    maxIngestMemoryBytes?: number;
    blockOnRootRunFinalization?: boolean;
    traceBatchConcurrency?: number;
    fetchOptions?: RequestInit;
    /**
     * Whether to require manual .flush() calls before sending traces.
     * Useful if encountering network rate limits at trace high volumes.
     */
    manualFlushMode?: boolean;
    tracingSamplingRate?: number;
    /**
     * Enable debug mode for the client. If set, all sent HTTP requests will be logged.
     */
    debug?: boolean;
    /**
     * The workspace ID. Required for org-scoped API keys.
     */
    workspaceId?: string;
    /**
     * Custom fetch implementation. Useful for testing.
     */
    fetchImplementation?: typeof fetch;
    /**
     * Disable prompt caching for this client.
     * By default, prompt caching is enabled globally.
     */
    disablePromptCache?: boolean;
    /**
     * Where to send traces.  One of:
     *
     * - `"langsmith"` (default) — LangSmith REST API only.
     * - `"otel"` — OpenTelemetry export only.
     *
     * Falls back to the `LANGSMITH_TRACING_MODE` env var, then to the
     * legacy `OTEL_ENABLED` / `LANGSMITH_OTEL_ENABLED` env vars, then to
     * `"langsmith"`.
     */
    tracingMode?: TracingMode;
    /**
     * Additional HTTP headers to include in all requests.
     * These headers will be merged with the default headers (User-Agent,
     * x-api-key, x-tenant-id, etc.). Custom headers will not override
     * the default required headers.
     */
    headers?: Record<string, string>;
    /**
     * @deprecated Use `configureGlobalPromptCache()` to configure caching, or
     * `disablePromptCache: true` to disable it. This parameter is deprecated.
     *
     * Configuration for caching. Can be:
     * - `true`: Enable caching with default settings (uses global singleton)
     * - `Cache`/`PromptCache` instance: Use custom cache configuration
     * - `false`: Disable caching (equivalent to `disablePromptCache: true`)
     *
     * @example
     * ```typescript
     * import { Client, Cache, configureGlobalPromptCache } from "langsmith";
     *
     * // Enable with defaults
     * const client1 = new Client({});
     *
     * // Or use custom configuration
     * import { configureGlobalPromptCache } from "langsmith";
     * configureGlobalPromptCache({
     *   maxSize: 100,
     *   ttlSeconds: 3600, // 1 hour, or null for infinite TTL
     * });
     * const client2 = new Client({});
     *
     * // Or disable for a specific client
     * const client3 = new Client({ disablePromptCache: true });
     * ```
     */
    cache?: boolean | PromptCache;
}
/**
 * Represents the parameters for listing runs (spans) from the Langsmith server.
 */
interface ListRunsParams {
    /**
     * The ID or IDs of the project(s) to filter by.
     */
    projectId?: string | string[];
    /**
     * The name or names of the project(s) to filter by.
     */
    projectName?: string | string[];
    /**
     * The ID of the trace to filter by.
     */
    traceId?: string;
    /**
     * isRoot - Whether to only include root runs.
     *  */
    isRoot?: boolean;
    /**
     * The execution order to filter by.
     */
    executionOrder?: number;
    /**
     * The ID of the parent run to filter by.
     */
    parentRunId?: string;
    /**
     * The order by run start date
     */
    order?: "asc" | "desc";
    /**
     * The ID of the reference example to filter by.
     */
    referenceExampleId?: string;
    /**
     * The start time to filter by.
     */
    startTime?: Date;
    /**
     * The run type to filter by.
     */
    runType?: string;
    /**
     * Indicates whether to filter by error runs.
     */
    error?: boolean;
    /**
     * The ID or IDs of the runs to filter by.
     */
    id?: string[];
    /**
     * The maximum number of runs to retrieve.
     */
    limit?: number;
    /**
     * The query string to filter by.
     */
    query?: string;
    /**
     * The filter string to apply.
     *
     * Run Filtering:
     * Listing runs with query params is useful for simple queries, but doesn't support many common needs, such as filtering by metadata, tags, or other fields.
     * LangSmith supports a filter query language to permit more complex filtering operations when fetching runs. This guide will provide a high level overview of the grammar as well as a few examples of when it can be useful.
     * If you'd prefer a more visual guide, you can get a taste of the language by viewing the table of runs on any of your projects' pages. We provide some recommended filters to get you started that you can copy and use the SDK.
     *
     * Grammar:
     * The filtering grammar is based on common comparators on fields in the run object. Supported comparators include:
     * - gte (greater than or equal to)
     * - gt (greater than)
     * - lte (less than or equal to)
     * - lt (less than)
     * - eq (equal to)
     * - neq (not equal to)
     * - has (check if run contains a tag or metadata json blob)
     * - search (search for a substring in a string field)
     */
    filter?: string;
    /**
     * Filter to apply to the ROOT run in the trace tree. This is meant to be used in conjunction with the regular
     *  `filter` parameter to let you filter runs by attributes of the root run within a trace. Example is filtering by
     * feedback assigned to the trace.
     */
    traceFilter?: string;
    /**
     * Filter to apply to OTHER runs in the trace tree, including sibling and child runs. This is meant to be used in
     * conjunction with the regular `filter` parameter to let you filter runs by attributes of any run within a trace.
     */
    treeFilter?: string;
    /**
     * The values to include in the response.
     *
     * Note: The 'child_run_ids' value is deprecated and will be removed in a future version.
     * This field is no longer populated by the API.
     */
    select?: string[];
}
interface GroupRunsParams {
    /**
     * The ID or IDs of the project(s) to filter by.
     */
    projectId?: string;
    /**
     * The ID or IDs of the project(s) to filter by.
     */
    projectName?: string;
    /**
     * @example "conversation"
     */
    groupBy: string;
    /**
     * The filter string to apply.
     *
     * Run Filtering:
     * Listing runs with query params is useful for simple queries, but doesn't support many common needs, such as filtering by metadata, tags, or other fields.
     * LangSmith supports a filter query language to permit more complex filtering operations when fetching runs. This guide will provide a high level overview of the grammar as well as a few examples of when it can be useful.
     * If you'd prefer a more visual guide, you can get a taste of the language by viewing the table of runs on any of your projects' pages. We provide some recommended filters to get you started that you can copy and use the SDK.
     *
     * Grammar:
     * The filtering grammar is based on common comparators on fields in the run object. Supported comparators include:
     * - gte (greater than or equal to)
     * - gt (greater than)
     * - lte (less than or equal to)
     * - lt (less than)
     * - eq (equal to)
     * - neq (not equal to)
     * - has (check if run contains a tag or metadata json blob)
     * - search (search for a substring in a string field)
     */
    filter?: string;
    /**
     * The start time to filter by.
     */
    startTime?: Date;
    /**
     * The end time to filter by.
     */
    endTime?: Date;
    /**
     * The maximum number of runs to retrieve.
     */
    limit?: number;
    /**
     * The maximum number of runs to retrieve.
     */
    offset?: number;
}
export interface ReadThreadParams {
    threadId: string;
    projectId?: string;
    projectName?: string;
    isRoot?: boolean;
    limit?: number;
    filter?: string;
    order?: "asc" | "desc";
}
export interface ListThreadsParams {
    projectId?: string;
    projectName?: string;
    limit?: number;
    offset?: number;
    filter?: string;
    startTime?: Date;
    isRoot?: boolean;
}
interface UploadCSVParams {
    csvFile: Blob;
    fileName: string;
    inputKeys: string[];
    outputKeys: string[];
    description?: string;
    dataType?: DataType;
    name?: string;
}
interface feedback_source {
    type: string;
    metadata?: KVMap;
}
interface FeedbackCreate {
    id: string;
    run_id: string | null;
    trace_id?: string;
    key: string;
    score?: ScoreType;
    value?: ValueType;
    correction?: object | null;
    comment?: string | null;
    feedback_source?: feedback_source | KVMap | null;
    feedbackConfig?: FeedbackConfig;
    session_id?: string;
    start_time?: number | string;
    comparative_experiment_id?: string;
    extend_trace_retention?: boolean;
    /** Agent address as an LRN string. */
    address?: string;
}
type DefaultClientConfig = {
    apiUrl: string;
    apiUrlSource: string;
    apiKey?: string;
    webUrl?: string;
    hideInputs?: boolean;
    hideOutputs?: boolean;
    hideMetadata?: boolean;
    workspaceId?: string;
    oauthAccessToken?: string;
    oauthRefreshToken?: string;
    profileAuth?: ProfileAuth;
};
interface CreateRunParams {
    name: string;
    inputs: KVMap;
    run_type: string;
    id?: string;
    start_time?: number | string;
    end_time?: number | string;
    extra?: KVMap;
    error?: string;
    serialized?: object;
    outputs?: KVMap;
    reference_example_id?: string;
    child_runs?: RunCreate[];
    parent_run_id?: string;
    project_name?: string;
    /** (beta) Send the run to this address instead of a project. */
    address?: AgentAddress;
    revision_id?: string;
    trace_id?: string;
    dotted_order?: string;
    attachments?: Attachments;
}
interface ProjectOptions {
    projectName?: string;
    projectId?: string;
}
type RecordStringAny = Record<string, any>;
export type FeedbackSourceType = "model" | "api" | "app";
export type CreateFeedbackOptions = {
    /** The metric name, tag, or aspect to provide feedback on. */
    key: string;
    score?: ScoreType;
    value?: ValueType;
    correction?: object;
    comment?: string;
    sourceInfo?: object;
    feedbackSourceType?: FeedbackSourceType;
    feedbackConfig?: FeedbackConfig;
    sourceRunId?: string;
    feedbackId?: string;
    /**
     * Highly recommended. The trace the run belongs to (equals `runId` for a root run).
     * When set, the feedback is batched and sent in the background; call
     * `awaitPendingTraceBatches()` to wait for delivery.
     */
    traceId?: string;
    comparativeExperimentId?: string;
    /**
     * The run's start time, ISO string or epoch ms. Better performance if provided.
     */
    startTime?: number | string;
    /** If false, create feedback without extending the trace's retention tier. */
    extendTraceRetention?: boolean;
};
/** @deprecated Pass all params within an object and populate sessionId. */
export type CreateFeedbackLegacyOptions = Omit<CreateFeedbackOptions, "key"> & {
    /** @deprecated This option is no longer used. */
    eager?: boolean;
    /**
     * The session (project) ID of the run. Required for run-level feedback;
     * omitting it is deprecated. See
     * https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#feedback-create
     */
    sessionId?: string;
    /** The project (or experiment) to provide feedback on, for session-level feedback. */
    projectId?: string;
};
export type CreateFeedbackParams = CreateFeedbackOptions & ({
    /** The run to provide feedback on. */
    runId: string;
    /** The session (project) ID of the run. */
    sessionId: string;
    projectId?: never;
    address?: never;
} | {
    /** The run to provide feedback on. */
    runId: string;
    /** (beta) The address the run was sent to, e.g. `runTree.address`. */
    address: AgentAddress;
    sessionId?: never;
    projectId?: never;
} | {
    runId?: null;
    /** The project (or experiment) to provide feedback on. */
    projectId: string;
    sessionId?: never;
    address?: never;
});
export type CreateExampleOptions = {
    /** The ID of the dataset to create the example in. */
    datasetId?: string;
    /** The name of the dataset to create the example in (if dataset ID is not provided). */
    datasetName?: string;
    /** The creation date of the example. */
    createdAt?: Date;
    /** A unique identifier for the example. */
    exampleId?: string;
    /** Additional metadata associated with the example. */
    metadata?: KVMap;
    /** The split(s) to assign the example to. */
    split?: string | string[];
    /** The ID of the source run associated with this example. */
    sourceRunId?: string;
    /** Whether to use the inputs and outputs from the source run. */
    useSourceRunIO?: boolean;
    /** Which attachments from the source run to use. */
    useSourceRunAttachments?: string[];
    /** Attachments for the example */
    attachments?: Attachments;
};
export type CreateProjectParams = {
    projectName: string;
    description?: string | null;
    metadata?: RecordStringAny | null;
    upsert?: boolean;
    projectExtra?: RecordStringAny | null;
    referenceDatasetId?: string | null;
    numExamples?: number | null;
    numRepetitions?: number | null;
    evaluatorKeys?: string[] | null;
    tagValueIds?: string[] | null;
};
type AutoBatchQueueItem = {
    action: "create" | "update" | "feedback";
    item: RunCreate | RunUpdate | FeedbackCreate;
    otelContext?: OTELContext;
    apiKey?: string;
    apiUrl?: string;
    workspaceId?: string;
    size?: number;
};
type Thread = {
    filter: string;
    count: number;
    total_tokens: number;
    total_cost: number | null;
    min_start_time: string;
    max_start_time: string;
    latency_p50: number;
    latency_p99: number;
    feedback_stats: any | null;
    thread_id: string;
    first_inputs: string;
    last_outputs: string;
    last_error: string | null;
};
/** Item returned by {@link Client.listThreads}. */
export interface ListThreadsItem extends Thread {
    runs: Run[];
}
export declare function mergeRuntimeEnvIntoRun<T extends RunCreate | RunUpdate>(run: T, cachedEnvVars?: Record<string, string>, omitTracedRuntimeInfo?: boolean, tracingSampleRate?: number): T;
export declare function _checkBackendVersion(backendVersion: string, minVersion: string): void;
export declare const DEFAULT_UNCOMPRESSED_BATCH_SIZE_LIMIT_BYTES: number;
/** Default maximum memory (1GB) for queue size limits. */
export declare const DEFAULT_MAX_SIZE_BYTES: number;
export declare class AutoBatchQueue {
    items: {
        action: AutoBatchQueueItem["action"];
        payload: AutoBatchQueueItem["item"];
        otelContext?: OTELContext;
        itemPromiseResolve: () => void;
        itemPromise: Promise<void>;
        size: number;
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
    }[];
    sizeBytes: number;
    private maxSizeBytes;
    constructor(maxSizeBytes?: number);
    peek(): {
        action: AutoBatchQueueItem["action"];
        payload: AutoBatchQueueItem["item"];
        otelContext?: OTELContext;
        itemPromiseResolve: () => void;
        itemPromise: Promise<void>;
        size: number;
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
    };
    push(item: AutoBatchQueueItem): Promise<void>;
    pop({ upToSizeBytes, upToSize, }: {
        upToSizeBytes: number;
        upToSize: number;
    }): [AutoBatchQueueItem[], () => void];
}
export declare class Client implements LangSmithTracingClientInterface {
    private apiKey?;
    private apiUrl;
    private webUrl?;
    private workspaceId?;
    private caller;
    private batchIngestCaller;
    private timeout_ms;
    private _tenantId;
    private hideInputs?;
    private hideOutputs?;
    private hideMetadata?;
    private anonymizer?;
    private omitTracedRuntimeInfo?;
    private tracingSampleRate?;
    private autoBatchTracing;
    private autoBatchQueue;
    private autoBatchTimeout;
    private autoBatchAggregationDelayMs;
    private batchSizeBytesLimit?;
    private batchSizeLimit?;
    /** `config.fetchOptions` without its `headers`, which are merged separately. */
    private fetchOptions;
    private _fetchOptionsHeaders;
    private _openAPIClient?;
    private _openAPIClientSignature?;
    private settings;
    private blockOnRootRunFinalization;
    private traceBatchConcurrency;
    private _serverInfo;
    private _getServerInfoPromise?;
    private _stainlessVersionsChecked;
    private manualFlushMode;
    private _serializeWorker?;
    /**
     * Tracks in-flight drainAutoBatchQueue promises so awaitPendingTraceBatches
     * can wait on them even if the flush involves async work (worker-thread
     * serialize) that hasn't yet registered with batchIngestCaller.queue.
     */
    private _pendingDrains;
    private langSmithToOTELTranslator?;
    private _tracingMode;
    get tracingMode(): TracingMode;
    private fetchImplementation?;
    private cachedLSEnvVarsForMetadata?;
    private _promptCache?;
    private profileAuth?;
    private get _fetch();
    private getProfileManagedAuthorizationHeader;
    private isProfileManagedAuthorizationHeader;
    private hasExplicitAuthHeader;
    private applyCurrentAuthHeaders;
    /**
     * Serialize a payload for tracing, optionally offloading the work to a
     * Node worker thread when the runtime supports worker_threads.
     *
     * Falls back to synchronous serialization when:
     *  - manualFlushMode is enabled (serverless: worker boot cost > benefit)
     *  - worker_threads is unavailable (non-Node runtimes)
     *  - the payload contains values that can't be structured-cloned across
     *    threads (functions, non-cloneable class instances, streams, etc.)
     *  - the worker throws for any other reason
     *
     * In all fallback cases the returned bytes are identical to the sync path.
     */
    private _trackDrain;
    private _serializeBody;
    private multipartStreamingDisabled;
    private _multipartDisabled;
    private _runCompressionDisabled;
    private failedTracesDir;
    private failedTracesMaxBytes;
    private static _fallbackDirsCreated;
    private _customHeaders;
    debug: boolean;
    constructor(config?: ClientConfig);
    static getDefaultClientConfig(): DefaultClientConfig;
    getHostUrl(): string;
    /**
     * The headers this client sets from its own config, which a caller-supplied
     * header must not replace.
     *
     * Only what the client *actually* supplies: passing an explicit `Authorization`
     * or `x-api-key` header with no configured credential is a supported way to
     * authenticate (see `hasExplicitAuthHeader`), so those must survive.
     */
    private get _sdkControlledHeaders();
    /**
     * Headers supplied by the caller, through either `config.headers` or
     * `config.fetchOptions.headers`, with the ones this SDK sets removed.
     *
     * `_customHeaders` is normalized here rather than at assignment because it is
     * public and mutable: `get headers` hands back the caller's own object, so its
     * contents can change (and can become malformed) at any point.
     */
    private get _callerHeaders();
    private get _mergedHeaders();
    /**
     * The options to build the generated client with: its auth, and the headers
     * it should send on every request.
     *
     * The generated client applies `defaultHeaders` *after* its own auth headers,
     * so the ones this SDK sets are already dropped from `_callerHeaders` to keep
     * the precedence of `_mergedHeaders`, where required headers win.
     */
    private get _openAPIClientOptions();
    /**
     * Get or set custom headers for the client.
     * Custom headers are merged with default headers (User-Agent, x-api-key, x-tenant-id).
     * Custom headers will not override the default required headers.
     */
    get headers(): Record<string, string>;
    set headers(value: Record<string, string> | undefined);
    private _getOpenAPIBaseUrl;
    /**
     * The generated OpenAPI client, rebuilt whenever its auth or headers change.
     *
     * The generated client captures `defaultHeaders` and `apiKey` when it is
     * built, while the handwritten paths recompute `_mergedHeaders` per request.
     * Rebuilding on change keeps the two halves from diverging when the inputs
     * move underneath us — a caller mutating the object returned by
     * `get headers`, or a profile whose auth header only becomes available after
     * its token is refreshed.
     */
    private get openAPIClient();
    private _newOpenAPIClient;
    private _getPlatformEndpointPath;
    get evaluators(): Evaluators;
    get runs(): OpenAPIRuns;
    /** Access the v2 sandboxes resource (registries, snapshots, boxes). */
    get sandboxes(): Sandboxes;
    /** Access the v2 datasets resource (experimentRuns, etc.). */
    get datasets(): Datasets;
    /** Access the annotation queues resource (runs, items). */
    get annotationQueues(): AnnotationQueues;
    /** Access the threads resource (query, stats, listTraces). */
    get threads(): Threads;
    /** Access the traces resource (query, listRuns). */
    get traces(): Traces;
    /**
     * (beta) Access the sessions resource, which resolves an address to the
     * project its traces go to: `client.sessions.resolve(address)`.
     */
    get sessions(): Sessions;
    /** Manage workspace registry agents and their tracing destinations. */
    get agents(): Agents;
    /** Access the public shared-run resource. */
    get public(): Public;
    private processInputs;
    private processOutputs;
    private processMetadata;
    /**
     * Apply the configured anonymizer to a run's error string.
     *
     * Unlike inputs/outputs, `error` is a plain string (an exception message or
     * traceback) that can carry credentials the user never explicitly logged --
     * e.g. an HTTP-client error whose message embeds an `Authorization` header.
     * The anonymizer is typed `(KVMap) => KVMap`, so the string is wrapped as
     * `{ error }`, scrubbed, and unwrapped. Mirrors the Python SDK's
     * `Client._hide_run_error`.
     *
     * TODO: Update anonymizer to always nest inputs/outputs/error for consistency
     */
    private processError;
    /**
     * Filter content from new_token events to prevent streaming LLM output
     * from being uploaded via events.
     */
    private _filterNewTokenEvents;
    private prepareRunCreateOrUpdateInputs;
    private _getResponse;
    private _get;
    private _getPaginated;
    private _getCursorPaginatedList;
    private _shouldSample;
    private _filterForSampling;
    private _getBatchSizeLimitBytes;
    /**
     * Get the maximum number of operations to batch in a single request.
     */
    private _getBatchSizeLimit;
    private _getDatasetExamplesMultiPartSupport;
    private drainAutoBatchQueue;
    /**
     * Persist a failed trace payload to a local fallback directory.
     *
     * Saves a self-contained JSON file containing the endpoint path, the HTTP
     * headers required for replay, and the base64-encoded request body.
     * Can be replayed later with a simple POST:
     *
     *   POST /<endpoint>
     *   Content-Type: <value from saved headers>
     *   [Content-Encoding: <value from saved headers>]
     *   <decoded body>
     */
    private static _writeTraceToFallbackDir;
    private _processBatch;
    private _sendBatchToOTELTranslator;
    private _maskRunMetadata;
    private _mergeRuntimeEnvAndMaskMetadata;
    private processRunOperation;
    protected _getServerInfo(): Promise<any>;
    private _checkStainlessVersion;
    protected _ensureServerInfo(): Promise<Record<string, any>>;
    _supportsSDBQuery(): Promise<boolean>;
    /**
     * Throw on SmithDB-only deployments, warn elsewhere. Call only when run-level
     * feedback has no sessionId.
     */
    private _checkFeedbackSessionId;
    protected _getSettings(): Promise<LangSmithSettings>;
    /**
     * Flushes current queued traces.
     */
    flush(): Promise<void>;
    private _cloneCurrentOTELContext;
    createRun(run: CreateRunParams, options?: {
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
    }): Promise<void>;
    /**
     * Batch ingest/upsert multiple runs in the Langsmith system.
     * @param runs
     */
    batchIngestRuns({ runCreates, runUpdates, }: {
        runCreates?: RunCreate[];
        runUpdates?: RunUpdate[];
    }, options?: {
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
        sizeBytes?: number;
    }): Promise<void>;
    private _postBatchIngestRuns;
    /**
     * Batch ingest/upsert multiple runs in the Langsmith system.
     * @param runs
     */
    multipartIngestRuns({ runCreates, runUpdates, feedbacks, }: {
        runCreates?: RunCreate[];
        runUpdates?: RunUpdate[];
        feedbacks?: FeedbackCreate[];
    }, options?: {
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
        useGzip?: boolean;
        sizeBytes?: number;
    }): Promise<void>;
    private _createNodeFetchBody;
    private _createMultipartStream;
    private _sendMultipartRequest;
    updateRun(runId: string, run: RunUpdate, options?: {
        apiKey?: string;
        apiUrl?: string;
        workspaceId?: string;
    }): Promise<void>;
    /** @deprecated Use `client.runs.retrieve()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-runs#runs-retrieve for the migration guide. Will be removed after Jan 31, 2027. */
    readRun(runId: string, { loadChildRuns }?: {
        loadChildRuns: boolean;
    }): Promise<Run>;
    /** @deprecated Use `client.runs.getURL()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-runs#runs-get-url for the migration guide. Will be removed after Jan 31, 2027. */
    getRunUrl({ runId, run, projectOpts, address: rawAddress, }: {
        runId?: string;
        run?: Run;
        projectOpts?: ProjectOptions;
        /**
         * (beta) An address that names the run's project, such as the
         * `AgentAddress` the run was sent to or an `ExperimentAddress`, for a run
         * that names no project. It is resolved to its project with one request,
         * which needs LangSmith 0.18 or later. It must name the project the run is
         * in. A run that carries its own `address` does not need it.
         */
        address?: Address;
    }): Promise<string>;
    /** The ID of the project an address names, with one request. */
    private _resolveAddress;
    private _loadChildRuns;
    /**
     * List runs from the LangSmith server.
     * @deprecated Use `client.runs.query()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-query-runs#runs-query for the migration guide. Will be removed after Jan 31, 2027.
     * @param projectId - The ID of the project to filter by.
     * @param projectName - The name of the project to filter by.
     * @param parentRunId - The ID of the parent run to filter by.
     * @param traceId - The ID of the trace to filter by.
     * @param referenceExampleId - The ID of the reference example to filter by.
     * @param startTime - The start time to filter by.
     * @param isRoot - Indicates whether to only return root runs.
     * @param runType - The run type to filter by.
     * @param error - Indicates whether to filter by error runs.
     * @param id - The ID of the run to filter by.
     * @param query - The query string to filter by.
     * @param filter - The filter string to apply to the run spans.
     * @param traceFilter - The filter string to apply on the root run of the trace.
     * @param treeFilter - The filter string to apply on other runs in the trace.
     * @param limit - The maximum number of runs to retrieve.
     * @returns {AsyncIterable<Run>} - The runs.
     *
     * @example
     * // List all runs in a project
     * const projectRuns = client.listRuns({ projectName: "<your_project>" });
     *
     * @example
     * // List LLM and Chat runs in the last 24 hours
     * const todaysLLMRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   start_time: new Date(Date.now() - 24 * 60 * 60 * 1000),
     *   run_type: "llm",
     * });
     *
     * @example
     * // List traces in a project
     * const rootRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   execution_order: 1,
     * });
     *
     * @example
     * // List runs without errors
     * const correctRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   error: false,
     * });
     *
     * @example
     * // List runs by run ID
     * const runIds = [
     *   "a36092d2-4ad5-4fb4-9c0d-0dba9a2ed836",
     *   "9398e6be-964f-4aa4-8ae9-ad78cd4b7074",
     * ];
     * const selectedRuns = client.listRuns({ run_ids: runIds });
     *
     * @example
     * // List all "chain" type runs that took more than 10 seconds and had `total_tokens` greater than 5000
     * const chainRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   filter: 'and(eq(run_type, "chain"), gt(latency, 10), gt(total_tokens, 5000))',
     * });
     *
     * @example
     * // List all runs called "extractor" whose root of the trace was assigned feedback "user_score" score of 1
     * const goodExtractorRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   filter: 'eq(name, "extractor")',
     *   traceFilter: 'and(eq(feedback_key, "user_score"), eq(feedback_score, 1))',
     * });
     *
     * @example
     * // List all runs that started after a specific timestamp and either have "error" not equal to null or a "Correctness" feedback score equal to 0
     * const complexRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   filter: 'and(gt(start_time, "2023-07-15T12:34:56Z"), or(neq(error, null), and(eq(feedback_key, "Correctness"), eq(feedback_score, 0.0))))',
     * });
     *
     * @example
     * // List all runs where `tags` include "experimental" or "beta" and `latency` is greater than 2 seconds
     * const taggedRuns = client.listRuns({
     *   projectName: "<your_project>",
     *   filter: 'and(or(has(tags, "experimental"), has(tags, "beta")), gt(latency, 2))',
     * });
     */
    listRuns(props: ListRunsParams): AsyncIterable<Run>;
    listGroupRuns(props: GroupRunsParams): AsyncIterable<Thread>;
    /** @deprecated Use `client.threads.listTraces()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-threads#threads-list-traces for the migration guide. Will be removed after Jan 31, 2027. */
    readThread(props: ReadThreadParams): AsyncIterable<Run>;
    /** @deprecated Use `client.threads.query()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-threads#threads-query for the migration guide. Will be removed after Jan 31, 2027. */
    listThreads(props: ListThreadsParams): Promise<ListThreadsItem[]>;
    getRunStats({ id, trace, parentRun, runType, projectNames, projectIds, referenceExampleIds, startTime, endTime, error, query, filter, traceFilter, treeFilter, isRoot, dataSourceType, }: {
        id?: string[];
        trace?: string;
        parentRun?: string;
        runType?: string;
        projectNames?: string[];
        projectIds?: string[];
        referenceExampleIds?: string[];
        startTime?: string;
        endTime?: string;
        error?: boolean;
        query?: string;
        filter?: string;
        traceFilter?: string;
        treeFilter?: string;
        isRoot?: boolean;
        dataSourceType?: string;
    }): Promise<any>;
    /** @deprecated Use `client.runs.share.create()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#share-and-read-public-runs for the migration guide. Will be removed after Jan 31, 2027. */
    shareRun(runId: string, { shareId }?: {
        shareId?: string;
    }): Promise<string>;
    /** @deprecated Use `client.runs.share.delete()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#share-and-read-public-runs for the migration guide. Will be removed after Jan 31, 2027. */
    unshareRun(runId: string): Promise<void>;
    /** @deprecated Use `client.runs.retrieve({ selects: ["SHARE_URL"] })` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#share-and-read-public-runs for the migration guide. Will be removed after Jan 31, 2027. */
    readRunSharedLink(runId: string): Promise<string | undefined>;
    /** @deprecated Use `client.public.runs.query()` instead. See https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#share-and-read-public-runs for the migration guide. Will be removed after Jan 31, 2027. */
    listSharedRuns(shareToken: string, { runIds, }?: {
        runIds?: string[];
    }): Promise<Run[]>;
    readDatasetSharedSchema(datasetId?: string, datasetName?: string): Promise<DatasetShareSchema>;
    shareDataset(datasetId?: string, datasetName?: string): Promise<DatasetShareSchema>;
    unshareDataset(datasetId: string): Promise<void>;
    readSharedDataset(shareToken: string): Promise<Dataset>;
    /**
     * Get shared examples.
     *
     * @param {string} shareToken The share token to get examples for. A share token is the UUID (or LangSmith URL, including UUID) generated when explicitly marking an example as public.
     * @param {Object} [options] Additional options for listing the examples.
     * @param {string[] | undefined} [options.exampleIds] A list of example IDs to filter by.
     * @returns {Promise<Example[]>} The shared examples.
     */
    listSharedExamples(shareToken: string, options?: {
        exampleIds?: string[];
    }): Promise<Example[]>;
    createProject({ projectName, description, metadata, upsert, projectExtra, referenceDatasetId, numExamples, numRepetitions, evaluatorKeys, tagValueIds, }: CreateProjectParams): Promise<TracerSession>;
    updateProject(projectId: string, { name, description, metadata, projectExtra, endTime, }: {
        name?: string | null;
        description?: string | null;
        metadata?: RecordStringAny | null;
        projectExtra?: RecordStringAny | null;
        endTime?: string | null;
    }): Promise<TracerSession>;
    hasProject({ projectId, projectName, }: {
        projectId?: string;
        projectName?: string;
    }): Promise<boolean>;
    readProject({ projectId, projectName, includeStats, }: {
        projectId?: string;
        projectName?: string;
        includeStats?: boolean;
    }): Promise<TracerSessionResult>;
    getProjectUrl({ projectId, projectName, }: {
        projectId?: string;
        projectName?: string;
    }): Promise<string>;
    getDatasetUrl({ datasetId, datasetName, }: {
        datasetId?: string;
        datasetName?: string;
    }): Promise<string>;
    private _getTenantId;
    listProjects({ projectIds, name, nameContains, referenceDatasetId, referenceDatasetName, includeStats, datasetVersion, referenceFree, metadata, }?: {
        projectIds?: string[];
        name?: string;
        nameContains?: string;
        referenceDatasetId?: string;
        referenceDatasetName?: string;
        includeStats?: boolean;
        datasetVersion?: string;
        referenceFree?: boolean;
        metadata?: RecordStringAny;
    }): AsyncIterable<TracerSessionResult>;
    deleteProject({ projectId, projectName, }: {
        projectId?: string;
        projectName?: string;
    }): Promise<void>;
    uploadCsv({ csvFile, fileName, inputKeys, outputKeys, description, dataType, name, }: UploadCSVParams): Promise<Dataset>;
    createDataset(name: string, { description, dataType, inputsSchema, outputsSchema, metadata, tagValueIds, }?: {
        description?: string;
        dataType?: DataType;
        inputsSchema?: KVMap;
        outputsSchema?: KVMap;
        metadata?: RecordStringAny;
        tagValueIds?: string[];
    }): Promise<Dataset>;
    readDataset({ datasetId, datasetName, }: {
        datasetId?: string;
        datasetName?: string;
    }): Promise<Dataset>;
    hasDataset({ datasetId, datasetName, }: {
        datasetId?: string;
        datasetName?: string;
    }): Promise<boolean>;
    diffDatasetVersions({ datasetId, datasetName, fromVersion, toVersion, }: {
        datasetId?: string;
        datasetName?: string;
        fromVersion: string | Date;
        toVersion: string | Date;
    }): Promise<DatasetDiffInfo>;
    readDatasetOpenaiFinetuning({ datasetId, datasetName, }: {
        datasetId?: string;
        datasetName?: string;
    }): Promise<any[]>;
    listDatasets({ limit, offset, datasetIds, datasetName, datasetNameContains, metadata, }?: {
        limit?: number;
        offset?: number;
        datasetIds?: string[];
        datasetName?: string;
        datasetNameContains?: string;
        metadata?: RecordStringAny;
    }): AsyncIterable<Dataset>;
    /**
     * Update a dataset
     * @param props The dataset details to update
     * @returns The updated dataset
     */
    updateDataset(props: {
        datasetId?: string;
        datasetName?: string;
        name?: string;
        description?: string;
    }): Promise<Dataset>;
    /**
     * Updates a tag on a dataset.
     *
     * If the tag is already assigned to a different version of this dataset,
     * the tag will be moved to the new version. The as_of parameter is used to
     * determine which version of the dataset to apply the new tags to.
     *
     * It must be an exact version of the dataset to succeed. You can
     * use the "readDatasetVersion" method to find the exact version
     * to apply the tags to.
     * @param params.datasetId The ID of the dataset to update. Must be provided if "datasetName" is not provided.
     * @param params.datasetName The name of the dataset to update. Must be provided if "datasetId" is not provided.
     * @param params.asOf The timestamp of the dataset to apply the new tags to.
     * @param params.tag The new tag to apply to the dataset.
     */
    updateDatasetTag(props: {
        datasetId?: string;
        datasetName?: string;
        asOf: string | Date;
        tag: string;
    }): Promise<void>;
    deleteDataset({ datasetId, datasetName, }: {
        datasetId?: string;
        datasetName?: string;
    }): Promise<void>;
    createExample(update: ExampleCreate): Promise<Example>;
    /**
     * @deprecated This signature is deprecated, use createExample(update: ExampleCreate) instead
     */
    createExample(inputs: KVMap, referenceOutputs: KVMap, options: CreateExampleOptions): Promise<Example>;
    createExamples(uploads: ExampleCreate[]): Promise<Example[]>;
    /** @deprecated Use the uploads-only overload instead */
    createExamples(props: {
        inputs?: Array<KVMap>;
        referenceOutputs?: Array<KVMap>;
        /** @deprecated Use referenceOutputs instead. */
        outputs?: Array<KVMap>;
        metadata?: Array<KVMap>;
        splits?: Array<string | Array<string>>;
        sourceRunIds?: Array<string>;
        useSourceRunIOs?: Array<boolean>;
        useSourceRunAttachments?: Array<string[]>;
        attachments?: Array<Attachments>;
        exampleIds?: Array<string>;
        datasetId?: string;
        datasetName?: string;
    }): Promise<Example[]>;
    createLLMExample(input: string, generation: string | undefined, options: CreateExampleOptions): Promise<Example>;
    createChatExample(input: KVMap[] | LangChainBaseMessage[], generations: KVMap | LangChainBaseMessage | undefined, options: CreateExampleOptions): Promise<Example>;
    readExample(exampleId: string): Promise<Example>;
    listExamples<Sparse extends boolean = false>({ datasetId, datasetName, exampleIds, asOf, splits, inlineS3Urls, metadata, limit, offset, filter, includeAttachments, select, excludeDefaultFields, }?: {
        datasetId?: string;
        datasetName?: string;
        exampleIds?: string[];
        asOf?: string | Date;
        splits?: string[];
        inlineS3Urls?: boolean;
        metadata?: KVMap;
        limit?: number;
        offset?: number;
        filter?: string;
        includeAttachments?: boolean;
        /** Fields to include in each example, such as "id" or "outputs". */
        select?: string[];
        /**
         * Return only the fields in `select`, plus `id`. Other default fields
         * (`created_at`, `modified_at`, `inputs`, `name`, `dataset_id`) are absent
         * unless selected. Rows are typed as `SparseExample` when this is `true`.
         */
        excludeDefaultFields?: Sparse;
    }): AsyncIterable<Sparse extends true ? SparseExample : Example>;
    deleteExample(exampleId: string): Promise<void>;
    /**
     * Delete multiple examples by ID.
     * @param exampleIds - The IDs of the examples to delete
     * @param options - Optional settings for deletion
     * @param options.hardDelete - If true, permanently delete examples. If false (default), soft delete them.
     */
    deleteExamples(exampleIds: string[], options?: {
        hardDelete?: boolean;
    }): Promise<void>;
    /**
     * @deprecated This signature is deprecated, use updateExample(update: ExampleUpdate) instead
     */
    updateExample(exampleId: string, update: ExampleUpdateWithoutId): Promise<object>;
    updateExample(update: ExampleUpdate): Promise<object>;
    updateExamples(update: ExampleUpdate[]): Promise<object>;
    /**
     * Get dataset version by closest date or exact tag.
     *
     * Use this to resolve the nearest version to a given timestamp or for a given tag.
     *
     * @param options The options for getting the dataset version
     * @param options.datasetId The ID of the dataset
     * @param options.datasetName The name of the dataset
     * @param options.asOf The timestamp of the dataset to retrieve
     * @param options.tag The tag of the dataset to retrieve
     * @returns The dataset version
     */
    readDatasetVersion({ datasetId, datasetName, asOf, tag, }: {
        datasetId?: string;
        datasetName?: string;
        asOf?: string | Date;
        tag?: string;
    }): Promise<DatasetVersion>;
    listDatasetSplits({ datasetId, datasetName, asOf, }: {
        datasetId?: string;
        datasetName?: string;
        asOf?: string | Date;
    }): Promise<string[]>;
    updateDatasetSplits({ datasetId, datasetName, splitName, exampleIds, remove, }: {
        datasetId?: string;
        datasetName?: string;
        splitName: string;
        exampleIds: string[];
        remove?: boolean;
    }): Promise<void>;
    createFeedback(params: CreateFeedbackParams): Promise<Feedback>;
    /** @deprecated Pass all params within an object and populate sessionId. */
    createFeedback(runId: string | null, key: string, options: CreateFeedbackLegacyOptions): Promise<Feedback>;
    private _canBatchFeedback;
    private _postFeedback;
    /** Sends batched feedback one request at a time when multipart is unavailable. */
    private _postFeedbacks;
    updateFeedback(feedbackId: string, { score, value, correction, comment, }: {
        score?: number | boolean | null;
        value?: number | boolean | string | object | null;
        correction?: object | null;
        comment?: string | null;
    }): Promise<void>;
    readFeedback(feedbackId: string): Promise<Feedback>;
    deleteFeedback(feedbackId: string): Promise<void>;
    listFeedback({ runIds, feedbackKeys, feedbackSourceTypes, }?: {
        runIds?: string[];
        feedbackKeys?: string[];
        feedbackSourceTypes?: FeedbackSourceType[];
    }): AsyncIterable<Feedback>;
    /**
     * Creates a presigned feedback token and URL.
     *
     * The token can be used to authorize feedback metrics without
     * needing an API key. This is useful for giving browser-based
     * applications the ability to submit feedback without needing
     * to expose an API key.
     *
     * @param runId The ID of the run.
     * @param feedbackKey The feedback key.
     * @param options Additional options for the token.
     * @param options.expiration The expiration time for the token.
     *
     * @returns A promise that resolves to a FeedbackIngestToken.
     */
    createPresignedFeedbackToken(runId: string, feedbackKey: string, { expiration, feedbackConfig, }?: {
        expiration?: string | TimeDelta;
        feedbackConfig?: FeedbackConfig;
    }): Promise<FeedbackIngestToken>;
    createComparativeExperiment({ name, experimentIds, referenceDatasetId, createdAt, description, metadata, id, }: {
        name: string;
        experimentIds: Array<string>;
        referenceDatasetId?: string;
        createdAt?: Date;
        description?: string;
        metadata?: Record<string, unknown>;
        id?: string;
    }): Promise<ComparativeExperiment>;
    /**
     * Retrieves a list of presigned feedback tokens for a given run ID.
     * @param runId The ID of the run.
     * @returns An async iterable of FeedbackIngestToken objects.
     */
    listPresignedFeedbackTokens(runId: string): AsyncIterable<FeedbackIngestToken>;
    _selectEvalResults(results: EvaluationResult | EvaluationResult[] | EvaluationResults): Array<EvaluationResult>;
    _logEvaluationFeedback(evaluatorResponse: EvaluationResult | EvaluationResult[] | EvaluationResults, run?: Run, sourceInfo?: {
        [key: string]: any;
    }, sessionId?: string): Promise<[results: EvaluationResult[], feedbacks: Feedback[]]>;
    logEvaluationFeedback(params: {
        evaluatorResponse: EvaluationResult | EvaluationResult[] | EvaluationResults;
        run: Run;
        projectId: string;
        sourceInfo?: {
            [key: string]: any;
        };
    }): Promise<EvaluationResult[]>;
    /** @deprecated Pass all params within an object and populate projectId. */
    logEvaluationFeedback(evaluatorResponse: EvaluationResult | EvaluationResult[] | EvaluationResults, run?: Run, sourceInfo?: {
        [key: string]: any;
    }, sessionId?: string): Promise<EvaluationResult[]>;
    /**
     * API for managing feedback configs
     */
    /**
     * Create a feedback configuration on the LangSmith API.
     *
     * This upserts: if an identical config already exists, it returns it.
     * If a conflicting config exists for the same key, a 400 error is raised.
     *
     * @param options - The options for creating a feedback config
     * @param options.feedbackKey - The unique key for this feedback config
     * @param options.feedbackConfig - The config specifying type, bounds, and categories
     * @param options.isLowerScoreBetter - Whether a lower score is better. When
     *   omitted, a key that already has configs keeps its direction, and a new
     *   key defaults to higher is better.
     * @param options.isEnforced - Create the key's enforced config, which sets
     *   the rules for the whole workspace. Requires the
     *   feedback-configs:manage-enforced permission, which workspace admins
     *   have. Fails if the key already has an enforced config.
     * @returns The created FeedbackConfigSchema object
     */
    createFeedbackConfig(options: {
        feedbackKey: string;
        feedbackConfig: FeedbackConfig;
        isLowerScoreBetter?: boolean;
        isEnforced?: boolean;
    }): Promise<FeedbackConfigSchema>;
    /**
     * List feedback configurations on the LangSmith API.
     * @param options - The options for listing feedback configs
     * @param options.feedbackKeys - Filter by specific feedback keys
     * @param options.nameContains - Filter by name substring
     * @param options.limit - The maximum number of configs to return
     * @returns An async iterator of FeedbackConfigSchema objects
     */
    listFeedbackConfigs(options?: {
        feedbackKeys?: string[];
        nameContains?: string;
        limit?: number;
    }): AsyncIterableIterator<FeedbackConfigSchema>;
    /**
     * Update a feedback configuration on the LangSmith API.
     * @param feedbackKey - The key of the feedback config to update
     * @param options - The options for updating the feedback config
     * @param options.feedbackConfig - The new feedback config
     * @param options.isLowerScoreBetter - Whether a lower score is better
     * @returns The updated FeedbackConfigSchema object
     */
    updateFeedbackConfig(feedbackKey: string, options?: {
        feedbackConfig?: FeedbackConfig;
        isLowerScoreBetter?: boolean;
    }): Promise<FeedbackConfigSchema>;
    /**
     * Delete a feedback configuration on the LangSmith API.
     * @param feedbackKey - The key of the feedback config to delete
     */
    deleteFeedbackConfig(feedbackKey: string): Promise<void>;
    /**
     * API for managing annotation queues
     */
    /**
     * List the annotation queues on the LangSmith API.
     * @param options - The options for listing annotation queues
     * @param options.queueIds - The IDs of the queues to filter by
     * @param options.name - The name of the queue to filter by
     * @param options.nameContains - The substring that the queue name should contain
     * @param options.limit - The maximum number of queues to return
     * @returns An iterator of AnnotationQueue objects
     */
    listAnnotationQueues(options?: {
        queueIds?: string[];
        name?: string;
        nameContains?: string;
        limit?: number;
    }): AsyncIterableIterator<AnnotationQueue>;
    /**
     * Create an annotation queue on the LangSmith API.
     * @param options - The options for creating an annotation queue
     * @param options.name - The name of the annotation queue
     * @param options.description - The description of the annotation queue
     * @param options.queueId - The ID of the annotation queue
     * @returns The created AnnotationQueue object
     */
    createAnnotationQueue(options: {
        name: string;
        description?: string;
        queueId?: string;
        rubricInstructions?: string;
        rubricItems?: AnnotationQueueRubricItem[];
    }): Promise<AnnotationQueueWithDetails>;
    /**
     * Read an annotation queue with the specified queue ID.
     * @param queueId - The ID of the annotation queue to read
     * @returns The AnnotationQueueWithDetails object
     */
    readAnnotationQueue(queueId: string): Promise<AnnotationQueueWithDetails>;
    /**
     * Update an annotation queue with the specified queue ID.
     * @param queueId - The ID of the annotation queue to update
     * @param options - The options for updating the annotation queue
     * @param options.name - The new name for the annotation queue
     * @param options.description - The new description for the annotation queue
     */
    updateAnnotationQueue(queueId: string, options: {
        name?: string;
        description?: string;
        rubricInstructions?: string;
        rubricItems?: AnnotationQueueRubricItem[];
    }): Promise<void>;
    /**
     * Delete an annotation queue with the specified queue ID.
     * @param queueId - The ID of the annotation queue to delete
     */
    deleteAnnotationQueue(queueId: string): Promise<void>;
    /**
     * Add runs to an annotation queue with the specified queue ID.
     *
     * The second argument is either:
     * - `RunKey[]` (preferred): each entry carries the run's full lookup key, so
     *   it can be located directly without a scan. Required for workspaces served
     *   by SmithDB; routes to `POST /runs/by-key`.
     * - `string[]`: a plain list of run IDs. **Deprecated**: this path will be
     *   removed after Jan 31, 2027; prefer the key form. Routes to `POST /runs`.
     *   See https://docs.langchain.com/langsmith/smithdb-sdk-migration-feedback#annotation-queues-add-runs.
     *
     * If every element is a string (or the list is empty) it is treated as run
     * IDs; otherwise the list is treated as `RunKey` objects.
     *
     * @param queueId - The ID of the annotation queue
     * @param runs - Either a list of run IDs (deprecated) or a list of run keys.
     */
    addRunsToAnnotationQueue(queueId: string, runs: string[] | RunKey[]): Promise<void>;
    /**
     * Get a run from an annotation queue at the specified index.
     * @param queueId - The ID of the annotation queue
     * @param index - The index of the run to retrieve
     * @returns A Promise that resolves to a RunWithAnnotationQueueInfo object
     * @throws {Error} If the run is not found at the given index or for other API-related errors
     */
    getRunFromAnnotationQueue(queueId: string, index: number): Promise<RunWithAnnotationQueueInfo>;
    /**
     * List the runs in an annotation queue.
     * @param queueId - The ID of the annotation queue
     * @param options - The options for listing runs in the annotation queue
     * @param options.status - Filter runs by review status. If omitted, returns
     * runs across all review states.
     * @param options.limit - The maximum number of runs to return
     * @returns An iterator of RunWithAnnotationQueueInfo objects
     */
    listRunsFromAnnotationQueue(queueId: string, options?: {
        status?: "needs_my_review" | "needs_others_review" | "completed";
        limit?: number;
    }): AsyncIterableIterator<RunWithAnnotationQueueInfo>;
    /**
     * Delete a run from an an annotation queue.
     * @param queueId - The ID of the annotation queue to delete the run from
     * @param queueRunId - The ID of the run to delete from the annotation queue
     */
    deleteRunFromAnnotationQueue(queueId: string, queueRunId: string): Promise<void>;
    /**
     * Get the size of an annotation queue.
     * @param queueId - The ID of the annotation queue
     */
    getSizeFromAnnotationQueue(queueId: string): Promise<{
        size: number;
    }>;
    protected _currentTenantIsOwner(owner: string): Promise<boolean>;
    protected _ownerConflictError(action: string, owner: string): Promise<Error>;
    protected _getLatestCommitHash(promptOwnerAndName: string): Promise<string | undefined>;
    protected _createCommitTags(promptOwnerAndName: string, commitId: string, tags: string | string[]): Promise<void>;
    protected _likeOrUnlikePrompt(promptIdentifier: string, like: boolean): Promise<LikePromptResponse>;
    protected _getPromptUrl(promptIdentifier: string): Promise<string>;
    /**
     * Check if a prompt exists.
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     * @returns A Promise that resolves to true if the prompt exists, false otherwise
     * @example
     * ```typescript
     * // Check if a prompt exists before creating a commit
     * if (await client.promptExists("my-prompt")) {
     *   await client.createCommit("my-prompt", template);
     * } else {
     *   await client.createPrompt("my-prompt");
     * }
     * ```
     */
    promptExists(promptIdentifier: string): Promise<boolean>;
    /**
     * Like a prompt.
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     * @returns A Promise that resolves to the like response containing the updated like count
     * @example
     * ```typescript
     * // Like a prompt
     * const response = await client.likePrompt("owner/useful-prompt");
     * console.log(`Prompt now has ${response.likes} likes`);
     * ```
     */
    likePrompt(promptIdentifier: string): Promise<LikePromptResponse>;
    /**
     * Unlike a prompt (remove a previously added like).
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     * @returns A Promise that resolves to the like response containing the updated like count
     * @example
     * ```typescript
     * // Unlike a prompt
     * const response = await client.unlikePrompt("owner/useful-prompt");
     * console.log(`Prompt now has ${response.likes} likes`);
     * ```
     */
    unlikePrompt(promptIdentifier: string): Promise<LikePromptResponse>;
    /**
     * List all commits for a prompt.
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     *   - "promptName:commitHash" (commit hash is ignored, all commits are returned)
     * @returns An async iterable iterator of PromptCommit objects
     * @example
     * ```typescript
     * // List commits for a private prompt
     * for await (const commit of client.listCommits("my-prompt")) {
     *   console.log(commit);
     * }
     *
     * // List commits for a prompt with explicit owner
     * for await (const commit of client.listCommits("owner/my-prompt")) {
     *   console.log(commit);
     * }
     * ```
     */
    listCommits(promptIdentifier: string): AsyncIterableIterator<PromptCommit>;
    /**
     * List prompts by filter.
     * @param options - Optional filters for listing prompts
     * @param options.isPublic - Filter by public/private prompts. If undefined, returns all prompts.
     * @param options.isArchived - Filter by archived status. Defaults to false (non-archived prompts only).
     * @param options.sortField - Field to sort by. Defaults to "updated_at".
     * @param options.query - Search query to filter prompts by name or description.
     * @returns An async iterable iterator of Prompt objects
     * @example
     * ```typescript
     * // List all prompts
     * for await (const prompt of client.listPrompts()) {
     *   console.log(prompt);
     * }
     *
     * // List only public prompts
     * for await (const prompt of client.listPrompts({ isPublic: true })) {
     *   console.log(prompt);
     * }
     *
     * // Search for prompts
     * for await (const prompt of client.listPrompts({ query: "translation" })) {
     *   console.log(prompt);
     * }
     * ```
     */
    listPrompts(options?: {
        isPublic?: boolean;
        isArchived?: boolean;
        sortField?: PromptSortField;
        query?: string;
    }): AsyncIterableIterator<Prompt>;
    /**
     * Get a prompt by its identifier.
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     *   - "promptName:commitHash" (commit hash is ignored, latest version is returned)
     * @returns A Promise that resolves to the Prompt object, or null if not found
     * @example
     * ```typescript
     * // Get a private prompt
     * const prompt = await client.getPrompt("my-prompt");
     *
     * // Get a public prompt
     * const publicPrompt = await client.getPrompt("owner/public-prompt");
     * ```
     */
    getPrompt(promptIdentifier: string): Promise<Prompt | null>;
    /**
     * Create a new prompt.
     * @param promptIdentifier - The identifier for the new prompt. Can be in the format:
     *   - "promptName" (creates a private prompt)
     *   - "owner/promptName" (creates a prompt under a specific owner, must match your tenant)
     * @param options - Optional configuration for the prompt
     * @param options.description - A description of the prompt
     * @param options.readme - Markdown content for the prompt's README
     * @param options.tags - Array of tags to categorize the prompt
     * @param options.isPublic - Whether the prompt should be public. Requires a LangChain Hub handle.
     * @returns A Promise that resolves to the created Prompt object
     * @throws {Error} If creating a public prompt without a LangChain Hub handle, or if owner doesn't match current tenant
     * @example
     * ```typescript
     * // Create a private prompt
     * const prompt = await client.createPrompt("my-new-prompt", {
     *   description: "A prompt for translations",
     *   tags: ["translation", "language"]
     * });
     *
     * // Create a public prompt
     * const publicPrompt = await client.createPrompt("my-public-prompt", {
     *   description: "A public translation prompt",
     *   isPublic: true
     * });
     * ```
     */
    createPrompt(promptIdentifier: string, options?: {
        description?: string;
        readme?: string;
        tags?: string[];
        isPublic?: boolean;
    }): Promise<Prompt>;
    /**
     * Create a new commit for an existing prompt.
     * @param promptIdentifier - The identifier of the prompt. Can be in the format:
     *   - "promptName" (for private prompts, owner defaults to "-")
     *   - "owner/promptName" (for prompts with explicit owner)
     * @param object - The prompt object/manifest to commit (e.g., ChatPromptTemplate, messages array, etc.)
     * @param options - Optional configuration for the commit
     * @param options.parentCommitHash - The parent commit hash. Defaults to "latest" (the most recent commit).
     * @param options.tags - A tag or list of tags to apply to the commit.
     * @param options.description - A description for the commit.
     * @returns A Promise that resolves to the URL of the newly created commit
     * @throws {Error} If the prompt does not exist
     * @example
     * ```typescript
     * import { ChatPromptTemplate } from "@langchain/core/prompts";
     *
     * // Create a commit with a new version of the prompt
     * const template = ChatPromptTemplate.fromMessages([
     *   ["system", "You are a helpful assistant."],
     *   ["human", "{input}"]
     * ]);
     *
     * const commitUrl = await client.createCommit("my-prompt", template);
     * console.log(`Commit created: ${commitUrl}`);
     *
     * // Create a commit with tags
     * const commitUrl2 = await client.createCommit("my-prompt", template, {
     *   tags: ["production", "v1"]
     * });
     * ```
     */
    createCommit(promptIdentifier: string, object: any, options?: {
        parentCommitHash?: string;
        tags?: string | string[];
        description?: string;
    }): Promise<string>;
    /**
     * Update examples with attachments using multipart form data.
     * @param updates List of ExampleUpdateWithAttachments objects to upsert
     * @returns Promise with the update response
     */
    updateExamplesMultipart(datasetId: string, updates?: ExampleUpdate[]): Promise<UpdateExamplesResponse>;
    private _updateExamplesMultipart;
    /**
     * Upload examples with attachments using multipart form data.
     * @param uploads List of ExampleUploadWithAttachments objects to upload
     * @returns Promise with the upload response
     * @deprecated This method is deprecated and will be removed in future LangSmith versions, please use `createExamples` instead
     */
    uploadExamplesMultipart(datasetId: string, uploads?: ExampleCreate[]): Promise<UploadExamplesResponse>;
    private _uploadExamplesMultipart;
    updatePrompt(promptIdentifier: string, options?: {
        description?: string;
        readme?: string;
        tags?: string[];
        isPublic?: boolean;
        isArchived?: boolean;
    }): Promise<Record<string, any>>;
    deletePrompt(promptIdentifier: string): Promise<void>;
    /**
     * Generate a cache key for a prompt.
     * Format: "{identifier}" or "{identifier}:with_model"
     */
    private _getPromptCacheKey;
    /**
     * Fetch a prompt commit directly from the API (bypassing cache).
     */
    private _fetchPromptFromApi;
    /**
     * Pull a prompt commit from the LangSmith API.
     *
     * Public prompts referenced by owner/name cross a trust boundary because the
     * prompt manifest may contain serialized LangChain objects and configuration
     * that affect runtime behavior. For example, a prompt can intentionally
     * configure a model with a custom base URL, headers, model name, or other
     * constructor arguments. These are supported features, but they also mean the
     * prompt contents should be treated as executable configuration rather than
     * plain text.
     *
     * Set `dangerouslyPullPublicPrompt: true` only after reviewing and trusting
     * the prompt contents, not merely the publishing account. Prompts from your
     * own or your organization's account can still be unsafe if that account or
     * prompt was compromised.
     *
     * When pulling a trusted external prompt, prefer pinning to a specific commit
     * rather than following a mutable latest version. Using `includeModel: true`
     * increases risk and should be avoided for public prompts or prompts outside
     * your own organization.
     */
    pullPromptCommit(promptIdentifier: string, options?: {
        includeModel?: boolean;
        skipCache?: boolean;
        /**
         * Set to `true` to allow pulling a public prompt by owner/name, for
         * example `username/promptname`. Defaults to `false`.
         */
        dangerouslyPullPublicPrompt?: boolean;
    }): Promise<PromptCommit>;
    /**
     * This method should not be used directly, use `import { pull } from "langchain/hub"` instead.
     * Using this method directly returns the JSON string of the prompt rather than a LangChain object.
     *
     * Public prompts referenced by owner/name cross a trust boundary because the
     * prompt manifest may contain serialized LangChain objects and configuration
     * that affect runtime behavior. For example, a prompt can intentionally
     * configure a model with a custom base URL, headers, model name, or other
     * constructor arguments. These are supported features, but they also mean the
     * prompt contents should be treated as executable configuration rather than
     * plain text.
     *
     * Set `dangerouslyPullPublicPrompt: true` only after reviewing and trusting
     * the prompt contents, not merely the publishing account. Prompts from your
     * own or your organization's account can still be unsafe if that account or
     * prompt was compromised.
     *
     * When pulling a trusted external prompt, prefer pinning to a specific commit
     * rather than following a mutable latest version. Using `includeModel: true`
     * increases risk and should be avoided for public prompts or prompts outside
     * your own organization.
     * @private
     */
    _pullPrompt(promptIdentifier: string, options?: {
        includeModel?: boolean;
        skipCache?: boolean;
        /**
         * Set to `true` to allow pulling a public prompt by owner/name, for
         * example `username/promptname`. Defaults to `false`.
         */
        dangerouslyPullPublicPrompt?: boolean;
    }): Promise<any>;
    pushPrompt(promptIdentifier: string, options?: {
        object?: any;
        parentCommitHash?: string;
        isPublic?: boolean;
        description?: string;
        readme?: string;
        tags?: string[];
        commitTags?: string | string[];
        commitDescription?: string;
    }): Promise<string>;
    /**
     * Check if an agent repo exists.
     */
    agentExists(identifier: string): Promise<boolean>;
    /**
     * Check if a skill repo exists.
     */
    skillExists(identifier: string): Promise<boolean>;
    /**
     * Pull an agent directory from Hub.
     * @param identifier The identifier (owner/name[:version]).
     * @param options.version Commit hash or tag; overrides identifier's version.
     */
    pullAgent(identifier: string, options?: {
        version?: string;
    }): Promise<AgentContext>;
    /**
     * Pull a skill directory from Hub.
     */
    pullSkill(identifier: string, options?: {
        version?: string;
    }): Promise<SkillContext>;
    /**
     * Push an agent to Hub. Creates the repo if missing, patches metadata if
     * provided, then commits the given files.
     * @returns The URL of the resulting commit.
     */
    pushAgent(identifier: string, options: {
        files: Record<string, Entry | null>;
        parentCommit?: string;
        description?: string;
        readme?: string;
        tags?: string[];
        isPublic?: boolean;
    }): Promise<string>;
    /**
     * Push a skill to Hub.
     */
    pushSkill(identifier: string, options: {
        files: Record<string, Entry | null>;
        parentCommit?: string;
        description?: string;
        readme?: string;
        tags?: string[];
        isPublic?: boolean;
    }): Promise<string>;
    /**
     * Delete an agent and all its owned child file repos.
     */
    deleteAgent(identifier: string): Promise<void>;
    /**
     * Delete a skill and all its owned child file repos.
     */
    deleteSkill(identifier: string): Promise<void>;
    /**
     * List agent repos. Yields one at a time, auto-paginating.
     */
    listAgents(options?: {
        isPublic?: boolean;
        isArchived?: boolean;
        query?: string;
    }): AsyncIterableIterator<Prompt>;
    /**
     * List skill repos. Yields one at a time, auto-paginating.
     */
    listSkills(options?: {
        isPublic?: boolean;
        isArchived?: boolean;
        query?: string;
    }): AsyncIterableIterator<Prompt>;
    private _listReposByType;
    private _pullDirectory;
    private _pushDirectory;
    private _deleteDirectory;
    private _repoExists;
    private _createRepo;
    private _updateRepoMetadata;
    /**
     * Clone a public dataset to your own langsmith tenant.
     * This operation is idempotent. If you already have a dataset with the given name,
     * this function will do nothing.
  
     * @param {string} tokenOrUrl The token of the public dataset to clone.
     * @param {Object} [options] Additional options for cloning the dataset.
     * @param {string} [options.sourceApiUrl] The URL of the langsmith server where the data is hosted. Defaults to the API URL of your current client.
     * @param {string} [options.datasetName] The name of the dataset to create in your tenant. Defaults to the name of the public dataset.
     * @returns {Promise<void>}
     */
    clonePublicDataset(tokenOrUrl: string, options?: {
        sourceApiUrl?: string;
        datasetName?: string;
    }): Promise<void>;
    private parseTokenOrUrl;
    /**
     * Cleanup resources held by the client.
     * Stops the cache's background refresh timer.
     */
    cleanup(): void;
    /**
     * Awaits all pending trace batches. Useful for environments where
     * you need to be sure that all tracing requests finish before execution ends,
     * such as serverless environments.
     *
     * @example
     * ```
     * import { Client } from "langsmith";
     *
     * const client = new Client();
     *
     * try {
     *   // Tracing happens here
     *   ...
     * } finally {
     *   await client.awaitPendingTraceBatches();
     * }
     * ```
     *
     * @returns A promise that resolves once all currently pending traces have sent.
     */
    awaitPendingTraceBatches(): Promise<void>;
    /**
     * Returns a string representation of the Client instance.
     * This method is called when the object is converted to a string
     * or logged, ensuring sensitive information like API keys is not exposed.
     *
     * @returns A string representation of the Client.
     */
    toString(): string;
}
export interface LangSmithTracingClientInterface {
    createRun: (run: CreateRunParams) => Promise<void>;
    updateRun: (runId: string, run: RunUpdate) => Promise<void>;
}
export {};
//# sourceMappingURL=client.d.mts.map