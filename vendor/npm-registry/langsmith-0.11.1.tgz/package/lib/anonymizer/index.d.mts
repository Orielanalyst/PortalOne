export interface StringNode {
    value: string;
    path: string;
}
export interface StringNodeProcessor {
    maskNodes: (nodes: StringNode[]) => StringNode[];
}
export interface StringNodeRule {
    type?: "pattern";
    pattern: RegExp | string;
    replace?: string;
}
export type ReplacerType = ((value: string, path?: string) => string) | StringNodeRule[] | StringNodeProcessor;
export declare function createAnonymizer(replacer: ReplacerType, options?: {
    maxDepth?: number;
}): <T>(data: T) => T;
/**
 * Replacement token written in place of detected secrets by
 * {@link DEFAULT_SECRET_RULES} / {@link createSecretAnonymizer}.
 */
export declare const SECRET_PLACEHOLDER = "[SECRET_DETECTED]";
/**
 * A curated, high-precision rule set for detecting common credentials in
 * traced data (prompts, tool inputs/outputs, file contents, shell commands).
 *
 * Designed to favor *low false positives* over exhaustive coverage:
 *  - Provider rules are anchored to well-known key prefixes.
 *  - Structural rules only fire when a sensitive *name* (api_key, token,
 *    password, …) is paired with an assignment/separator, so ordinary code,
 *    UUIDs, and hashes are left intact.
 *
 * This is NOT a port of gitleaks/secretlint; pattern shapes are drawn from
 * those projects (and provider docs) as a reference only. Every rule sets an
 * explicit `replace` because {@link createAnonymizer}'s default is
 * `[redacted]`, whereas the shared token here is {@link SECRET_PLACEHOLDER}.
 *
 * Patterns are written to port 1:1 to the Python SDK preset (no lookbehind).
 */
export declare const DEFAULT_SECRET_RULES: StringNodeRule[];
/**
 * Build an anonymizer pre-loaded with {@link DEFAULT_SECRET_RULES} suitable for
 * passing to `new Client({ anonymizer })`. It redacts detected secrets from run
 * inputs, outputs, and metadata client-side, before they are uploaded.
 *
 * @param options.extraRules - Additional rules appended after the defaults.
 * @param options.maxDepth - Max recursion depth (default 24; higher than
 *   `createAnonymizer`'s default of 10 because traced payloads nest deeply,
 *   e.g. `messages[].content[].args`).
 *
 * @example
 * ```ts
 * import { Client } from "langsmith";
 * import { createSecretAnonymizer } from "langsmith/anonymizer";
 *
 * const client = new Client({ anonymizer: createSecretAnonymizer() });
 * ```
 */
export declare function createSecretAnonymizer(options?: {
    extraRules?: StringNodeRule[];
    maxDepth?: number;
}): <T>(data: T) => T;
//# sourceMappingURL=index.d.mts.map