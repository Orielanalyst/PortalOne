import type { SandboxAccessControl, SandboxAwsAuthRule, SandboxGcpAuthRule, SandboxProxyConfig, SandboxProxyRule, SandboxProxySecret } from "./types.mjs";
/** Validate role-only descriptors without tightening legacy static inputs. */
export declare function getAwsRoleArn(aws: unknown): string | undefined;
/** Reference a LangSmith workspace secret in a sandbox proxy configuration. */
export declare function workspaceSecret(name: string): SandboxProxySecret;
/** Provide a write-only secret value for a sandbox proxy configuration. */
export declare function opaqueSecret(value: string): SandboxProxySecret;
/** Build a sandbox proxy config from one or more proxy rules. */
export declare function proxyConfig({ rules, accessControl, }?: {
    rules?: SandboxProxyRule[];
    /** @deprecated Ignored. The sandbox runtime has no proxy bypass list. */
    noProxy?: string[];
    accessControl?: SandboxAccessControl;
}): SandboxProxyConfig;
interface AwsAuthCommonOptions {
    name?: string;
    enabled?: boolean;
    envVars?: Record<string, string>;
}
type AwsStaticAuthConfig = Extract<SandboxAwsAuthRule["aws"], {
    access_key_id: SandboxProxySecret;
}>;
type AwsRoleAuthConfig = Extract<SandboxAwsAuthRule["aws"], {
    role_arn: string;
}>;
type AwsStaticAuthOptions = AwsAuthCommonOptions & {
    accessKeyId: SandboxProxySecret;
    secretAccessKey: SandboxProxySecret;
    roleArn?: "";
};
type AwsRoleAuthOptions = AwsAuthCommonOptions & {
    roleArn: string;
    accessKeyId?: never;
    secretAccessKey?: never;
};
/**
 * Sign supported AWS HTTPS requests using static keys or an IAM role.
 * Role auth requires backend support and is configured at sandbox creation.
 * LangSmith supplies the workspace External ID and renews credentials.
 * A role in proxyConfig uses its effective IAM permissions; the same helper
 * in mountConfig.auth uses the backend's mount-scoped S3 permissions.
 */
export declare function awsAuth(options: AwsStaticAuthOptions): SandboxAwsAuthRule<AwsStaticAuthConfig>;
export declare function awsAuth(options: AwsRoleAuthOptions): SandboxAwsAuthRule<AwsRoleAuthConfig>;
export declare function awsAuth(options: AwsStaticAuthOptions | AwsRoleAuthOptions): SandboxAwsAuthRule;
/** Build a sandbox proxy rule that injects GCP OAuth bearer auth. */
export declare function gcpAuth({ serviceAccountJson, scopes, name, enabled, envVars, }: {
    serviceAccountJson: SandboxProxySecret;
    scopes?: string[];
    name?: string;
    enabled?: boolean;
    envVars?: Record<string, string>;
}): SandboxGcpAuthRule;
export {};
//# sourceMappingURL=proxy_config.d.mts.map