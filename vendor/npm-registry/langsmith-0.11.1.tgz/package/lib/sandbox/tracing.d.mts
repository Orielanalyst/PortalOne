export declare function addSandboxMetadata(sandboxId?: string): void;
//# sourceMappingURL=tracing.d.mts.map