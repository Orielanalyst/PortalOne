/**
 * WebSocket-based command execution for long-running commands.
 *
 * Uses the `ws` npm package (optional peer dependency).
 * Install with: npm install ws
 */
import type { WsMessage, WsRunOptions } from "./types.mjs";
export declare const WS_OPEN_TIMEOUT: number | undefined;
export declare const WS_CONNECT_BUDGET: number | undefined;
/** Instant after which connect attempts must stop, if bounded. */
export declare function connectDeadline(): number | undefined;
/** Seconds left in the connect budget, or undefined when unbounded. */
export declare function remainingBudget(deadline: number | undefined): number | undefined;
/** Per-attempt open timeout, clamped so it cannot outlive `deadline`. */
export declare function openTimeoutFor(deadline: number | undefined): number | undefined;
type WsWebSocket = any;
/** Whether the optional `ws` package could be loaded (resolved once). */
export declare function isWsAvailable(): Promise<boolean>;
/**
 * Convert a dataplane HTTP URL to a WebSocket URL for /execute/ws.
 */
export declare function buildWsUrl(dataplaneUrl: string): string;
/**
 * Build auth headers for the WebSocket upgrade request.
 */
export declare function buildAuthHeaders(apiKey: string | undefined, extraHeaders?: Record<string, string>): Record<string, string>;
/**
 * Control interface for an active WebSocket stream.
 *
 * Created before the async generator starts, bound to the WebSocket once
 * the connection opens. The CommandHandle holds a reference to this
 * object to send kill/input messages.
 */
export declare class WSStreamControl {
    private _ws;
    private _closed;
    private _killed;
    private _closeStdinPending;
    /** Bind to the active WebSocket. Called inside the generator. */
    _bind(ws: WsWebSocket): void;
    /** Mark as closed. Called when the generator exits. */
    _unbind(): void;
    /** True if kill() has been called on this stream. */
    get killed(): boolean;
    /** Send a kill message to abort the running command. */
    sendKill(): void;
    /** Send stdin data to the running command. */
    sendInput(data: string): void;
    /**
     * Half-close the command's stdin so it reads EOF.
     *
     * A reconnected stream binds its socket only once iteration starts, so a
     * close arriving before that is queued and sent on bind — dropping it would
     * leave the command waiting for an EOF that never comes.
     */
    sendCloseStdin(): void;
}
/**
 * Raise the appropriate exception from a server error message.
 */
export declare function raiseForWsError(msg: WsMessage, commandId?: string): never;
/**
 * Execute a command over WebSocket, yielding raw message dicts.
 *
 * Returns a tuple of [async_message_iterator, control]. The control object
 * provides sendKill() and sendInput() methods for the CommandHandle.
 *
 * The iterator yields WsMessage objects with a "type" field:
 * - { type: "started", command_id: "...", pid: N }
 * - { type: "stdout", data: "...", offset: N }
 * - { type: "stderr", data: "...", offset: N }
 * - { type: "exit", exit_code: N }
 *
 * If onStdout/onStderr callbacks are provided, they are invoked as
 * data arrives in addition to yielding the messages.
 */
export declare function runWsStream(dataplaneUrl: string, apiKey: string | undefined, command: string, options?: WsRunOptions): Promise<[AsyncIterableIterator<WsMessage>, WSStreamControl]>;
/**
 * Reconnect to an existing command over WebSocket.
 *
 * Returns a tuple of [async_message_iterator, control], same as runWsStream.
 * The iterator yields the server's 'started' acknowledgement, then stdout,
 * stderr, exit, and error messages. That acknowledgement is the only evidence a
 * reattachment landed for a command producing no output, so it is forwarded
 * rather than dropped.
 */
export declare function reconnectWsStream(dataplaneUrl: string, apiKey: string | undefined, commandId: string, options?: {
    stdoutOffset?: number;
    stderrOffset?: number;
    headers?: Record<string, string>;
}): Promise<[AsyncIterableIterator<WsMessage>, WSStreamControl]>;
export {};
//# sourceMappingURL=ws_execute.d.mts.map