/** Header carrying the signed identity of a LangSmith-login service URL request. */
export declare const USER_TOKEN_HEADER = "X-Langsmith-User-Token";
/** Header carrying the signature of a proxy callback request. */
export declare const CALLBACK_SIGNATURE_HEADER = "X-LangSmith-Signature-JWT";
/** The LangSmith user a service URL request was made by. */
export interface SandboxUser {
    subject: string;
    email?: string;
    name?: string;
    expiresAt: Date;
}
/** The sandbox whose outbound request triggered a proxy callback. */
export interface SandboxCallbackIdentity {
    tenant_id: string;
    sandbox_id: string;
    organization_id?: string;
    ls_user_id?: string;
}
/** Snapshot of the outbound request, sent for `full_request` callbacks. */
export interface SandboxCallbackRequest {
    method: string;
    url: string;
    scheme: string;
    host: string;
    path: string;
    query?: string;
    headers: Record<string, string[]>;
    body_base64: string;
    body_truncated: boolean;
}
/** A verified proxy callback payload. */
export interface SandboxCallback {
    host: string;
    port: number;
    identity: SandboxCallbackIdentity;
    request?: SandboxCallbackRequest;
}
export interface SandboxTokenVerifierConfig {
    /** LangSmith API URL whose origin serves the JWKS. Defaults to LANGSMITH_ENDPOINT. */
    apiUrl?: string;
    /** Full JWKS URL; overrides `apiUrl`. */
    jwksUrl?: string;
    /** Timeout in milliseconds for fetching the JWKS. */
    timeoutMs?: number;
    /**
     * Allow fetching the JWKS over plain HTTP from a non-loopback host. Anyone
     * who can tamper with that traffic can forge tokens this verifier accepts.
     */
    allowInsecureJwks?: boolean;
}
export interface VerifyUserTokenOptions {
    /**
     * The service URL host the request was sent to, such as the request's
     * `Host` header. A full service URL is also accepted.
     */
    audience: string;
    /** If set, the LangSmith app URL the token must be issued by. */
    issuer?: string;
}
export interface VerifyCallbackOptions {
    /** The raw request body, exactly as received. */
    body: string | Uint8Array | ArrayBuffer;
    /** The `X-LangSmith-Signature-JWT` header value. */
    signature: string;
    /**
     * If set, checks the signature's audience, which is the callback URL as
     * configured in the proxy config. A string must match exactly; a predicate
     * is called with each audience and must return true for at least one.
     */
    aud?: AudienceMatcher;
    /** If set, the LangSmith OAuth issuer the signature must be issued by. */
    issuer?: string;
}
/** An exact audience, or a predicate called with each audience in the token. */
export type AudienceMatcher = string | ((aud: string) => boolean);
/**
 * Verifies tokens LangSmith signs for code running in or behind a sandbox.
 *
 * Keys are fetched from LangSmith's JWKS endpoint and cached. Requires Web
 * Crypto Ed25519 support (Node.js 20+, Deno, Bun, Cloudflare Workers).
 *
 * @example
 * ```typescript
 * const verifier = new SandboxTokenVerifier();
 *
 * // In an app served from a LangSmith-login service URL:
 * const user = await verifier.verifyUserToken(
 *   req.headers.get(USER_TOKEN_HEADER)!,
 *   { audience: req.headers.get("host")! }
 * );
 *
 * // In a proxy callback endpoint:
 * const callback = await verifier.verifyCallback({
 *   body: await req.text(),
 *   signature: req.headers.get(CALLBACK_SIGNATURE_HEADER)!,
 *   aud: "https://example.com/sandbox-callback",
 * });
 * ```
 */
export declare class SandboxTokenVerifier {
    private readonly jwksUrl;
    private readonly timeoutMs;
    private keys;
    private fetchedAt;
    private inflight?;
    constructor(config?: SandboxTokenVerifierConfig);
    /**
     * Verify the `X-Langsmith-User-Token` header of a service URL request.
     *
     * LangSmith sets this header only for service URLs that use LangSmith login.
     * Code that knows it is running in a sandbox can instead trust the unsigned
     * `X-Langsmith-User-Id` and `X-Langsmith-User-Email` headers, which the
     * sandbox runtime strips from inbound requests and sets itself; verify this
     * token when that is not guaranteed.
     */
    verifyUserToken(token: string, options: VerifyUserTokenOptions): Promise<SandboxUser>;
    /** Verify a proxy callback request and return its parsed payload. */
    verifyCallback(options: VerifyCallbackOptions): Promise<SandboxCallback>;
    private verify;
    private key;
    private refresh;
}
//# sourceMappingURL=verify.d.mts.map