/** How a service URL is gated. Omit for a minted token. */
export type ServiceAccess = "restricted" | "workspace";
/** Header the sandbox router reads the minted service token from. */
export declare const SERVICE_TOKEN_HEADER = "X-Langsmith-Sandbox-Service-Token";
export interface ServiceUrlData {
    browser_url?: string;
    service_url?: string;
    token?: string;
    expires_at?: string;
    access?: string;
}
/**
 * Service URL carrying a short-lived token, refreshed as it nears expiry.
 *
 * Accessors are async because a refresh is a network call.
 */
export declare class ServiceUrl {
    private readonly _sandboxId?;
    private _browserUrl;
    private _serviceUrl;
    private _token;
    private _expiresAt;
    private readonly _refresher?;
    constructor(data: ServiceUrlData, refresher?: () => Promise<ServiceUrl>, _sandboxId?: string | undefined);
    private _shouldRefresh;
    private _maybeRefresh;
    /** The signed token, refreshed if near expiry. */
    token(): Promise<string>;
    /** The service base URL, refreshed if near expiry. */
    serviceUrl(): Promise<string>;
    /** The browser URL that authenticates then redirects, refreshed if near expiry. */
    browserUrl(): Promise<string>;
    /** ISO 8601 expiry of the current token, refreshed if near expiry. */
    expiresAt(): Promise<string>;
    /** Fetch a path on the service with the token header injected. */
    fetch(path?: string, init?: RequestInit): Promise<Response>;
}
/**
 * Service URL gated by LangSmith login rather than a token.
 *
 * The grant is durable: no token, no expiry, and only usable from a browser
 * signed in to LangSmith — which is why there is no fetch helper here, a
 * programmatic request cannot satisfy the login.
 */
export declare class ServiceLoginUrl {
    /** The URL to open in a browser. */
    readonly url: string;
    /** Who may open it: "restricted" or "workspace". */
    readonly access: string;
    constructor(data: ServiceUrlData);
}
//# sourceMappingURL=service_url.d.mts.map