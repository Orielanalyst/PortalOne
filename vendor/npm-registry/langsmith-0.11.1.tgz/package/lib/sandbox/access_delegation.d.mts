/** How a delegation grant derives its permission set. */
export type AccessDelegationMode = "INHERIT" | "EXPLICIT";
/**
 * Grant letting code inside a sandbox call the LangSmith API as the creator.
 *
 * `INHERIT` tracks everything the creator can do; `EXPLICIT` is capped to
 * `permissions`. Permissions are a ceiling re-checked on every request rather
 * than a snapshot, so access the creator loses is lost here too.
 */
export interface AccessDelegation {
    mode: AccessDelegationMode;
    permissions?: string[];
}
/** Rejects grants the server would refuse, without the round trip. */
export declare function validateAccessDelegation(value: AccessDelegation): AccessDelegation;
//# sourceMappingURL=access_delegation.d.mts.map