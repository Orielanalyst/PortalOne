import type { ContextHubMountSpec, GCSMountSpec, GitMountRefSpec, GitMountSpec, MountCacheConfig, MountEncryptionConfig, S3MountSpec, SandboxMount, SandboxMountAuth, SandboxMountConfig, SandboxProxyConfig } from "./types.mjs";
export declare function s3Mount({ id, mountPath, bucket, region, prefix, endpointUrl, pathStyle, readOnly, cache, encryption, }: {
    id: string;
    mountPath: string;
    bucket: string;
    region?: string;
    prefix?: string;
    endpointUrl?: string;
    pathStyle?: boolean;
    readOnly?: boolean;
    cache?: MountCacheConfig;
    encryption?: MountEncryptionConfig;
}): S3MountSpec;
export declare function gitMount({ id, mountPath, remoteUrl, ref, refreshIntervalSeconds, }: {
    id: string;
    mountPath: string;
    remoteUrl: string;
    ref?: GitMountRefSpec;
    refreshIntervalSeconds?: number;
}): GitMountSpec;
export declare function gcsMount({ id, mountPath, bucket, prefix, readOnly, cache, }: {
    id: string;
    mountPath: string;
    bucket: string;
    prefix?: string;
    readOnly?: boolean;
    cache?: MountCacheConfig;
}): GCSMountSpec;
/**
 * Build a read-only Context Hub mount. The sync is one-way: files written
 * under the mount path inside the sandbox are never pushed back to the repo,
 * and the next sync overwrites them.
 */
export declare function contextHubMount({ id, mountPath, repo, initialPullOnly, }: {
    id: string;
    mountPath: string;
    repo: string;
    initialPullOnly?: boolean;
}): ContextHubMountSpec;
/**
 * Build mount-scoped auth, or use an enabled AWS rule from proxyConfig for S3.
 * Pass the same proxyConfig to sandbox creation; its general IAM permissions
 * remain unchanged. GCS mounts still require explicit GCP auth in this config.
 */
export declare function mountConfig({ auth, mounts, proxyConfig, }: {
    auth?: SandboxMountAuth[];
    mounts: SandboxMount[];
    proxyConfig?: SandboxProxyConfig;
}): SandboxMountConfig;
export declare function validateMountConfigProxyConfig(mountConfig: SandboxMountConfig, proxyConfig: SandboxProxyConfig | undefined): void;
//# sourceMappingURL=mounts.d.mts.map