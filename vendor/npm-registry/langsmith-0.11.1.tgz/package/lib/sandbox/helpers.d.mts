/**
 * Shared helper functions for error handling.
 *
 * These functions are used to parse error responses and raise appropriate
 * exceptions. They contain no I/O operations.
 */
import type { FileChunk, FileStat, ReadRangeOptions, RunConfig } from "./types.mjs";
/**
 * Validate TTL values for sandbox create/update (minute resolution).
 *
 * @param value - TTL in seconds (`undefined` means unset; `0` disables).
 * @param name - Parameter name for error messages.
 * @throws LangSmithValidationError if negative or not a multiple of 60 (when non-zero).
 */
export declare function validateTtl(value: number | undefined, name: string): void;
interface ParsedError {
    errorType?: string;
    message: string;
}
interface ValidationDetail {
    loc?: unknown[];
    msg?: string;
    type?: string;
    [key: string]: unknown;
}
/**
 * Parse standardized error response.
 *
 * Expected format: {"detail": {"error": "...", "message": "..."}}
 */
export declare function parseErrorResponse(response: Response): Promise<ParsedError>;
/**
 * Parse Pydantic validation error response.
 *
 * Returns a list of validation error details.
 */
export declare function parseValidationError(response: Response): Promise<ValidationDetail[]>;
/**
 * Extract quota type from error message.
 */
export declare function extractQuotaType(message: string): string | undefined;
/**
 * Handle HTTP errors specific to sandbox creation.
 *
 * Maps API error responses to specific exception types:
 * - 408: LangSmithResourceTimeoutError (sandbox didn't become ready in time)
 * - 422: LangSmithValidationError (bad input) or LangSmithSandboxCreationError (runtime)
 * - 429: LangSmithQuotaExceededError (org limits exceeded)
 * - 503: LangSmithSandboxCreationError (no resources available)
 * - Other: Falls through to generic error handling
 */
export declare function handleSandboxCreationError(response: Response): Promise<never>;
/**
 * Throw `LangSmithSandboxNotReadyError` when the API rejected a proxy-config
 * update because the sandbox is not `ready`.
 *
 * That status check is the sole source of `InvalidRequest` on the update
 * endpoint for the fields this client sends, so a typed error lets callers
 * start the sandbox and retry instead of matching on status codes. Reads a
 * clone so the caller's own error handling can still consume the body.
 */
export declare function throwIfNotReady(response: Response, name: string): Promise<void>;
/**
 * Handle HTTP errors and raise appropriate exceptions (for client operations).
 */
export declare function handleClientHttpError(response: Response): Promise<never>;
/**
 * Handle HTTP errors for sandbox operations (run, read, write).
 *
 * Maps API error types to specific exceptions:
 * - WriteError -> LangSmithSandboxOperationError (operation="write")
 * - ReadError -> LangSmithSandboxOperationError (operation="read")
 * - CommandError -> LangSmithSandboxOperationError (operation="command")
 * - ConnectionError (502) -> LangSmithSandboxConnectionError
 * - FileNotFound / 404 -> LangSmithResourceNotFoundError (resourceType="file")
 * - NotReady (400) -> LangSmithSandboxNotReadyError
 * - 403 -> LangSmithSandboxOperationError (permission denied)
 */
export declare function handleSandboxHttpError(response: Response): Promise<never>;
/**
 * Reject a per-command `runConfig` alongside the deprecated `env`/`cwd`.
 *
 * The server answers 400 for a request carrying both spellings rather than
 * letting one silently win, so refuse it here where the message can name the
 * replacement.
 */
export declare function assertRunConfigNotCombined(options: {
    runConfig?: RunConfig;
    env?: Record<string, string>;
    cwd?: string;
}): void;
/**
 * Whether to half-close stdin at spawn.
 *
 * Defaults on for a non-PTY command: a command that reads stdin otherwise
 * blocks on a pipe nobody writes to until the timeout kills it. A PTY has no
 * separate write end to close, so the server ignores the flag there.
 */
export declare function resolveCloseInput(closeInput: boolean | undefined, pty: boolean): boolean;
/** Render a byte range as an RFC 9110 `Range` header value. */
export declare function buildRangeHeader(options: ReadRangeOptions): string;
/** Build a FileStat from a HEAD response's headers. */
export declare function fileStatFromResponse(response: Response): FileStat;
/** Build a FileChunk from a ranged download response. */
export declare function fileChunkFromResponse(response: Response): Promise<FileChunk>;
/** Map a file-operation HTTP error, including the non-JSON 416. */
export declare function handleFileHttpError(response: Response, path: string, sandboxName: string): Promise<never>;
export {};
//# sourceMappingURL=helpers.d.mts.map