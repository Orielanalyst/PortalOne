/**
 * TypeScript interfaces for the sandbox module.
 *
 * Field names use snake_case to match API response format.
 */
import type { AccessDelegation } from "./access_delegation.mjs";
/**
 * Result of executing a command in a sandbox.
 */
export interface ExecutionResult {
    stdout: string;
    stderr: string;
    exit_code: number;
}
/**
 * Lightweight provisioning status for any async-created resource.
 */
export interface ResourceStatus {
    /** One of "provisioning", "ready", "failed". */
    status: string;
    /** Human-readable details when failed. */
    status_message?: string;
}
/**
 * The user, working directory and environment commands run with.
 *
 * Mirrors `docker run -u / -w / -e`: `user` and `work_dir` replace the layer
 * below, `env_vars` merge into it key by key. It applies at three points, each
 * layered over the one before -- the snapshot, the sandbox, and a single
 * command.
 */
export interface RunConfig {
    /**
     * Account to run as: `name`, `uid`, `name:group` or `uid:gid`. Defaults to
     * the Docker image's `USER`.
     */
    user?: string;
    /**
     * Absolute working directory. Defaults to the image's `WORKDIR`. A relative
     * path is rejected by the server.
     */
    work_dir?: string;
    /** Environment variables, merged over the layer below. */
    env_vars?: Record<string, string>;
}
/**
 * One filesystem entry returned by `sandbox.glob()`.
 */
export interface FileInfo {
    /** Absolute path of the entry. */
    path: string;
    /** True for a directory. */
    is_dir: boolean;
    /** Size in bytes. */
    size_bytes: number;
    /** RFC 3339 modification timestamp. */
    modified_at?: string;
}
/**
 * Entries matching a glob pattern.
 */
export interface GlobResult {
    matches: FileInfo[];
    /**
     * True when the server hit its result cap or deadline, so the search is a
     * partial answer worth refining.
     */
    truncated: boolean;
}
/**
 * One matching line found by `sandbox.grep()`.
 */
export interface GrepMatch {
    /** Absolute path of the file the match was found in. */
    path: string;
    /** 1-based line number. */
    line: number;
    /** The matching line's text. */
    text: string;
}
/**
 * Lines matching a literal search.
 */
export interface GrepResult {
    matches: GrepMatch[];
    /** True when the server hit its result cap or deadline. */
    truncated: boolean;
}
/**
 * Options for the read-only filesystem search operations.
 */
export interface GlobOptions {
    /** Maximum matches to return. */
    limit?: number;
    /** Request timeout in seconds. */
    timeout?: number;
    headers?: Record<string, string>;
}
/**
 * Options for `sandbox.grep()`.
 */
export interface GrepOptions extends GlobOptions {
    /**
     * Restrict which files are searched. A bare `*.py` matches by basename at
     * any depth; a pattern containing `/` or `**` matches the path relative to
     * the search root.
     */
    glob?: string;
}
/**
 * What a `HEAD` on a sandbox file reports, without transferring it.
 */
export interface FileStat {
    /** The file's size. */
    size_bytes: number;
    /**
     * Strong validator for the current contents. Opaque -- compare it, never
     * parse it. Pass it back as `ifRange` to resume a download safely, or as
     * `ifNoneMatch` to poll for a change.
     */
    etag?: string;
    /** HTTP-date of the last modification, second-resolution. */
    last_modified?: string;
    /** The server's content type for the file. */
    content_type?: string;
}
/**
 * Bytes returned by a ranged read, and where they sit in the file.
 */
export interface FileChunk {
    /** The bytes returned. Empty when `unchanged` is true. */
    content: Uint8Array;
    /**
     * Validator for the version these bytes came from. Pass it as `ifRange` on
     * the next chunk so a rewrite restarts the read instead of splicing two
     * versions together.
     */
    etag?: string;
    /** The file's full size, or undefined when the server did not report it. */
    total_bytes?: number;
    /** Offset of the first byte returned. */
    start: number;
    /**
     * True when the server answered 206 with only part of the file. A false
     * here after a ranged request means the file changed and the server sent it
     * whole -- restart from zero.
     */
    partial: boolean;
    /**
     * True when the caller passed `ifNoneMatch` and the file still matches it.
     * No bytes are returned.
     */
    unchanged: boolean;
    /** HTTP-date of the last modification. */
    last_modified?: string;
}
/**
 * Options for a ranged read. Provide `start` (with optional `end`), or
 * `suffixBytes`.
 */
export interface ReadRangeOptions {
    /** First byte to return. With `end`, an inclusive range. */
    start?: number;
    /** Last byte to return, inclusive. Clamped to EOF rather than rejected. */
    end?: number;
    /** Return the last N bytes. Mutually exclusive with `start`/`end`. */
    suffixBytes?: number;
    /**
     * An `ETag` from an earlier chunk. The range is honored only while the file
     * still matches it.
     */
    ifRange?: string;
    /**
     * An `ETag` the caller already holds. An unchanged file answers with
     * `unchanged: true` and no bytes.
     */
    ifNoneMatch?: string;
    /** Request timeout in seconds. */
    timeout?: number;
    headers?: Record<string, string>;
}
/**
 * Represents a sandbox snapshot.
 *
 * Snapshots are built from Docker images or captured from running sandboxes.
 * They are used to create new sandboxes.
 */
export interface Snapshot {
    id: string;
    name: string;
    /** One of "building", "ready", "failed". */
    status: string;
    fs_capacity_bytes: number;
    docker_image?: string;
    image_digest?: string;
    source_sandbox_id?: string;
    status_message?: string;
    fs_used_bytes?: number;
    created_by?: string;
    registry_id?: string;
    created_at?: string;
    updated_at?: string;
    /**
     * User, working directory and environment sandboxes built from this
     * snapshot boot with, resolved from the Docker image at build time. Absent
     * on snapshots built before the server recorded it, which boot as root with
     * no image environment.
     */
    run_config?: RunConfig;
}
/**
 * Data representing a sandbox instance from the API.
 */
export interface SandboxData {
    id?: string;
    name: string;
    dataplane_url?: string;
    status?: string;
    status_message?: string;
    created_at?: string;
    updated_at?: string;
    /**
     * Idle timeout in seconds. The launcher stops the sandbox after this
     * many seconds of inactivity. `0` disables the idle stop;
     * omitted/`undefined` means not set (the server applies a default).
     */
    idle_ttl_seconds?: number;
    /**
     * Seconds after a sandbox enters the `stopped` state before it (and its
     * filesystem clone) are permanently deleted. `0` disables stop-anchored
     * deletion; omitted/`undefined` falls back to the server default.
     */
    delete_after_stop_seconds?: number;
    /**
     * Timestamp when the sandbox transitioned to the `stopped` state, or
     * `undefined` while running. The deletion deadline is
     * `stopped_at + delete_after_stop_seconds`.
     */
    stopped_at?: string;
    /** Snapshot ID used to create this sandbox. */
    snapshot_id?: string;
    /** Number of vCPUs allocated. */
    vcpus?: number;
    /** Memory allocation in bytes. */
    mem_bytes?: number;
    /** Root filesystem capacity in bytes. */
    fs_capacity_bytes?: number;
    /**
     * User, working directory and environment the sandbox's commands run with.
     * Absent on sandboxes created before the server recorded it.
     */
    run_config?: RunConfig;
    /**
     * LangSmith access granted to code inside the sandbox. Absent when it has
     * none.
     */
    access_delegation?: AccessDelegation;
}
/**
 * Configuration options for the SandboxClient.
 */
export interface SandboxClientConfig {
    /**
     * Full URL of the sandbox API endpoint.
     * If not provided, derived from LANGSMITH_ENDPOINT environment variable.
     */
    apiEndpoint?: string;
    /**
     * API key for authentication.
     * If not provided, uses LANGSMITH_API_KEY environment variable.
     */
    apiKey?: string;
    /**
     * Default HTTP timeout in milliseconds.
     */
    timeoutMs?: number;
    /**
     * Maximum number of retries for transient failures (network errors, 5xx, 429).
     * Defaults to 3.
     */
    maxRetries?: number;
    /**
     * Maximum number of concurrent requests.
     * Defaults to Infinity (no limit).
     */
    maxConcurrency?: number;
    /**
     * Optional default headers attached to every request on this client,
     * including the data-plane `/execute` HTTP endpoint and the `/execute/ws`
     * WebSocket upgrade. Use this to pass additional auth headers
     * (e.g. `X-Service-Key`).
     */
    headers?: Record<string, string>;
}
/**
 * A single chunk of streaming output from command execution.
 */
export interface OutputChunk {
    /** Either "stdout" or "stderr". */
    stream: "stdout" | "stderr";
    /** The text content of this chunk. */
    data: string;
    /** Byte offset within the stream. Used internally for reconnection. */
    offset: number;
}
/**
 * Internal WebSocket message type from the server.
 */
export interface WsMessage {
    type: "started" | "stdout" | "stderr" | "exit" | "error";
    [key: string]: unknown;
}
/**
 * Options for the low-level WebSocket stream functions.
 */
export interface WsRunOptions {
    /** Command timeout in seconds. Default: 60. */
    timeout?: number;
    /** Environment variables to set for the command. */
    env?: Record<string, string>;
    /** Working directory for command execution. */
    cwd?: string;
    /** Shell to use. Default: "/bin/bash". */
    shell?: string;
    /** Callback invoked with each stdout chunk. */
    onStdout?: (data: string) => void;
    /** Callback invoked with each stderr chunk. */
    onStderr?: (data: string) => void;
    /** Client-assigned command ID. */
    commandId?: string;
    /**
     * Idle timeout in seconds. If the command has no connected clients for
     * this duration, it is killed. Defaults to 300 (5 minutes).
     * Set to -1 for no idle timeout.
     */
    idleTimeout?: number;
    /**
     * If true, kill the command immediately when the last client disconnects.
     * Defaults to false (command continues running and can be reconnected to).
     */
    killOnDisconnect?: boolean;
    /**
     * How long (in seconds) a finished command's session is kept for
     * reconnection. Defaults to 600 (10 minutes). Set to -1 to keep indefinitely.
     */
    ttlSeconds?: number;
    /** Whether to allocate a PTY. */
    pty?: boolean;
    /** Per-command user, working directory and environment. */
    runConfig?: RunConfig;
    /** Half-close the spawned process's stdin so it reads EOF. */
    closeStdin?: boolean;
    /**
     * Additional headers attached to the WebSocket upgrade request. Merged on
     * top of any default headers the SandboxClient was constructed with.
     */
    headers?: Record<string, string>;
}
/**
 * Options for running a command in a sandbox.
 */
export interface RunOptions {
    /**
     * Command timeout in seconds.
     */
    timeout?: number;
    /**
     * Environment variables to set for the command.
     *
     * @deprecated Use `runConfig.env_vars`. The two cannot be combined.
     */
    env?: Record<string, string>;
    /**
     * Working directory for command execution.
     *
     * @deprecated Use `runConfig.work_dir`. The two cannot be combined.
     */
    cwd?: string;
    /**
     * User, working directory and environment for this one command, layered
     * over the sandbox's own.
     */
    runConfig?: RunConfig;
    /**
     * Half-close the command's stdin so a command that reads it sees EOF
     * rather than blocking until the timeout. Defaults to true for a non-PTY
     * command, which means `sendInput()` on the returned handle throws unless
     * this is set to false. Ignored under `pty: true`, where input and output
     * share one terminal file descriptor -- send an EOT byte (0x04) as input
     * instead.
     */
    closeInput?: boolean;
    /**
     * Shell to use for command execution. Defaults to "/bin/bash".
     */
    shell?: string;
    /**
     * Whether to wait for the command to complete before returning.
     * When true (default), returns an ExecutionResult.
     * When false, returns a CommandHandle for streaming output.
     */
    wait?: boolean;
    /**
     * Client-assigned command ID. Executing with an existing command ID
     * re-attaches to that command (get-or-create) instead of starting a
     * new one. Only used by the WebSocket path.
     */
    commandId?: string;
    /**
     * Callback invoked with each stdout chunk during streaming execution.
     * When provided, WebSocket streaming is used.
     */
    onStdout?: (data: string) => void;
    /**
     * Callback invoked with each stderr chunk during streaming execution.
     * When provided, WebSocket streaming is used.
     */
    onStderr?: (data: string) => void;
    /**
     * Idle timeout in seconds. If the command has no connected clients for
     * this duration, it is killed. Defaults to 300 (5 minutes).
     * Set to -1 for no idle timeout.
     */
    idleTimeout?: number;
    /**
     * If true, kill the command immediately when the last client disconnects.
     * Defaults to false (command continues running and can be reconnected to).
     */
    killOnDisconnect?: boolean;
    /**
     * How long (in seconds) a finished command's session is kept for
     * reconnection. Defaults to 600 (10 minutes). Set to -1 to keep indefinitely.
     */
    ttlSeconds?: number;
    /**
     * If true, allocate a pseudo-terminal (PTY) for the command.
     * Useful for commands that require a TTY (e.g., interactive programs,
     * commands that use terminal control codes). Defaults to false.
     */
    pty?: boolean;
}
/**
 * Network access-control rules for a sandbox's proxy sidecar.
 *
 * Supported pattern types: exact domains, globs (e.g. `*.example.com`),
 * IPs, CIDR ranges (e.g. `10.0.0.0/8`), and regex (`~pattern`).
 *
 * Only one of `allow_list` and `deny_list` may be populated.
 */
export interface SandboxAccessControl {
    /** Hosts the sandbox is allowed to reach. */
    allow_list?: string[];
    /** Hosts the sandbox is blocked from reaching. */
    deny_list?: string[];
}
/** Secret value reference for sandbox proxy rules. */
export interface SandboxProxySecret {
    /** `workspace_secret` references a workspace secret; `opaque` is write-only. */
    type: "workspace_secret" | "opaque";
    /** Workspace secret reference or opaque secret value. */
    value: string;
}
/** Static credentials used by the sandbox proxy signer. */
interface AwsStaticAuthConfig {
    access_key_id: SandboxProxySecret;
    secret_access_key: SandboxProxySecret;
    role_arn?: "";
}
/** IAM role assumed and renewed by LangSmith, outside the sandbox. */
interface AwsRoleAuthConfig {
    role_arn: string;
    access_key_id?: never;
    secret_access_key?: never;
}
/** AWS auth rule for sandbox proxy SigV4 signing. */
export interface SandboxAwsAuthRule<Auth extends AwsStaticAuthConfig | AwsRoleAuthConfig = AwsStaticAuthConfig | AwsRoleAuthConfig> {
    /** Rule name. */
    name: string;
    /** AWS auth rules are matched by the sandbox proxy's AWS endpoint matcher. */
    type: "aws";
    /** Whether the rule is enabled. */
    enabled?: boolean;
    /**
     * Plaintext environment variables set for every command in the sandbox while
     * the rule is enabled, for tools that refuse to run unless a credential
     * variable is present even though the proxy injects the real credential on
     * the wire.
     */
    env_vars?: Record<string, string>;
    /** Exclusive static credentials or IAM-role descriptor. */
    aws: Auth;
}
/** GCP auth rule for sandbox proxy OAuth bearer injection. */
export interface SandboxGcpAuthRule {
    /** Rule name. */
    name: string;
    /** GCP auth rules use the sandbox proxy's built-in Google API host matcher. */
    type: "gcp";
    /** Whether the rule is enabled. */
    enabled?: boolean;
    /**
     * Plaintext environment variables set for every command in the sandbox while
     * the rule is enabled, for tools that refuse to run unless a credential
     * variable is present even though the proxy injects the real credential on
     * the wire.
     */
    env_vars?: Record<string, string>;
    /** GCP service-account credential and OAuth scopes. */
    gcp: {
        service_account_json: SandboxProxySecret;
        scopes?: string[];
    };
}
/** Proxy rule accepted by the sandbox proxy config. */
export type SandboxProxyRule = SandboxAwsAuthRule | SandboxGcpAuthRule | Record<string, unknown>;
/**
 * Full proxy configuration forwarded to the sandbox server as-is (snake_case
 * so it's wire-compatible with the backend). Mirrors the server's
 * `ProxyConfig` type.
 */
export interface SandboxProxyConfig {
    /** Header-injection rules keyed by host pattern. */
    rules?: SandboxProxyRule[];
    /** @deprecated Ignored by the server. The sandbox runtime has no proxy bypass list. */
    no_proxy?: string[];
    /** Allow/deny list enforced at the proxy sidecar. */
    access_control?: SandboxAccessControl;
}
/** Optional per-mount cache configuration supported by bucket mounts. */
export interface MountCacheConfig {
    /** Maximum VFS cache size in bytes. */
    max_size_bytes?: number;
    /** Seconds rclone waits before writing cached changes back. */
    writeback_seconds?: number;
}
interface SandboxBucketMountBase {
    /** Stable mount identifier. */
    id: string;
    /** Absolute path inside the sandbox where the mount appears. */
    mount_path: string;
    /** Whether the mount should be read-only. */
    read_only?: boolean;
    /** Optional per-mount VFS cache configuration. */
    cache?: MountCacheConfig;
}
/**
 * S3 configuration for a sandbox mount. Field names are snake_case so the
 * object is wire-compatible with the backend `MountSpec` type.
 */
export interface S3MountConfig {
    /** S3 or S3-compatible endpoint URL. */
    endpoint_url: string;
    /** AWS region for signing and bucket access. */
    region: string;
    /** Bucket name. */
    bucket: string;
    /** Optional key prefix inside the bucket. */
    prefix?: string;
    /** Whether to use path-style addressing for S3-compatible endpoints. */
    path_style?: boolean;
}
/** Customer-managed key that uploads through a mount are encrypted with. */
export interface MountEncryptionConfig {
    /** KMS key ARN in the mount's region; uploads use SSE-KMS with this key. */
    kms_key: string;
}
/** S3-backed sandbox mount specification. */
export interface S3MountSpec extends SandboxBucketMountBase {
    /** Mount type. */
    type: "s3";
    /** Optional customer-managed key for uploads. */
    encryption?: MountEncryptionConfig;
    /** S3 mount configuration. */
    s3: S3MountConfig;
}
/** GCS configuration for a sandbox mount. */
export interface GCSMountConfig {
    /** GCS bucket name. */
    bucket: string;
    /** Optional object prefix inside the bucket. */
    prefix?: string;
}
/** GCS-backed sandbox mount specification. */
export interface GCSMountSpec extends SandboxBucketMountBase {
    /** Mount type. */
    type: "gcs";
    /** GCS mount configuration. */
    gcs: GCSMountConfig;
}
/** Git ref selected for a sandbox mount. */
export interface GitMountRefSpec {
    /** Git ref type. */
    type: "branch" | "tag";
    /** Branch or tag name. */
    name: string;
}
/** Git configuration for a sandbox mount. */
export interface GitMountConfig {
    /** Public HTTPS Git remote URL. */
    remote_url: string;
    /** Optional branch or tag to mount. */
    ref?: GitMountRefSpec;
    /** Optional refresh interval for polling the remote. */
    refresh_interval_seconds?: number;
}
/** Git-backed sandbox mount specification. */
export interface GitMountSpec {
    /** Stable mount identifier. */
    id: string;
    /** Mount type. */
    type: "git";
    /** Absolute path inside the sandbox where the mount appears. */
    mount_path: string;
    /** Git mount configuration. */
    git: GitMountConfig;
}
/** Context Hub configuration for a sandbox mount. */
export interface ContextHubMountConfig {
    /**
     * Context Hub repository to sync, as `owner/repo` (e.g. `-/my-agent`, where
     * `-` is the current workspace).
     */
    repo: string;
    /** Sync once at startup instead of polling for updates. */
    initial_pull_only?: boolean;
}
/** Read-only Context Hub-backed sandbox mount specification. */
export interface ContextHubMountSpec {
    /** Stable mount identifier. */
    id: string;
    /** Mount type. */
    type: "contexthub";
    /** Absolute path inside the sandbox where the repo tree appears. */
    mount_path: string;
    /** Context Hub mount configuration. */
    contexthub: ContextHubMountConfig;
}
/** Sandbox mount specification. */
export type SandboxMount = S3MountSpec | GCSMountSpec | GitMountSpec | ContextHubMountSpec;
/** AWS credentials used by the backend to authenticate S3 mounts. */
export interface SandboxAwsMountAuthConfig {
    access_key_id: SandboxProxySecret;
    secret_access_key: SandboxProxySecret;
    role_arn?: "";
}
/** GCP credentials used by the backend to authenticate GCS mounts. */
export interface SandboxGcpMountAuthConfig {
    service_account_json: SandboxProxySecret;
}
/** Provider auth blocks for sandbox mounts. */
export interface SandboxMountAuthConfig {
    /** IAM roles here are restricted to this sandbox's S3 mount scopes. */
    aws?: SandboxAwsMountAuthConfig | AwsRoleAuthConfig;
    gcp?: SandboxGcpMountAuthConfig;
}
/** Provider auth helper output accepted by mountConfig. */
export type SandboxMountAuth = SandboxAwsAuthRule | SandboxGcpAuthRule;
/** Public mount config sent to the sandbox API. */
export interface SandboxMountConfig {
    /** Provider auth blocks for bucket-backed mounts. */
    auth: SandboxMountAuthConfig;
    /** Mounts attached to the sandbox. */
    mounts: SandboxMount[];
}
/**
 * Options for creating a sandbox.
 */
export interface CreateSandboxOptions {
    /**
     * Optional snapshot name to boot from. Mutually exclusive with the positional
     * `snapshotId`.
     * Resolved server-side to a snapshot owned by the caller's tenant.
     */
    snapshotName?: string;
    /**
     * Optional sandbox name (auto-generated if not provided).
     */
    name?: string;
    /**
     * Timeout in seconds when waiting for ready.
     */
    timeout?: number;
    /**
     * Whether to wait for the sandbox to be ready before returning.
     * When false, returns immediately with status "provisioning".
     * Use getSandboxStatus() or waitForSandbox() to poll for readiness.
     * Default: true.
     */
    waitForReady?: boolean;
    /**
     * Idle timeout in seconds. The launcher stops the sandbox after this many
     * seconds of inactivity. Must be a multiple of 60. Pass `0` to disable
     * the idle stop. When omitted, the server applies a default of `600`
     * seconds (10 minutes).
     */
    idleTtlSeconds?: number;
    /**
     * Seconds after the sandbox enters the `stopped` state before it (and
     * its filesystem clone) are permanently deleted. Must be a multiple of
     * 60. Pass `0` to disable stop-anchored deletion (manual cleanup
     * required). When omitted, the server applies its configured default
     * (typically 14 days).
     */
    deleteAfterStopSeconds?: number;
    /** Number of vCPUs. */
    vCpus?: number;
    /** Memory in bytes. */
    memBytes?: number;
    /** Root filesystem capacity in bytes. */
    fsCapacityBytes?: number;
    /**
     * Mount configuration forwarded to the server as `mount_config`. The backend
     * expands mount auth into runtime proxy rules. Explicit AWS/GCP proxy rules
     * in `proxyConfig` conflict with mount auth for the same provider.
     */
    mountConfig?: SandboxMountConfig;
    /**
     * Per-sandbox proxy configuration. Use
     * `{ access_control: { allow_list: ["github.com", "*.example.com"] } }`
     * to restrict outbound HTTPS to a set of host patterns. Forwarded to the
     * server as-is on the wire. Use `proxyConfig` with provider rule helpers
     * such as `awsAuth` for AWS SigV4 auth or `gcpAuth` for GCP OAuth bearer
     * auth.
     */
    proxyConfig?: SandboxProxyConfig;
    /**
     * User, working directory and environment the sandbox boots with,
     * overriding the snapshot's: `user` and `work_dir` replace, `env_vars`
     * merge. The sandbox's own env vars remain a layer above this one.
     */
    runConfig?: RunConfig;
    /**
     * Grant letting code inside the sandbox call the LangSmith API as you, with
     * no API key of its own. `{ mode: "INHERIT" }` grants everything you can do;
     * `{ mode: "EXPLICIT", permissions: [...] }` grants only the permissions
     * listed, each of which you must already hold. The grant belongs to the
     * sandbox, so anyone who can exec into it can make calls under it. Omit for
     * no access.
     */
    accessDelegation?: AccessDelegation;
}
/**
 * Options for creating a snapshot from a Docker image.
 */
export interface CreateSnapshotOptions {
    /** Private registry ID. */
    registryId?: string;
    /**
     * Override the Docker image's `USER`, `WORKDIR` and `ENV` for sandboxes
     * built from this snapshot: `user` and `work_dir` replace the image's,
     * `env_vars` merge over it key by key. Omitting it adopts the image's own
     * configuration. Pass `{ user: "0" }` to keep running as root.
     */
    runConfig?: RunConfig;
    /** Timeout in seconds when waiting for ready. Default: 60. */
    timeout?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * Options for creating a snapshot from a local Dockerfile context.
 */
export interface CreateDockerfileSnapshotOptions {
    /** Local Docker build context directory. Default: current working directory. */
    context?: string;
    /** Docker build args passed as BuildKit build-arg opts. */
    buildArgs?: Record<string, string>;
    /** Optional Dockerfile target stage. */
    target?: string;
    /** Callback for Docker build stdout/stderr chunks. */
    onBuildLog?: (data: string) => void;
    /**
     * Number of vCPUs for the temporary builder sandbox. The build runs
     * BuildKit plus the native snapshotter's layer copies inside it, which
     * contend for a single core by default, so an extra vCPU can cut a cold
     * build's wall time substantially.
     */
    vCpus?: number;
    /** Memory in bytes for the temporary builder sandbox. */
    memBytes?: number;
    /** Timeout in seconds for builder sandbox operations. Default: 60. */
    timeout?: number;
}
/**
 * Options for capturing a snapshot from a running sandbox.
 */
export interface CaptureSnapshotOptions {
    /**
     * Docker image tag inside the sandbox to export into the snapshot instead
     * of capturing the live root filesystem.
     */
    dockerImage?: string;
    /** Filesystem capacity in bytes for Docker image export. */
    fsCapacityBytes?: number;
    /**
     * Override applied over the configuration the captured sandbox was running
     * with: `user` and `work_dir` replace, `env_vars` merge.
     */
    runConfig?: RunConfig;
    /** Timeout in seconds when waiting for ready. Default: 60. */
    timeout?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * How a download link asks the browser to handle the file.
 */
export type DownloadContentDisposition = "attachment" | "inline";
/**
 * Options for minting a sandbox file download link.
 */
export interface GenerateDownloadURLOptions {
    /**
     * Link TTL in seconds. Omit for a link that never expires.
     */
    expiresInSeconds?: number;
    /** Content-Type to serve the file as. */
    contentType?: string;
    /** Content-Disposition to serve the file with. */
    contentDisposition?: DownloadContentDisposition;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * A link that downloads one sandbox file with no LangSmith credential.
 *
 * The link is pinned to the sandbox, the file path, and the response headers,
 * so it cannot be repointed at another file. It is pinned to the path rather
 * than to a snapshot of the contents, so the file must not be modified while
 * the link is in use.
 */
export interface DownloadURL {
    /** The full URL to fetch. Supports GET, HEAD, and Range. */
    download_url: string;
    /** The signed token embedded in `download_url`. */
    token: string;
    /** Expiry timestamp, or null for a link that never expires. */
    expires_at: string | null;
}
/**
 * Options for listing snapshots. All fields are optional and independent.
 *
 * The backend always paginates: when `limit` is omitted the server applies
 * a default page size (currently 50), so a single call will not necessarily
 * return every snapshot visible to the caller's tenant.
 */
export interface ListSnapshotsOptions {
    /**
     * Case-insensitive substring filter applied server-side to snapshot
     * names.
     */
    nameContains?: string;
    /**
     * Maximum number of snapshots to return for a single request. Must be
     * between 1 and 500 (inclusive); the server rejects values outside that
     * range. Defaults to 50 server-side when omitted.
     */
    limit?: number;
    /**
     * Number of snapshots to skip before returning results. Must be `>= 0`.
     * Useful for paginating through large result sets in combination with
     * `limit`.
     */
    offset?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * Options for waiting for a snapshot to become ready.
 */
export interface WaitForSnapshotOptions {
    /** Maximum time in seconds to wait. Default: 300. */
    timeout?: number;
    /** Time in seconds between status polls. Default: 2.0. */
    pollInterval?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * Options for starting a stopped sandbox.
 */
export interface StartSandboxOptions {
    /** Timeout in seconds when waiting for ready. Default: 120. */
    timeout?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
/**
 * Options for updating a sandbox (name, retention settings, proxy config).
 */
export interface UpdateSandboxOptions {
    /** New display name. */
    newName?: string;
    /**
     * Idle timeout in seconds. Must be a multiple of 60. Pass `0` to disable
     * the idle stop. Omit (or pass `undefined`) to leave the existing value
     * unchanged.
     */
    idleTtlSeconds?: number;
    /**
     * Seconds after entering `stopped` before deletion. Must be a multiple
     * of 60. Pass `0` to disable stop-anchored deletion. Omit (or pass
     * `undefined`) to leave the existing value unchanged.
     */
    deleteAfterStopSeconds?: number;
    /**
     * Replacement proxy configuration, sent to the server as-is (same shape as
     * `createSandbox`). Rules replace the existing set rather than merging into
     * it, so include every rule the sandbox should keep. Opaque header values
     * carry over from the current config, so rotating one credential does not
     * mean re-supplying secrets that can no longer be read. The sandbox must be
     * `ready`; start a stopped one first.
     */
    proxyConfig?: SandboxProxyConfig;
    /**
     * Merge into the sandbox's stored run configuration: `user` and `work_dir`
     * replace, `env_vars` merge. Takes effect for subsequent commands; commands
     * already running are unaffected, and a stopped sandbox picks it up on its
     * next start. Omitting it leaves the stored value untouched.
     */
    runConfig?: RunConfig;
}
/**
 * Options for waiting for a sandbox to become ready.
 */
export interface WaitForSandboxOptions {
    /**
     * Maximum time in seconds to wait for the sandbox to become ready.
     * Default: 120.
     */
    timeout?: number;
    /**
     * Time in seconds between status polls.
     * Default: 1.0.
     */
    pollInterval?: number;
    /** AbortSignal for cancellation. */
    signal?: AbortSignal;
}
export {};
//# sourceMappingURL=types.d.mts.map