/**
 * LangSmith Sandbox Module.
 *
 * This module provides sandboxed code execution capabilities through the
 * LangSmith Sandbox API.
 *
 * @example
 * ```typescript
 * import { SandboxClient } from "langsmith/sandbox";
 *
 * // Uses LANGSMITH_ENDPOINT and LANGSMITH_API_KEY from environment
 * const client = new SandboxClient();
 *
 * const snapshot = await client.createSnapshot(
 *   "python",
 *   "python:3.12-slim",
 *   1_073_741_824
 * );
 * const sandbox = await client.createSandbox(snapshot.id);
 * try {
 *   const result = await sandbox.run("python --version");
 *   console.log(result.stdout);
 * } finally {
 *   await sandbox.delete();
 * }
 * ```
 *
 * @packageDocumentation
 */
export { SandboxClient } from "./client.mjs";
export { Sandbox } from "./sandbox.mjs";
export { CommandHandle } from "./command_handle.mjs";
export { awsAuth, gcpAuth, opaqueSecret, proxyConfig, workspaceSecret, } from "./proxy_config.mjs";
export { validateAccessDelegation } from "./access_delegation.mjs";
export { ServiceUrl, ServiceLoginUrl, SERVICE_TOKEN_HEADER, } from "./service_url.mjs";
export { SandboxTokenVerifier, USER_TOKEN_HEADER, CALLBACK_SIGNATURE_HEADER, } from "./verify.mjs";
export type { AudienceMatcher, SandboxCallback, SandboxCallbackIdentity, SandboxCallbackRequest, SandboxTokenVerifierConfig, SandboxUser, VerifyCallbackOptions, VerifyUserTokenOptions, } from "./verify.mjs";
export { contextHubMount, gcsMount, gitMount, mountConfig, s3Mount, } from "./mounts.mjs";
export type { AccessDelegation, AccessDelegationMode, } from "./access_delegation.mjs";
export type { ServiceAccess, ServiceUrlData } from "./service_url.mjs";
export type { ExecutionResult, FileChunk, FileInfo, FileStat, GlobOptions, GlobResult, GrepMatch, GrepOptions, GrepResult, ReadRangeOptions, RunConfig, OutputChunk, WsMessage, WsRunOptions, ResourceStatus, Snapshot, SandboxData, SandboxClientConfig, RunOptions, CreateSandboxOptions, SandboxAccessControl, SandboxAwsAuthRule, SandboxAwsMountAuthConfig, SandboxGcpAuthRule, SandboxGcpMountAuthConfig, SandboxMountAuth, SandboxMountAuthConfig, SandboxMountConfig, SandboxProxyConfig, SandboxProxyRule, SandboxProxySecret, SandboxMount, MountCacheConfig, MountEncryptionConfig, ContextHubMountConfig, ContextHubMountSpec, GCSMountConfig, GCSMountSpec, GitMountConfig, GitMountRefSpec, GitMountSpec, S3MountConfig, S3MountSpec, CreateSnapshotOptions, CreateDockerfileSnapshotOptions, CaptureSnapshotOptions, DownloadContentDisposition, DownloadURL, GenerateDownloadURLOptions, ListSnapshotsOptions, WaitForSnapshotOptions, StartSandboxOptions, UpdateSandboxOptions, WaitForSandboxOptions, } from "./types.mjs";
export { LangSmithSandboxError, LangSmithSandboxAPIError, LangSmithSandboxAuthenticationError, LangSmithSandboxConnectionError, LangSmithSandboxRetryableConnectionError, LangSmithSandboxConnectTimeoutError, LangSmithSandboxServerReloadError, LangSmithResourceNotFoundError, LangSmithResourceTimeoutError, LangSmithResourceInUseError, LangSmithResourceAlreadyExistsError, LangSmithResourceNameConflictError, LangSmithValidationError, LangSmithQuotaExceededError, LangSmithResourceCreationError, LangSmithSandboxCreationError, LangSmithSandboxNotReadyError, LangSmithSandboxOperationError, LangSmithCommandTimeoutError, LangSmithDataplaneNotConfiguredError, LangSmithSandboxTokenVerificationError, } from "./errors.mjs";
//# sourceMappingURL=index.d.mts.map