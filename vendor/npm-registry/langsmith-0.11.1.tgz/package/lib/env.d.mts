export declare const isEnvTracingEnabled: (tracingEnabled?: boolean) => boolean;
/**
 * Whether a failed redactor should fall back to tracing the raw payload.
 *
 * Set `LANGSMITH_ALLOW_UNPROCESSED_PAYLOADS` to restore the pre-fail-closed
 * behavior in an emergency. It uploads data no redactor processed, so it is off
 * by default and the caller logs a warning naming it whenever it takes effect.
 * Read only on failure, so it stays off the hot path.
 */
export declare const allowUnprocessedPayloads: () => boolean;
//# sourceMappingURL=env.d.mts.map