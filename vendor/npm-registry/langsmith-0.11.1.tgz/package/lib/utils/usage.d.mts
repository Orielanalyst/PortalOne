export declare const convertAnthropicUsageToInputTokenDetails: (usage: Record<string, unknown>) => Record<string, number>;
//# sourceMappingURL=usage.d.mts.map