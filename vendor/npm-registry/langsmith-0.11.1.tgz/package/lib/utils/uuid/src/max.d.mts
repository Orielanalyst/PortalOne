declare const _default: "ffffffff-ffff-ffff-ffff-ffffffffffff";
export default _default;
//# sourceMappingURL=max.d.mts.map