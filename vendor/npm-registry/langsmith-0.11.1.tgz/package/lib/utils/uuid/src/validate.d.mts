declare function validate(uuid: unknown): boolean;
export default validate;
//# sourceMappingURL=validate.d.mts.map