declare function version(uuid: string): number;
export default version;
//# sourceMappingURL=version.d.mts.map