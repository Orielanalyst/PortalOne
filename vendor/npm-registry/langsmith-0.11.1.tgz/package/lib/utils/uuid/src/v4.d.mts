import type { Version4Options } from "./types.mjs";
declare function v4(options?: Version4Options, buf?: undefined, offset?: number): string;
declare function v4<TBuf extends Uint8Array = Uint8Array>(options: Version4Options | undefined, buf: TBuf, offset?: number): TBuf;
export default v4;
//# sourceMappingURL=v4.d.mts.map