declare function sha1(bytes: Uint8Array): Uint8Array;
export default sha1;
//# sourceMappingURL=sha1.d.mts.map