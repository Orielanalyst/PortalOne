export default function rng(): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=rng.d.mts.map