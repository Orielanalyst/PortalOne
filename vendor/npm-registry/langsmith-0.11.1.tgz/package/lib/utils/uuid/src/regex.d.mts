declare const _default: RegExp;
export default _default;
//# sourceMappingURL=regex.d.mts.map