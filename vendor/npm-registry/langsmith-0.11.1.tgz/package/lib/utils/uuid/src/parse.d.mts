import type { NonSharedArrayBuffer } from "./types.mjs";
declare function parse(uuid: string): NonSharedArrayBuffer;
export default parse;
//# sourceMappingURL=parse.d.mts.map