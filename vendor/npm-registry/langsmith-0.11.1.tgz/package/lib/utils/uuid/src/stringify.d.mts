export declare function unsafeStringify(arr: Uint8Array, offset?: number): string;
declare function stringify(arr: Uint8Array, offset?: number): string;
export default stringify;
//# sourceMappingURL=stringify.d.mts.map