export interface OAuthRefreshLock {
    release(): Promise<void>;
}
declare function lockOwner(lockDir: string): string | undefined;
/**
 * Acquire an exclusive cross-process lock for refreshing OAuth tokens.
 *
 * Uses an atomic-`mkdir` directory lock at `<configPath>.oauth.lock.lock` with a
 * stale-break heuristic and owner-checked release, mirroring langsmith-go's
 * non-POSIX path. `deadline` is a `Date.now()`-based timestamp; acquisition
 * rejects once it passes. Callers treat any rejection as "skip refresh, use the
 * current token".
 */
export declare function acquireOAuthRefreshLock(configPath: string, deadline: number): Promise<OAuthRefreshLock>;
export declare const _internal: {
    LOCK_METADATA_FILE: string;
    LOCK_STALE_AFTER_MS: number;
    lockOwner: typeof lockOwner;
};
export {};
//# sourceMappingURL=profile-lock.d.mts.map