import wcswidth from "./src/wcswidth.mjs";
import wcwidth from "./src/wcwidth.mjs";
export { wcwidth, wcswidth };
//# sourceMappingURL=index.d.mts.map