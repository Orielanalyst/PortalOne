export interface Interval {
    first: number;
    last: number;
}
//# sourceMappingURL=models.d.mts.map