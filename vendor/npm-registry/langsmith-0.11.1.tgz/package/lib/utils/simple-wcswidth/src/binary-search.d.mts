import { Interval } from "./models.mjs";
declare const bisearch: (ucs: number, table: Interval[], tableSize: number) => number;
export default bisearch;
//# sourceMappingURL=binary-search.d.mts.map