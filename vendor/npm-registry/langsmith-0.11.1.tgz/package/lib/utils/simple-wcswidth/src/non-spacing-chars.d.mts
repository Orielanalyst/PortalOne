import { Interval } from "./models.mjs";
declare const combining: Interval[];
export default combining;
//# sourceMappingURL=non-spacing-chars.d.mts.map