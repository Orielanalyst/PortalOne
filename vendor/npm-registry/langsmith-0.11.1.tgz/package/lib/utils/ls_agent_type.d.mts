export type LsAgentType = "root" | "middleware" | "subagent" | "compaction";
export declare const NON_ROOT_LS_AGENT_TYPES: ReadonlySet<string>;
export declare function resolveDefaultLsAgentType(parentRunTree?: unknown): LsAgentType | undefined;
export declare function lsAgentTypeMetadata(tag: LsAgentType | undefined): {
    ls_agent_type?: LsAgentType;
};
export declare function defaultLsAgentTypeMetadata(existingMetadata: Record<string, unknown>, parentRunTree?: unknown): {
    ls_agent_type?: LsAgentType;
};
//# sourceMappingURL=ls_agent_type.d.mts.map