export declare function atee<T>(iter: AsyncGenerator<T>, length?: number): AsyncGenerator<T>[];
//# sourceMappingURL=atee.d.mts.map