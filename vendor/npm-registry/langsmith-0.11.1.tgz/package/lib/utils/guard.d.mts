/**
 * Check if tracing is enabled for the current run tree or environment.
 *
 * @returns `true` if tracing is enabled, `false` otherwise.
 */
export declare function isTracingEnabled(): boolean;
//# sourceMappingURL=guard.d.mts.map