export declare const getDefaultProjectName: () => string;
//# sourceMappingURL=project.d.mts.map