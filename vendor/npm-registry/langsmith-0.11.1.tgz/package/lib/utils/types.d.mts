export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const isPrimitive: (value: unknown) => value is string | number | boolean;
//# sourceMappingURL=types.d.mts.map