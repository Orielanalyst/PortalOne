import { type AgentAddress, EnvAddressError } from "../address.mjs";
/** One precedence level: the `[project, address]` it names. */
export type Tier = [string | undefined, AgentAddress | undefined];
export declare function rejectConflicting(project: unknown, address: unknown): void;
/** The highest level naming a project or an address, whichever it names. */
export declare function firstNamed(...tiers: Tier[]): Tier;
/**
 * The env's destination: its address, else its project, else "default".
 * @throws {EnvAddressError} For half an address, or an address and a project.
 */
export declare function resolveFromEnv(): Tier;
export declare function logUntraced(error: EnvAddressError): void;
/** Warn once, at client construction, if the env can't address runs. */
export declare function warnOnEnv(): void;
/**
 * Put the run's address in its payload field, in its wire form.
 * Without one, a create naming no project takes the env address.
 *
 * @throws {EnvAddressError} If the env names half an address.
 */
export declare function applyToPayload(run: {
    address?: AgentAddress;
    session_id?: string;
    session_name?: string;
}, { update }?: {
    update?: boolean;
}): void;
//# sourceMappingURL=addressing.d.mts.map