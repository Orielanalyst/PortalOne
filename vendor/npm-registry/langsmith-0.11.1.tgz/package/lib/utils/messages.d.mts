import { LangChainBaseMessage } from "../schemas.mjs";
export declare function isLangChainMessage(message?: any): message is LangChainBaseMessage;
interface ConvertedData {
    content: string;
    [key: string]: any;
}
export declare function convertLangChainMessageToExample(message: LangChainBaseMessage): {
    type: string;
    data: ConvertedData;
};
export {};
//# sourceMappingURL=messages.d.mts.map