import type { Run as V2Run } from "../../resources/runs/runs.mjs";
import type { Client } from "../client.mjs";
import type { Run, TracerSession } from "../schemas.mjs";
export declare const QueryBackend: {
    readonly CLICKHOUSE_ONLY: "clickhouse_only";
    readonly SMITHDB_ONLY: "smithdb_only";
    readonly DUAL: "dual";
};
export type QueryBackend = (typeof QueryBackend)[keyof typeof QueryBackend];
/** Which backend(s) `/info`'s `instance_flags` indicate for run/trace queries. */
export declare function getQueryBackend(instanceFlags?: Record<string, unknown> | null): QueryBackend;
export declare function v2RunToRun(run: V2Run): Run;
export declare function loadTracesV2(client: Client, project: TracerSession, options: {
    isRoot?: boolean;
}): Promise<Run[]>;
//# sourceMappingURL=v2_migration.d.mts.map