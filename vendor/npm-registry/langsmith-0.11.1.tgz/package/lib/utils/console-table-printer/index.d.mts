import Table from "./src/console-table-printer.mjs";
import { printSimpleTable as printTable, renderSimpleTable as renderTable } from "./src/internalTable/internal-table-printer.mjs";
import { COLOR, ALIGNMENT } from "./src/models/external-table.mjs";
export { Table, printTable, renderTable, COLOR, ALIGNMENT };
//# sourceMappingURL=index.d.mts.map