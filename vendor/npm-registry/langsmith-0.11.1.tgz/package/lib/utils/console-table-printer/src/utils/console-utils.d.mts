import { CharLengthDict } from "../models/common.mjs";
export declare const stripAnsi: (str: string) => string;
export declare const findWidthInConsole: (str: string, charLength?: CharLengthDict) => number;
//# sourceMappingURL=console-utils.d.mts.map