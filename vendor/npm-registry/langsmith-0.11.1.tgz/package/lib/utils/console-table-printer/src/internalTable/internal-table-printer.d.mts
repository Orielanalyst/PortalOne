import { Dictionary } from "../models/common.mjs";
import { ComplexOptions } from "../models/external-table.mjs";
import TableInternal from "./internal-table.mjs";
export declare const renderTable: (table: TableInternal) => string;
export declare const renderSimpleTable: (rows: Dictionary[], tableOptions?: ComplexOptions) => string;
export declare const printSimpleTable: (rows: Dictionary[], tableOptions?: ComplexOptions) => void;
//# sourceMappingURL=internal-table-printer.d.mts.map