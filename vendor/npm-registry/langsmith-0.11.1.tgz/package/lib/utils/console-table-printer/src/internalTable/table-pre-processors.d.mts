import TableInternal from "./internal-table.mjs";
export declare const preProcessColumns: (table: TableInternal) => void;
export declare const preProcessRows: (table: TableInternal) => void;
//# sourceMappingURL=table-pre-processors.d.mts.map