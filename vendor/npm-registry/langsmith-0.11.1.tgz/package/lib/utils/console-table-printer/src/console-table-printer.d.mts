import TableInternal from "./internalTable/internal-table.mjs";
import { Dictionary } from "./models/common.mjs";
import { ColumnOptionsRaw, ComplexOptions } from "./models/external-table.mjs";
import { RowOptionsRaw } from "./utils/table-helpers.mjs";
export default class Table {
    table: TableInternal;
    constructor(options?: ComplexOptions | string[]);
    addColumn(column: string | ColumnOptionsRaw): this;
    addColumns(columns: string[] | ColumnOptionsRaw[]): this;
    addRow(text: Dictionary, rowOptions?: RowOptionsRaw): this;
    addRows(toBeInsertedRows: Dictionary[], rowOptions?: RowOptionsRaw): this;
    printTable(): void;
    render(): string;
}
//# sourceMappingURL=console-table-printer.d.mts.map