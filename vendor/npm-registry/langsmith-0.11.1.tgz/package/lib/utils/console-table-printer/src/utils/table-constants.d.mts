import { ALIGNMENT, COLOR } from "../models/common.mjs";
import { TableStyleDetails } from "../models/internal-table.mjs";
export declare const DEFAULT_COLUMN_LEN = 20;
export declare const DEFAULT_ROW_SEPARATOR = false;
export declare const DEFAULT_TABLE_STYLE: TableStyleDetails;
export declare const ALIGNMENTS: string[];
export declare const COLORS: string[];
export declare const DEFAULT_ROW_FONT_COLOR: COLOR;
export declare const DEFAULT_HEADER_FONT_COLOR: COLOR;
export declare const DEFAULT_ROW_ALIGNMENT: ALIGNMENT;
export declare const DEFAULT_HEADER_ALIGNMENT: ALIGNMENT;
//# sourceMappingURL=table-constants.d.mts.map