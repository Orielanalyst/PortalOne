import { ColumnOptionsRaw, ComputedColumn, DefaultColumnOptions } from "../models/external-table.mjs";
import { Column } from "../models/internal-table.mjs";
export declare const objIfExists: (key: string, val: any) => {
    [x: string]: any;
};
export declare const rawColumnToInternalColumn: (column: ColumnOptionsRaw | ComputedColumn, defaultColumnStyles?: DefaultColumnOptions) => Column;
//# sourceMappingURL=input-converter.d.mts.map