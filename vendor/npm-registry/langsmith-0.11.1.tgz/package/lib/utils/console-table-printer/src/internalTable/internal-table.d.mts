import { CharLengthDict, Dictionary, Row } from "../models/common.mjs";
import { ColumnOptionsRaw, ComplexOptions, ComputedColumn, DefaultColumnOptions, RowFilterFunction, RowSortFunction, Valuetransform } from "../models/external-table.mjs";
import { Column, TableStyleDetails } from "../models/internal-table.mjs";
import { ColorMap } from "../utils/colored-console-line.mjs";
import { RowOptions } from "../utils/table-helpers.mjs";
declare class TableInternal {
    title?: string;
    tableStyle: TableStyleDetails;
    columns: Column[];
    rows: Row[];
    filterFunction: RowFilterFunction;
    sortFunction: RowSortFunction;
    enabledColumns: string[];
    disabledColumns: string[];
    computedColumns: ComputedColumn[];
    rowSeparator: boolean;
    colorMap: ColorMap;
    charLength: CharLengthDict;
    defaultColumnOptions?: DefaultColumnOptions;
    transforms?: Record<string, Valuetransform>;
    initSimple(columns: string[]): void;
    initDetailed(options: ComplexOptions): void;
    constructor(options?: ComplexOptions | string[]);
    createColumnFromRow(text: Dictionary): void;
    addColumn(textOrObj: string | ComputedColumn | ColumnOptionsRaw): void;
    addColumns(toBeInsertedColumns: string[] | ColumnOptionsRaw[]): void;
    addRow(text: Dictionary, options?: RowOptions): void;
    addRows(toBeInsertedRows: Dictionary[], options?: RowOptions): void;
    renderTable(): string;
}
export default TableInternal;
//# sourceMappingURL=internal-table.d.mts.map