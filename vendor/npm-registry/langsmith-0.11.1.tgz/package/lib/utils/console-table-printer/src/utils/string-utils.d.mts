import { ALIGNMENT, CharLengthDict } from "../models/common.mjs";
export declare const splitTextIntoTextsOfMinLen: (inpStr: string, width: number, charLength?: CharLengthDict) => string[];
export declare const textWithPadding: (text: string, alignment: ALIGNMENT, columnLen: number, charLength?: CharLengthDict) => string;
export declare const biggestWordInSentence: (inpStr: string, charLength?: CharLengthDict) => number;
//# sourceMappingURL=string-utils.d.mts.map