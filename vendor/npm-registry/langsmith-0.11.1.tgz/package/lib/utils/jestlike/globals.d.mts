import { AsyncLocalStorage } from "node:async_hooks";
import { Dataset, TracerSession, Example } from "../../schemas.mjs";
import { Client, CreateProjectParams } from "../../client.mjs";
import { RunTree } from "../../run_trees.mjs";
import { SimpleEvaluationResult } from "./types.mjs";
export declare const DEFAULT_TEST_CLIENT: Client;
export type TestWrapperAsyncLocalStorageData = {
    enableTestTracking?: boolean;
    dataset?: Dataset;
    createdAt: string;
    projectConfig?: Partial<CreateProjectParams>;
    project?: TracerSession;
    setLoggedOutput?: (value: Record<string, unknown>) => void;
    onFeedbackLogged?: (feedback: SimpleEvaluationResult) => void;
    currentExample?: Partial<Example> & {
        syncPromise?: Promise<Example>;
    };
    client: Client;
    suiteUuid: string;
    suiteName: string;
    testRootRunTree?: RunTree;
    setupPromise?: Promise<void>;
    syncExamplePromises?: Map<string, Promise<Example>>;
};
export declare const testWrapperAsyncLocalStorageInstance: AsyncLocalStorage<TestWrapperAsyncLocalStorageData>;
export declare function trackingEnabled(context: TestWrapperAsyncLocalStorageData): boolean;
export declare const evaluatorLogFeedbackPromises: Set<unknown>;
export declare function _logTestFeedback(params: {
    exampleId?: string;
    feedback: SimpleEvaluationResult;
    context: TestWrapperAsyncLocalStorageData;
    runTree?: RunTree;
    client: Client;
    sourceRunId?: string;
}): void;
//# sourceMappingURL=globals.d.mts.map