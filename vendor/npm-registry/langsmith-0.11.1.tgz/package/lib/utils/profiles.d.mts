export declare const DEFAULT_API_URL = "https://api.smith.langchain.com";
type LangSmithProfileOAuth = {
    access_token?: string;
    refresh_token?: string;
    expires_at?: string;
};
type LangSmithProfile = {
    api_key?: string;
    api_url?: string;
    workspace_id?: string;
    oauth?: LangSmithProfileOAuth;
};
type LangSmithProfileConfigFile = {
    current_profile?: string;
    profiles?: Record<string, LangSmithProfile>;
};
type LangSmithProfileState = {
    configPath: string;
    config: LangSmithProfileConfigFile;
    profileName: string;
    profile: LangSmithProfile;
};
export type ProfileAuthHeader = {
    name: "Authorization" | "x-api-key";
    value: string;
};
export type ProfileClientConfig = {
    apiUrl?: string;
    apiKey?: string;
    workspaceId?: string;
    oauthAccessToken?: string;
    oauthRefreshToken?: string;
    profileAuth?: ProfileAuth;
};
export declare function hasValue(value?: string | null): boolean;
/**
 * Resolve the token endpoint, preferring the deployment's metadata document.
 * Falls back to `<mount>/oauth/token`, keeping a trailing `/api` because
 * self-hosted mounts the authorization server under it.
 */
export declare function resolveTokenEndpoint(apiUrl: string, fetchImplementation: typeof fetch): Promise<string>;
export declare function loadProfileClientConfig(): ProfileClientConfig;
export declare class ProfileAuth {
    private state;
    private refreshPromise?;
    private managedAuthorizationValue?;
    constructor(state: LangSmithProfileState);
    currentAuthHeader(): ProfileAuthHeader | undefined;
    getAuthHeader(fetchImplementation: typeof fetch, signal?: AbortSignal | null): Promise<ProfileAuthHeader | undefined>;
    isProfileAuthorizationHeader(value: string): boolean;
    private reloadProfile;
    private refreshOAuthToken;
    private rememberProfileAuthHeader;
}
export {};
//# sourceMappingURL=profiles.d.mts.map