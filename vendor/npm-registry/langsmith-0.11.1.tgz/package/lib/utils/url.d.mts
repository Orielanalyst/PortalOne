/**
 * Resolve a path the API returned against the client's API URL.
 *
 * Self-hosted deployments return attachment `presigned_url`s as paths such as
 * `/api/v1/public/download?jwt=...`. Mirrors Python's `_construct_url`, including
 * the de-duplication of an `/api` or `/api/v1` suffix already present on apiUrl.
 */
export declare function constructUrl(apiUrl: string, pathname: string): string;
//# sourceMappingURL=url.d.mts.map