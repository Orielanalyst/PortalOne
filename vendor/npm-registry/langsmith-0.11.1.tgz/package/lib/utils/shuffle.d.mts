export declare function shuffle<T extends unknown[]>(array: T): T;
//# sourceMappingURL=shuffle.d.mts.map