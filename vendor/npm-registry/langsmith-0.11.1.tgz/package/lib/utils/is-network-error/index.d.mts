export default function isNetworkError(error: any): boolean;
//# sourceMappingURL=index.d.mts.map