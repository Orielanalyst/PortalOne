import type { KVMap } from "../schemas.mjs";
/** Mask a value, keeping object key names so a trace shows what was set. */
export declare function mask(value: unknown): unknown;
/** Copy `entry`, masking values outside `safeKeys`, so unknown keys fail closed. */
export declare function redactOutside(entry: unknown, safeKeys: ReadonlySet<string>): unknown;
/**
 * Apply `redact` to every object argument, since `traceable` shapes a
 * multi-argument call as `{ args: [params, requestOptions] }`.
 */
export declare function overParams(inputs: KVMap, redact: (params: KVMap) => KVMap): KVMap;
//# sourceMappingURL=redaction.d.mts.map