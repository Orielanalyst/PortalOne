export declare function getOpenAPIBaseUrl(apiUrl: string): string;
//# sourceMappingURL=api_url.d.mts.map