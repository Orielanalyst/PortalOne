export declare const PQueue: typeof import("p-queue").default;
export type PQueueType = InstanceType<typeof PQueue>;
//# sourceMappingURL=p-queue.d.mts.map