import type { LanguageModelV2Usage, LanguageModelV3Usage } from "@ai-sdk/provider";
import { KVMap } from "../schemas.mjs";
export declare function extractOutputTokenDetails(usage?: Partial<LanguageModelV2Usage> | Partial<LanguageModelV3Usage>, providerMetadata?: Record<string, unknown>): Record<string, number> | {
    reasoning?: number;
    flex?: number;
    flex_reasoning?: number;
    priority?: number;
    priority_reasoning?: number;
};
export declare function extractInputTokenDetails(usage?: Partial<LanguageModelV2Usage> | Partial<LanguageModelV3Usage>, providerMetadata?: Record<string, unknown>): Record<string, number> | {
    cache_read?: number;
    cache_creation?: number;
    flex?: number;
    flex_cache_read?: number;
    flex_cache_creation?: number;
    priority?: number;
    priority_cache_read?: number;
    priority_cache_creation?: number;
};
export declare function extractUsageMetadata(span?: {
    status?: {
        code: number;
    };
    attributes?: Record<string, unknown>;
}): KVMap;
//# sourceMappingURL=vercel.d.mts.map