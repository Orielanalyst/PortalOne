/**
 * Deterministic trace sampling, kept consistent across LangSmith SDKs.
 */
/**
 * Decide whether `identifier` is sampled in at `samplingRate`.
 *
 * The decision is a pure function of the identifier, so every process and
 * every SDK agrees on it, and a run's create and patch never disagree.
 */
export declare const isSampledById: (identifier: string | null | undefined, samplingRate: number | undefined) => boolean;
//# sourceMappingURL=sampling.d.mts.map