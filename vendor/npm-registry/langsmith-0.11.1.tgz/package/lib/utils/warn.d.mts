export declare function warnOnce(message: string, options?: {
    type?: string;
    code?: string;
}): void;
//# sourceMappingURL=warn.d.mts.map