export declare const _LC_CONTEXT_VARIABLES_KEY: unique symbol;
export declare const _LC_CHILD_RUN_END_PROMISES_KEY: unique symbol;
export declare const _REPLICA_TRACE_ROOTS_KEY: unique symbol;
export declare const _PROCESSING_FAILED_KEY = "ls_error";
export declare const _PROCESSING_FAILED_PREFIX = "Processing failed; ";
export declare const _processingFailed: (payload: "inputs" | "outputs", hook: string) => string;
//# sourceMappingURL=constants.d.mts.map