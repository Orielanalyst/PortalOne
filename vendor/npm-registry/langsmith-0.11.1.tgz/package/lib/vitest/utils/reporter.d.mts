export declare const printVitestReporterTable: (files: any, ctx: any) => Promise<void>;
export interface VitestTestModule {
    children: {
        allTests: () => Iterable<{
            name: string;
            result: () => {
                state: "pending" | "passed" | "failed" | "skipped";
            };
            diagnostic: () => {
                duration: number;
            } | undefined;
        }>;
    };
    state: () => "pending" | "queued" | "skipped" | "passed" | "failed";
    relativeModuleId: string;
}
export declare const printVitestTestModulesReporterTable: (testModules: readonly VitestTestModule[]) => Promise<void>;
//# sourceMappingURL=reporter.d.mts.map