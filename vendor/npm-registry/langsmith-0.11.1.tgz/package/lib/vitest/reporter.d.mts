import { DefaultReporter } from "vitest/reporters";
import { RunnerTestFile } from "vitest";
declare class LangSmithEvalReporter extends DefaultReporter {
    private skipOnFinished;
    onFinished(files: RunnerTestFile[], errors: unknown[]): Promise<void>;
    onTestRunEnd(...args: Parameters<DefaultReporter["onTestRunEnd"]>): Promise<void>;
}
export default LangSmithEvalReporter;
//# sourceMappingURL=reporter.d.mts.map