"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("./internal/tslib.js");
// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
tslib_1.__exportStar(require("./lib/traceable.js"), exports);
//# sourceMappingURL=traceable.js.map