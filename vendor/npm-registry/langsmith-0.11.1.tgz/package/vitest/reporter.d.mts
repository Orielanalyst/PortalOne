export { default } from '../lib/vitest/reporter.mjs';
//# sourceMappingURL=reporter.d.mts.map