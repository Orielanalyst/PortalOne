export declare const VERSION = "0.11.1";
//# sourceMappingURL=version.d.mts.map