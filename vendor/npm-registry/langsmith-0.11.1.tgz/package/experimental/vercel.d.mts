export * from "../lib/experimental/vercel/index.mjs";
//# sourceMappingURL=vercel.d.mts.map