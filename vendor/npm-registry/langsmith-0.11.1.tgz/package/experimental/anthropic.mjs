// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
export * from "../lib/experimental/anthropic/index.mjs";
//# sourceMappingURL=anthropic.mjs.map