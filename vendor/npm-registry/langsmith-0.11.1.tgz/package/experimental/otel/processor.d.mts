export * from "../../lib/experimental/otel/processor.mjs";
//# sourceMappingURL=processor.d.mts.map