// Entrypoint shim: `langsmith/<name>` -> hand-written code in src/lib (kept from langsmith-sdk).
export * from "../../lib/experimental/otel/processor.mjs";
//# sourceMappingURL=processor.mjs.map