export * from "../../lib/experimental/otel/setup.mjs";
//# sourceMappingURL=setup.d.mts.map