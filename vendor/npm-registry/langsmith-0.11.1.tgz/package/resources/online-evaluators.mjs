// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { OffsetPaginationOnlineEvaluators, } from "../core/pagination.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class OnlineEvaluators extends APIResource {
    /**
     * Create a new LLM or code evaluator for the current workspace.
     */
    create(body, options) {
        return this._client.post('/api/v1/platform/evaluators', { body, ...options });
    }
    /**
     * Retrieve a single evaluator by its ID.
     */
    retrieve(evaluatorID, options) {
        return this._client.get(path `/api/v1/platform/evaluators/${evaluatorID}`, options);
    }
    /**
     * Update an existing evaluator's name, LLM configuration, or code configuration.
     * Returns 409 when a code evaluator build is ENQUEUED or BUILDING.
     */
    update(evaluatorID, body, options) {
        return this._client.patch(path `/api/v1/platform/evaluators/${evaluatorID}`, { body, ...options });
    }
    /**
     * List evaluators for the current workspace, with optional filtering by type,
     * name, tag, feedback key, or resource ID.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v1/platform/evaluators', (OffsetPaginationOnlineEvaluators), { query, ...options });
    }
    /**
     * Delete an evaluator. Returns 409 when a code evaluator build is ENQUEUED or
     * BUILDING, or when run rules still reference the evaluator and delete_run_rules
     * is false. When delete_run_rules is true, all run rules referencing this
     * evaluator are deleted first (same tenant) if the build is not in flight.
     * Associated llm_evaluators and code_evaluators rows are removed by foreign-key
     * cascade when the evaluator row is deleted.
     */
    delete(evaluatorID, params = {}, options) {
        const { delete_run_rules } = params ?? {};
        return this._client.delete(path `/api/v1/platform/evaluators/${evaluatorID}`, {
            query: { delete_run_rules },
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Delete multiple evaluators by their IDs. Returns per-item success/failure.
     */
    bulkDelete(params, options) {
        const { evaluator_ids, delete_run_rules } = params;
        return this._client.delete('/api/v1/platform/evaluators', {
            query: { evaluator_ids, delete_run_rules },
            ...options,
        });
    }
    /**
     * Returns per-day LLM evaluator spend for the requested 7-day period, grouped by
     * evaluator, resource, or run rule. Exactly one of group_by, evaluator_id,
     * session_id, or dataset_id is required. resource_id, type, feedback_key,
     * tag_value_id, and agent_id may be supplied with group_by to narrow listing
     * aggregations.
     */
    spend(query, options) {
        return this._client.get('/api/v1/platform/evaluators/spend', { query, ...options });
    }
}
//# sourceMappingURL=online-evaluators.mjs.map