import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class ProductFeedback extends APIResource {
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     *
     * Submits concise product feedback with optional non-sensitive client details.
     */
    create(params: ProductFeedbackCreateParams, options?: RequestOptions): APIPromise<ProductFeedbackCreateResponse>;
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<ProductFeedbackRetrieveResponse>;
}
export interface ProductFeedbackCreateResponse {
    id: string;
    category: 'BUG' | 'FEATURE_REQUEST' | 'USABILITY' | 'DOCUMENTATION' | 'OTHER';
    created_at: string;
    message: string;
    source: 'LANGSMITH_CLI';
    client?: ProductFeedbackCreateResponse.Client;
}
export declare namespace ProductFeedbackCreateResponse {
    interface Client {
        architecture?: string;
        os?: string;
        version?: string;
    }
}
export interface ProductFeedbackRetrieveResponse {
    id: string;
    category: 'BUG' | 'FEATURE_REQUEST' | 'USABILITY' | 'DOCUMENTATION' | 'OTHER';
    created_at: string;
    message: string;
    source: 'LANGSMITH_CLI';
    client?: ProductFeedbackRetrieveResponse.Client;
}
export declare namespace ProductFeedbackRetrieveResponse {
    interface Client {
        architecture?: string;
        os?: string;
        version?: string;
    }
}
export interface ProductFeedbackCreateParams {
    /**
     * Body param
     */
    category: 'BUG' | 'FEATURE_REQUEST' | 'USABILITY' | 'DOCUMENTATION' | 'OTHER';
    /**
     * Body param
     */
    message: string;
    /**
     * Body param
     */
    source: 'LANGSMITH_CLI';
    /**
     * Body param
     */
    client?: ProductFeedbackCreateParams.Client;
    /**
     * Header param: Idempotency key
     */
    'Idempotency-Key'?: string;
}
export declare namespace ProductFeedbackCreateParams {
    interface Client {
        architecture?: string;
        os?: string;
        version?: string;
    }
}
export declare namespace ProductFeedback {
    export { type ProductFeedbackCreateResponse as ProductFeedbackCreateResponse, type ProductFeedbackRetrieveResponse as ProductFeedbackRetrieveResponse, type ProductFeedbackCreateParams as ProductFeedbackCreateParams, };
}
//# sourceMappingURL=product-feedback.d.mts.map