"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Issues = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class Issues extends resource_1.APIResource {
    /**
     * **Beta:** This endpoint is in active development and may change without notice.
     *
     * Returns one issue for the authenticated tenant.
     */
    retrieve(id, query = {}, options) {
        return this._client.get((0, path_1.path) `/api/v1/platform/issues/${id}`, { query, ...options });
    }
    /**
     * **Beta:** This endpoint is in active development and may change without notice.
     *
     * Returns issues for the authenticated tenant, optionally filtered by session,
     * status, severity, tag, linked trace, or last modified time.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v1/platform/issues', (pagination_1.OffsetPaginationIssues), {
            query,
            ...options,
        });
    }
}
exports.Issues = Issues;
//# sourceMappingURL=issues.js.map