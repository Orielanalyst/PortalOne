// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ExamplesAPI from "./examples.mjs";
import { Examples } from "./examples.mjs";
import * as ExperimentRunsAPI from "./experiment-runs.mjs";
import { ExperimentRuns, } from "./experiment-runs.mjs";
export class Datasets extends APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "examples", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ExamplesAPI.Examples(this._client)
        });
        Object.defineProperty(this, "experimentRuns", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ExperimentRunsAPI.ExperimentRuns(this._client)
        });
    }
}
Datasets.Examples = Examples;
Datasets.ExperimentRuns = ExperimentRuns;
//# sourceMappingURL=datasets.mjs.map