"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Examples = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Examples extends resource_1.APIResource {
    /**
     * Soft-delete an example, preserving prior versions and their attachments. If the
     * latest version is already deleted, the request succeeds without creating another
     * version. Deletion is recorded at the current time or just after the latest
     * version, whichever is later. For future-dated versions, latest reads reflect
     * deletion immediately; timestamp reads reflect deletion only at or after the
     * recorded deletion timestamp.
     */
    delete(exampleID, params, options) {
        const { dataset_id } = params;
        return this._client.delete((0, path_1.path) `/api/v1/platform/datasets/${dataset_id}/examples/${exampleID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Examples = Examples;
//# sourceMappingURL=examples.js.map