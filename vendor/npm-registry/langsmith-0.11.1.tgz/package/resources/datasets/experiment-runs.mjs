// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { ItemsCursorPostPagination, } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class ExperimentRuns extends APIResource {
    /**
     * Returns a paginated page of dataset examples with runs from the requested
     * experiments. Response uses the canonical `{items, next_cursor}` envelope.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     */
    query(datasetID, body, options) {
        return this._client.getAPIList(path `/api/v2/datasets/${datasetID}/experiment-runs`, (ItemsCursorPostPagination), { body, method: 'post', ...options });
    }
}
//# sourceMappingURL=experiment-runs.mjs.map