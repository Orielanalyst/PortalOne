"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Datasets = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ExamplesAPI = tslib_1.__importStar(require("./examples.js"));
const examples_1 = require("./examples.js");
const ExperimentRunsAPI = tslib_1.__importStar(require("./experiment-runs.js"));
const experiment_runs_1 = require("./experiment-runs.js");
class Datasets extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "examples", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ExamplesAPI.Examples(this._client)
        });
        Object.defineProperty(this, "experimentRuns", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ExperimentRunsAPI.ExperimentRuns(this._client)
        });
    }
}
exports.Datasets = Datasets;
Datasets.Examples = examples_1.Examples;
Datasets.ExperimentRuns = experiment_runs_1.ExperimentRuns;
//# sourceMappingURL=datasets.js.map