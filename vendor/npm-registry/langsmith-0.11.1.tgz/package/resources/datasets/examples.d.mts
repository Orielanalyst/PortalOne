import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Examples extends APIResource {
    /**
     * Soft-delete an example, preserving prior versions and their attachments. If the
     * latest version is already deleted, the request succeeds without creating another
     * version. Deletion is recorded at the current time or just after the latest
     * version, whichever is later. For future-dated versions, latest reads reflect
     * deletion immediately; timestamp reads reflect deletion only at or after the
     * recorded deletion timestamp.
     */
    delete(exampleID: string, params: ExampleDeleteParams, options?: RequestOptions): APIPromise<void>;
}
export interface ExampleDeleteParams {
    /**
     * Dataset ID
     */
    dataset_id: string;
}
export declare namespace Examples {
    export { type ExampleDeleteParams as ExampleDeleteParams };
}
//# sourceMappingURL=examples.d.mts.map