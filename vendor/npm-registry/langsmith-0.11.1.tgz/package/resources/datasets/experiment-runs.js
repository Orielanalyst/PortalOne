"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExperimentRuns = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class ExperimentRuns extends resource_1.APIResource {
    /**
     * Returns a paginated page of dataset examples with runs from the requested
     * experiments. Response uses the canonical `{items, next_cursor}` envelope.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     */
    query(datasetID, body, options) {
        return this._client.getAPIList((0, path_1.path) `/api/v2/datasets/${datasetID}/experiment-runs`, (pagination_1.ItemsCursorPostPagination), { body, method: 'post', ...options });
    }
}
exports.ExperimentRuns = ExperimentRuns;
//# sourceMappingURL=experiment-runs.js.map