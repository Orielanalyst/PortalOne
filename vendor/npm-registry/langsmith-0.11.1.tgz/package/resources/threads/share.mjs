// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Share extends APIResource {
    /**
     * Mints a public share token for a thread. Idempotent: sharing an already-shared
     * thread returns the existing token.
     *
     * @example
     * ```ts
     * const share = await client.threads.share.create(
     *   'thread_id',
     *   { project_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327' },
     * );
     * ```
     */
    create(threadID, body, options) {
        return this._client.post(path `/api/v2/threads/${threadID}/share`, { body, ...options });
    }
    /**
     * Returns the share token for a thread. The token is omitted when the thread is
     * not shared. Gated on runs:share so the control's state matches the control's
     * permission.
     *
     * @example
     * ```ts
     * const share = await client.threads.share.retrieve(
     *   'thread_id',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * );
     * ```
     */
    retrieve(threadID, query, options) {
        return this._client.get(path `/api/v2/threads/${threadID}/share`, { query, ...options });
    }
    /**
     * Deletes the share token for a thread. Idempotent: returns 204 whether or not a
     * share token existed. Deliberately does not verify the thread still exists.
     *
     * @example
     * ```ts
     * await client.threads.share.delete('thread_id', {
     *   project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * });
     * ```
     */
    delete(threadID, params, options) {
        const { project_id } = params;
        return this._client.delete(path `/api/v2/threads/${threadID}/share`, {
            query: { project_id },
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=share.mjs.map