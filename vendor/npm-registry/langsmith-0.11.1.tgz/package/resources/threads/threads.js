"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Threads = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ShareAPI = tslib_1.__importStar(require("./share.js"));
const share_1 = require("./share.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Threads extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "share", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ShareAPI.Share(this._client)
        });
    }
    /**
     * GET with body payload — no resources created. Returns aggregate statistics for
     * threads in a tracing project. The response includes the thread counts, run
     * counts, latency percentiles, rates, token totals, and cost totals requested in
     * `select`.
     *
     * Self-hosted deployments require LangSmith `v0.17` or later.
     *
     * @example
     * ```ts
     * const response = await client.threads.aggregateStats({
     *   project_id: '0190a1b2-c3d4-7ef0-a5b6-6ea3a82e9328',
     *   select: [
     *     'THREAD_COUNT',
     *     'TRACE_COUNT',
     *     'TOTAL_TOKENS',
     *     'TOTAL_COST',
     *   ],
     * });
     * ```
     */
    aggregateStats(body, options) {
        return this._client.post('/api/v2/threads/stats', { body, ...options });
    }
    /**
     * Retrieve all traces belonging to a specific thread within a project.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const threadTrace of client.threads.listTraces(
     *   'thread_id',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * )) {
     *   // ...
     * }
     * ```
     */
    listTraces(threadID, query, options) {
        return this._client.getAPIList((0, path_1.path) `/api/v2/threads/${threadID}/traces`, (pagination_1.ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Query threads within a project (session), with cursor-based pagination. Returns
     * threads matching the given time range and optional filters.
     *
     * When `ai_search` is set, `Accept: text/event-stream` is required; requests
     * without it return 406. AI search is unavailable on deployments that route
     * queries to the v1 backend and returns 501 there.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const thread of client.threads.query()) {
     *   // ...
     * }
     * ```
     */
    query(params, options) {
        const { Accept, ...body } = params;
        return this._client.getAPIList('/api/v2/threads/query', (pagination_1.ItemsCursorPostPagination), {
            body,
            method: 'post',
            ...options,
            headers: (0, headers_1.buildHeaders)([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
    /**
     * Compute aggregate stats for a single thread (turn count, latency percentiles,
     * token/cost sums, and detail breakdowns) within a project.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const threadStats = await client.threads.stats(
     *   'thread_id',
     *   {
     *     selects: ['TURNS'],
     *     session_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   },
     * );
     * ```
     */
    stats(threadID, query, options) {
        return this._client.get((0, path_1.path) `/api/v2/threads/${threadID}/stats`, { query, ...options });
    }
}
exports.Threads = Threads;
Threads.Share = share_1.Share;
//# sourceMappingURL=threads.js.map