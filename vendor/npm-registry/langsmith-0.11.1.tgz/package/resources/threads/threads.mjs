// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ShareAPI from "./share.mjs";
import { Share, } from "./share.mjs";
import { ItemsCursorGetPagination, ItemsCursorPostPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Threads extends APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "share", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ShareAPI.Share(this._client)
        });
    }
    /**
     * GET with body payload — no resources created. Returns aggregate statistics for
     * threads in a tracing project. The response includes the thread counts, run
     * counts, latency percentiles, rates, token totals, and cost totals requested in
     * `select`.
     *
     * Self-hosted deployments require LangSmith `v0.17` or later.
     *
     * @example
     * ```ts
     * const response = await client.threads.aggregateStats({
     *   project_id: '0190a1b2-c3d4-7ef0-a5b6-6ea3a82e9328',
     *   select: [
     *     'THREAD_COUNT',
     *     'TRACE_COUNT',
     *     'TOTAL_TOKENS',
     *     'TOTAL_COST',
     *   ],
     * });
     * ```
     */
    aggregateStats(body, options) {
        return this._client.post('/api/v2/threads/stats', { body, ...options });
    }
    /**
     * Retrieve all traces belonging to a specific thread within a project.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const threadTrace of client.threads.listTraces(
     *   'thread_id',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * )) {
     *   // ...
     * }
     * ```
     */
    listTraces(threadID, query, options) {
        return this._client.getAPIList(path `/api/v2/threads/${threadID}/traces`, (ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Query threads within a project (session), with cursor-based pagination. Returns
     * threads matching the given time range and optional filters.
     *
     * When `ai_search` is set, `Accept: text/event-stream` is required; requests
     * without it return 406. AI search is unavailable on deployments that route
     * queries to the v1 backend and returns 501 there.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const thread of client.threads.query()) {
     *   // ...
     * }
     * ```
     */
    query(params, options) {
        const { Accept, ...body } = params;
        return this._client.getAPIList('/api/v2/threads/query', (ItemsCursorPostPagination), {
            body,
            method: 'post',
            ...options,
            headers: buildHeaders([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
    /**
     * Compute aggregate stats for a single thread (turn count, latency percentiles,
     * token/cost sums, and detail breakdowns) within a project.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const threadStats = await client.threads.stats(
     *   'thread_id',
     *   {
     *     selects: ['TURNS'],
     *     session_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   },
     * );
     * ```
     */
    stats(threadID, query, options) {
        return this._client.get(path `/api/v2/threads/${threadID}/stats`, { query, ...options });
    }
}
Threads.Share = Share;
//# sourceMappingURL=threads.mjs.map