import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Share extends APIResource {
    /**
     * Mints a public share token for a thread. Idempotent: sharing an already-shared
     * thread returns the existing token.
     *
     * @example
     * ```ts
     * const share = await client.threads.share.create(
     *   'thread_id',
     *   { project_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327' },
     * );
     * ```
     */
    create(threadID: string, body: ShareCreateParams, options?: RequestOptions): APIPromise<ShareCreateResponse>;
    /**
     * Returns the share token for a thread. The token is omitted when the thread is
     * not shared. Gated on runs:share so the control's state matches the control's
     * permission.
     *
     * @example
     * ```ts
     * const share = await client.threads.share.retrieve(
     *   'thread_id',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * );
     * ```
     */
    retrieve(threadID: string, query: ShareRetrieveParams, options?: RequestOptions): APIPromise<ShareRetrieveResponse>;
    /**
     * Deletes the share token for a thread. Idempotent: returns 204 whether or not a
     * share token existed. Deliberately does not verify the thread still exists.
     *
     * @example
     * ```ts
     * await client.threads.share.delete('thread_id', {
     *   project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * });
     * ```
     */
    delete(threadID: string, params: ShareDeleteParams, options?: RequestOptions): APIPromise<void>;
}
export interface ShareCreateResponse {
    share_token?: string;
}
export interface ShareRetrieveResponse {
    share_token?: string;
}
export interface ShareCreateParams {
    /**
     * project_id is the tracing project UUID containing the thread.
     */
    project_id: string;
}
export interface ShareRetrieveParams {
    /**
     * Project UUID
     */
    project_id: string;
}
export interface ShareDeleteParams {
    /**
     * Project UUID
     */
    project_id: string;
}
export declare namespace Share {
    export { type ShareCreateResponse as ShareCreateResponse, type ShareRetrieveResponse as ShareRetrieveResponse, type ShareCreateParams as ShareCreateParams, type ShareRetrieveParams as ShareRetrieveParams, type ShareDeleteParams as ShareDeleteParams, };
}
//# sourceMappingURL=share.d.mts.map