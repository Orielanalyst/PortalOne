"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnnotationQueues = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ItemsAPI = tslib_1.__importStar(require("./items.js"));
const items_1 = require("./items.js");
const RunsAPI = tslib_1.__importStar(require("./runs.js"));
const runs_1 = require("./runs.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class AnnotationQueues extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "runs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new RunsAPI.Runs(this._client)
        });
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ItemsAPI.Items(this._client)
        });
    }
    /**
     * Get Annotation Queue
     */
    retrieve(queueID, options) {
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${queueID}`, options);
    }
    /**
     * Update Annotation Queue
     */
    update(queueID, body, options) {
        return this._client.patch((0, path_1.path) `/api/v1/annotation-queues/${queueID}`, { body, ...options });
    }
    /**
     * Delete Annotation Queue
     */
    delete(queueID, options) {
        return this._client.delete((0, path_1.path) `/api/v1/annotation-queues/${queueID}`, options);
    }
    /**
     * Create Annotation Queue
     */
    annotationQueues(body, options) {
        return this._client.post('/api/v1/annotation-queues', { body, ...options });
    }
    /**
     * Create Identity Annotation Queue Run Status
     *
     * @deprecated Deprecated: use the annotation queue items create_status method (POST /api/v1/platform/annotation-queues/items/{queue_item_id}/status) instead. Will be removed after Jan 31, 2027.
     */
    createRunStatus(annotationQueueRunID, body, options) {
        return this._client.post((0, path_1.path) `/api/v1/annotation-queues/status/${annotationQueueRunID}`, {
            body,
            ...options,
        });
    }
    /**
     * Export Annotation Queue Archived Runs
     */
    export(queueID, body, options) {
        return this._client.post((0, path_1.path) `/api/v1/annotation-queues/${queueID}/export`, { body, ...options });
    }
    /**
     * Populate annotation queue with runs from an experiment.
     */
    populate(body, options) {
        return this._client.post('/api/v1/annotation-queues/populate', { body, ...options });
    }
    /**
     * Get Annotation Queues
     */
    retrieveAnnotationQueues(query = {}, options) {
        return this._client.getAPIList('/api/v1/annotation-queues', (pagination_1.OffsetPaginationTopLevelArray), { query, ...options });
    }
    /**
     * Get Annotation Queues For Run
     */
    retrieveQueues(runID, options) {
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${runID}/queues`, options);
    }
    /**
     * Get a run from an annotation queue
     *
     * @deprecated Deprecated: use the annotation queue items list and retrieve_placement methods instead, which call GET /api/v1/platform/annotation-queues/{queue_id}/items and GET /api/v1/platform/annotation-queues/{queue_id}/items/{item_id}/placement. Will be removed after Jan 31, 2027.
     */
    retrieveRun(index, params, options) {
        const { queue_id, ...query } = params;
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${queue_id}/run/${index}`, { query, ...options });
    }
    /**
     * Get Size From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count) with the desired status instead. Will be removed after Jan 31, 2027.
     */
    retrieveSize(queueID, query = {}, options) {
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${queueID}/size`, { query, ...options });
    }
    /**
     * Get Total Archived From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count?status=archived) instead. Will be removed after Jan 31, 2027.
     */
    retrieveTotalArchived(queueID, query = {}, options) {
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${queueID}/total_archived`, { query, ...options });
    }
    /**
     * Get Total Size From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count?status=all) instead. Will be removed after Jan 31, 2027.
     */
    retrieveTotalSize(queueID, options) {
        return this._client.get((0, path_1.path) `/api/v1/annotation-queues/${queueID}/total_size`, options);
    }
}
exports.AnnotationQueues = AnnotationQueues;
AnnotationQueues.Runs = runs_1.Runs;
AnnotationQueues.Items = items_1.Items;
//# sourceMappingURL=annotation-queues.js.map