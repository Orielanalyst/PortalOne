// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Runs extends APIResource {
    /**
     * Add Runs To Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items create endpoint (POST /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    create(queueID, params, options) {
        const { body, extend_trace_retention } = params;
        return this._client.post(path `/api/v1/annotation-queues/${queueID}/runs`, {
            query: { extend_trace_retention },
            body: body,
            ...options,
        });
    }
    /**
     * Update Run In Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items update method (PATCH /api/v1/platform/annotation-queues/{queue_id}/items/{item_id}) instead. Will be removed after Jan 31, 2027.
     */
    update(queueRunID, params, options) {
        const { queue_id, ...body } = params;
        return this._client.patch(path `/api/v1/annotation-queues/${queue_id}/runs/${queueRunID}`, {
            body,
            ...options,
        });
    }
    /**
     * Get Runs From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items list method (GET /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    list(queueID, query = {}, options) {
        return this._client.get(path `/api/v1/annotation-queues/${queueID}/runs`, { query, ...options });
    }
    /**
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @deprecated Deprecated: use the annotation queue items create endpoint (POST /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    createByKey(queueID, params, options) {
        const { body, extend_trace_retention } = params;
        return this._client.post(path `/api/v1/annotation-queues/${queueID}/runs/by-key`, {
            query: { extend_trace_retention },
            body: body,
            ...options,
        });
    }
    /**
     * Delete Runs From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items delete_all method (POST /api/v1/platform/annotation-queues/{queue_id}/items/delete) instead. Will be removed after Jan 31, 2027.
     */
    deleteAll(queueID, body, options) {
        return this._client.post(path `/api/v1/annotation-queues/${queueID}/runs/delete`, { body, ...options });
    }
    /**
     * Delete Run From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items delete_all method (POST /api/v1/platform/annotation-queues/{queue_id}/items/delete) with the item ID instead. Will be removed after Jan 31, 2027.
     */
    deleteQueue(queueRunID, params, options) {
        const { queue_id } = params;
        return this._client.delete(path `/api/v1/annotation-queues/${queue_id}/runs/${queueRunID}`, options);
    }
}
//# sourceMappingURL=runs.mjs.map