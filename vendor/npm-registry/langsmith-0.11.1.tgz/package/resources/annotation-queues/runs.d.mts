import { APIResource } from "../../core/resource.mjs";
import * as AnnotationQueuesAPI from "./annotation-queues.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Runs extends APIResource {
    /**
     * Add Runs To Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items create endpoint (POST /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    create(queueID: string, params: RunCreateParams, options?: RequestOptions): APIPromise<RunCreateResponse>;
    /**
     * Update Run In Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items update method (PATCH /api/v1/platform/annotation-queues/{queue_id}/items/{item_id}) instead. Will be removed after Jan 31, 2027.
     */
    update(queueRunID: string, params: RunUpdateParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Get Runs From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items list method (GET /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    list(queueID: string, query?: RunListParams | null | undefined, options?: RequestOptions): APIPromise<RunListResponse>;
    /**
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @deprecated Deprecated: use the annotation queue items create endpoint (POST /api/v1/platform/annotation-queues/{queue_id}/items) instead. Will be removed after Jan 31, 2027.
     */
    createByKey(queueID: string, params: RunCreateByKeyParams, options?: RequestOptions): APIPromise<RunCreateByKeyResponse>;
    /**
     * Delete Runs From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items delete_all method (POST /api/v1/platform/annotation-queues/{queue_id}/items/delete) instead. Will be removed after Jan 31, 2027.
     */
    deleteAll(queueID: string, body: RunDeleteAllParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Delete Run From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items delete_all method (POST /api/v1/platform/annotation-queues/{queue_id}/items/delete) with the item ID instead. Will be removed after Jan 31, 2027.
     */
    deleteQueue(queueRunID: string, params: RunDeleteQueueParams, options?: RequestOptions): APIPromise<unknown>;
}
export type RunCreateResponse = Array<RunCreateResponse.RunCreateResponseItem>;
export declare namespace RunCreateResponse {
    interface RunCreateResponseItem {
        id: string;
        queue_id: string;
        run_id: string;
        added_at?: string;
        last_reviewed_time?: string | null;
        source_proposed_example_id?: string | null;
    }
}
export type RunUpdateResponse = unknown;
export type RunListResponse = Array<AnnotationQueuesAPI.RunSchemaWithAnnotationQueueInfo>;
export type RunCreateByKeyResponse = Array<RunCreateByKeyResponse.RunCreateByKeyResponseItem>;
export declare namespace RunCreateByKeyResponse {
    interface RunCreateByKeyResponseItem {
        id: string;
        queue_id: string;
        run_id: string;
        added_at?: string;
        last_reviewed_time?: string | null;
        source_proposed_example_id?: string | null;
    }
}
export type RunDeleteAllResponse = unknown;
export type RunDeleteQueueResponse = unknown;
export type RunCreateParams = RunCreateParams.RunsUuidArray | RunCreateParams.RunsAnnotationQueueRunAddSchemaArray | RunCreateParams.Variant2;
export declare namespace RunCreateParams {
    interface RunsUuidArray {
        /**
         * Body param
         */
        body: Array<string>;
        /**
         * Query param
         */
        extend_trace_retention?: boolean;
    }
    interface RunsAnnotationQueueRunAddSchemaArray {
        /**
         * Body param
         */
        body: Array<RunsAnnotationQueueRunAddSchemaArray.Body>;
        /**
         * Query param
         */
        extend_trace_retention?: boolean;
    }
    namespace RunsAnnotationQueueRunAddSchemaArray {
        /**
         * Add a single run to AQ (CH path) with an optional back-pointer to the
         * issues-agent proposal that seeded this add. Use when bulk-adding runs that come
         * from different proposals — each row carries its own source_proposed_example_id.
         * For unrelated bulk adds, prefer plain List[UUID] on the same endpoint.
         */
        interface Body {
            run_id: string;
            source_proposed_example_id?: string | null;
        }
    }
    interface Variant2 {
        /**
         * Body param
         */
        body: Array<Variant2.Body>;
        /**
         * Query param
         */
        extend_trace_retention?: boolean;
    }
    namespace Variant2 {
        /**
         * Deprecated: use plain UUID list or AddRunToQueueByKeyRequest instead.
         */
        interface Body {
            /**
             * @deprecated
             */
            run_id: string;
            /**
             * @deprecated
             */
            parent_run_id?: string | null;
            /**
             * @deprecated
             */
            session_id?: string | null;
            /**
             * @deprecated
             */
            start_time?: string | null;
            /**
             * @deprecated
             */
            trace_id?: string | null;
            /**
             * @deprecated
             */
            trace_tier?: 'longlived' | 'shortlived' | null;
        }
    }
}
export interface RunUpdateParams {
    /**
     * Path param
     */
    queue_id: string;
    /**
     * Body param
     */
    added_at?: string | null;
    /**
     * Body param
     */
    last_reviewed_time?: string | null;
}
export interface RunListParams {
    archived?: boolean | null;
    include_stats?: boolean | null;
    limit?: number;
    offset?: number;
    status?: 'needs_my_review' | 'needs_others_review' | 'completed' | null;
}
export interface RunCreateByKeyParams {
    /**
     * Body param
     */
    body: Array<RunCreateByKeyParams.Body>;
    /**
     * Query param
     */
    extend_trace_retention?: boolean;
}
export declare namespace RunCreateByKeyParams {
    /**
     * Add run to AQ by SmithDB key. is_root derived server-side (LSAQ-141).
     */
    interface Body {
        run_id: string;
        session_id: string;
        start_time: string;
        source_proposed_example_id?: string | null;
    }
}
export interface RunDeleteAllParams {
    delete_all?: boolean;
    exclude_run_ids?: Array<string> | null;
    run_ids?: Array<string> | null;
}
export interface RunDeleteQueueParams {
    queue_id: string;
}
export declare namespace Runs {
    export { type RunCreateResponse as RunCreateResponse, type RunUpdateResponse as RunUpdateResponse, type RunListResponse as RunListResponse, type RunCreateByKeyResponse as RunCreateByKeyResponse, type RunDeleteAllResponse as RunDeleteAllResponse, type RunDeleteQueueResponse as RunDeleteQueueResponse, type RunCreateParams as RunCreateParams, type RunUpdateParams as RunUpdateParams, type RunListParams as RunListParams, type RunCreateByKeyParams as RunCreateByKeyParams, type RunDeleteAllParams as RunDeleteAllParams, type RunDeleteQueueParams as RunDeleteQueueParams, };
}
//# sourceMappingURL=runs.d.mts.map