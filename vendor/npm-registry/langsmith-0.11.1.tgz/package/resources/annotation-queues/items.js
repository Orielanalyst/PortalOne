"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Items = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Items extends resource_1.APIResource {
    /**
     * Add RUN or THREAD items to a single annotation queue. RUN items require run_id
     * unless they are created from a suggested example. THREAD items require thread_id
     * and project_id.
     */
    create(queueID, params, options) {
        const { extend_trace_retention, ...body } = params;
        return this._client.post((0, path_1.path) `/api/v1/platform/annotation-queues/${queueID}/items`, {
            query: { extend_trace_retention },
            body,
            ...options,
        });
    }
    /**
     * Partially update mutable timestamps (added_at, last_reviewed_time) for a RUN or
     * THREAD annotation queue item. Omit a field, or pass JSON null, to leave it
     * unchanged.
     */
    update(itemID, params, options) {
        const { queue_id, ...body } = params;
        return this._client.patch((0, path_1.path) `/api/v1/platform/annotation-queues/${queue_id}/items/${itemID}`, {
            body,
            ...options,
        });
    }
    /**
     * List RUN and THREAD items in a single annotation queue for one review status
     * section, with opaque cursor pagination. Optional item_type=RUN|THREAD filters
     * the page. Optional min_start_time/max_start_time bound the item's trace start
     * time; items with no start time are excluded when either bound is set.
     * direction=backward returns items before the supplied cursor. The response
     * contains item metadata only, not expanded run or thread payloads.
     * status=archived returns items whose queue review requirements have been
     * satisfied, not merely items the caller personally marked completed.
     */
    list(queueID, query, options) {
        return this._client.getAPIList((0, path_1.path) `/api/v1/platform/annotation-queues/${queueID}/items`, (pagination_1.ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Log the caller's reviewer status for a RUN or THREAD annotation queue item. A
     * null status re-shows the item for this reviewer.
     */
    createStatus(queueItemID, body, options) {
        return this._client.post((0, path_1.path) `/api/v1/platform/annotation-queues/items/${queueItemID}/status`, {
            body,
            ...options,
        });
    }
    /**
     * Remove RUN or THREAD items from a single annotation queue by item ID. Both
     * active and completed items can be removed.
     */
    deleteAll(queueID, body, options) {
        return this._client.post((0, path_1.path) `/api/v1/platform/annotation-queues/${queueID}/items/delete`, {
            body,
            ...options,
        });
    }
    /**
     * Returns the number of annotation queue items in one status bucket. The two time
     * windows are independent: start_time/end_time bound when an item was archived,
     * min_start_time/max_start_time bound when its trace ran. Items with no trace
     * start time are excluded when either of the latter is set.
     */
    retrieveCount(queueID, query, options) {
        return this._client.get((0, path_1.path) `/api/v1/platform/annotation-queues/${queueID}/items/count`, {
            query,
            ...options,
        });
    }
    /**
     * Resolve a RUN or THREAD item to its current review section and zero-based
     * position for deep linking. The returned cursor counts RUN and THREAD items
     * together, so it is only valid for a list request with no item_type or start-time
     * filter.
     */
    retrievePlacement(itemID, params, options) {
        const { queue_id } = params;
        return this._client.get((0, path_1.path) `/api/v1/platform/annotation-queues/${queue_id}/items/${itemID}/placement`, options);
    }
}
exports.Items = Items;
//# sourceMappingURL=items.js.map