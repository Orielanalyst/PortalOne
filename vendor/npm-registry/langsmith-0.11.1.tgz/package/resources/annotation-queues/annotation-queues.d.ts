import { APIResource } from "../../core/resource.js";
import * as ItemsAPI from "./items.js";
import { ItemCreateParams, ItemCreateResponse, ItemCreateStatusParams, ItemCreateStatusResponse, ItemDeleteAllParams, ItemDeleteAllResponse, ItemListParams, ItemListResponse, ItemListResponsesItemsCursorGetPagination, ItemRetrieveCountParams, ItemRetrieveCountResponse, ItemRetrievePlacementParams, ItemRetrievePlacementResponse, ItemUpdateParams, ItemUpdateResponse, Items } from "./items.js";
import * as RunsAPI from "./runs.js";
import { RunCreateByKeyParams, RunCreateByKeyResponse, RunCreateParams, RunCreateResponse, RunDeleteAllParams, RunDeleteAllResponse, RunDeleteQueueParams, RunDeleteQueueResponse, RunListParams, RunListResponse, RunUpdateParams, RunUpdateResponse, Runs } from "./runs.js";
import * as DatasetsAPI from "../datasets/datasets.js";
import { APIPromise } from "../../core/api-promise.js";
import { OffsetPaginationTopLevelArray, type OffsetPaginationTopLevelArrayParams, PagePromise } from "../../core/pagination.js";
import { RequestOptions } from "../../internal/request-options.js";
import * as RunsAPI_ from "../runs/runs.js";
export declare class AnnotationQueues extends APIResource {
    runs: RunsAPI.Runs;
    items: ItemsAPI.Items;
    /**
     * Get Annotation Queue
     */
    retrieve(queueID: string, options?: RequestOptions): APIPromise<AnnotationQueueRetrieveResponse>;
    /**
     * Update Annotation Queue
     */
    update(queueID: string, body: AnnotationQueueUpdateParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Delete Annotation Queue
     */
    delete(queueID: string, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Create Annotation Queue
     */
    annotationQueues(body: AnnotationQueueAnnotationQueuesParams, options?: RequestOptions): APIPromise<AnnotationQueueSchema>;
    /**
     * Create Identity Annotation Queue Run Status
     *
     * @deprecated Deprecated: use the annotation queue items create_status method (POST /api/v1/platform/annotation-queues/items/{queue_item_id}/status) instead. Will be removed after Jan 31, 2027.
     */
    createRunStatus(annotationQueueRunID: string, body: AnnotationQueueCreateRunStatusParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Export Annotation Queue Archived Runs
     */
    export(queueID: string, body: AnnotationQueueExportParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Populate annotation queue with runs from an experiment.
     */
    populate(body: AnnotationQueuePopulateParams, options?: RequestOptions): APIPromise<unknown>;
    /**
     * Get Annotation Queues
     */
    retrieveAnnotationQueues(query?: AnnotationQueueRetrieveAnnotationQueuesParams | null | undefined, options?: RequestOptions): PagePromise<AnnotationQueueRetrieveAnnotationQueuesResponsesOffsetPaginationTopLevelArray, AnnotationQueueRetrieveAnnotationQueuesResponse>;
    /**
     * Get Annotation Queues For Run
     */
    retrieveQueues(runID: string, options?: RequestOptions): APIPromise<AnnotationQueueRetrieveQueuesResponse>;
    /**
     * Get a run from an annotation queue
     *
     * @deprecated Deprecated: use the annotation queue items list and retrieve_placement methods instead, which call GET /api/v1/platform/annotation-queues/{queue_id}/items and GET /api/v1/platform/annotation-queues/{queue_id}/items/{item_id}/placement. Will be removed after Jan 31, 2027.
     */
    retrieveRun(index: number, params: AnnotationQueueRetrieveRunParams, options?: RequestOptions): APIPromise<RunSchemaWithAnnotationQueueInfo>;
    /**
     * Get Size From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count) with the desired status instead. Will be removed after Jan 31, 2027.
     */
    retrieveSize(queueID: string, query?: AnnotationQueueRetrieveSizeParams | null | undefined, options?: RequestOptions): APIPromise<AnnotationQueueSizeSchema>;
    /**
     * Get Total Archived From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count?status=archived) instead. Will be removed after Jan 31, 2027.
     */
    retrieveTotalArchived(queueID: string, query?: AnnotationQueueRetrieveTotalArchivedParams | null | undefined, options?: RequestOptions): APIPromise<AnnotationQueueSizeSchema>;
    /**
     * Get Total Size From Annotation Queue
     *
     * @deprecated Deprecated: use the annotation queue items retrieve_count method (GET /api/v1/platform/annotation-queues/{queue_id}/items/count?status=all) instead. Will be removed after Jan 31, 2027.
     */
    retrieveTotalSize(queueID: string, options?: RequestOptions): APIPromise<AnnotationQueueSizeSchema>;
}
export type AnnotationQueueRetrieveAnnotationQueuesResponsesOffsetPaginationTopLevelArray = OffsetPaginationTopLevelArray<AnnotationQueueRetrieveAnnotationQueuesResponse>;
export interface AnnotationQueueRubricItemSchema {
    feedback_key: string;
    description?: string | null;
    feedback_config?: AnnotationQueueRubricItemSchema.FeedbackConfig | null;
    feedback_config_id?: string | null;
    is_assertion?: boolean | null;
    is_required?: boolean | null;
    regex_validator?: string | DatasetsAPI.Missing | null;
    score_descriptions?: {
        [key: string]: string;
    } | null;
    value_descriptions?: {
        [key: string]: string;
    } | null;
}
export declare namespace AnnotationQueueRubricItemSchema {
    interface FeedbackConfig {
        id: string;
        feedback_config: FeedbackConfig.FeedbackConfig;
        feedback_key: string;
        modified_at: string;
        tenant_id: string;
        is_deleted?: boolean;
        is_enforced?: boolean;
        is_first?: boolean;
        is_lower_score_better?: boolean | null;
    }
    namespace FeedbackConfig {
        interface FeedbackConfig {
            /**
             * Enum for feedback types.
             */
            type: 'continuous' | 'categorical' | 'freeform';
            categories?: Array<FeedbackConfig.Category> | null;
            max?: number | null;
            min?: number | null;
        }
        namespace FeedbackConfig {
            /**
             * Specific value and label pair for feedback
             */
            interface Category {
                value: number;
                label?: string | null;
            }
        }
    }
}
/**
 * AnnotationQueue schema.
 */
export interface AnnotationQueueSchema {
    id: string;
    name: string;
    queue_type: 'single' | 'pairwise';
    tenant_id: string;
    assigned_reviewers?: Array<AnnotationQueueSchema.AssignedReviewer>;
    created_at?: string;
    default_dataset?: string | null;
    description?: string | null;
    enable_reservations?: boolean | null;
    metadata?: {
        [key: string]: unknown;
    } | null;
    num_reviewers_per_item?: number | null;
    reservation_minutes?: number | null;
    reviewer_access_mode?: string;
    run_rule_id?: string | null;
    source_rule_id?: string | null;
    updated_at?: string;
}
export declare namespace AnnotationQueueSchema {
    /**
     * Identity info for an assigned reviewer on an annotation queue.
     */
    interface AssignedReviewer {
        id: string;
        email?: string | null;
        name?: string | null;
    }
}
/**
 * Size of an Annotation Queue
 */
export interface AnnotationQueueSizeSchema {
    size: number;
}
/**
 * Run schema with annotation queue info.
 */
export interface RunSchemaWithAnnotationQueueInfo {
    id: string;
    app_path: string;
    dotted_order: string;
    name: string;
    queue_run_id: string;
    /**
     * Enum for run types.
     */
    run_type: RunsAPI_.RunTypeEnum;
    session_id: string;
    status: string;
    trace_id: string;
    added_at?: string | null;
    child_run_ids?: Array<string> | null;
    completed_by?: Array<string>;
    completion_cost?: string | null;
    completion_cost_details?: {
        [key: string]: string;
    } | null;
    completion_token_details?: {
        [key: string]: number;
    } | null;
    completion_tokens?: number;
    direct_child_run_ids?: Array<string> | null;
    effective_added_at?: string | null;
    end_time?: string | null;
    error?: string | null;
    events?: Array<{
        [key: string]: unknown;
    }> | null;
    execution_order?: number;
    extra?: {
        [key: string]: unknown;
    } | null;
    feedback_stats?: {
        [key: string]: {
            [key: string]: unknown;
        };
    } | null;
    first_token_time?: string | null;
    in_dataset?: boolean | null;
    inputs?: {
        [key: string]: unknown;
    } | null;
    inputs_preview?: string | null;
    inputs_s3_urls?: {
        [key: string]: unknown;
    } | null;
    last_queued_at?: string | null;
    last_reviewed_time?: string | null;
    manifest_id?: string | null;
    manifest_s3_id?: string | null;
    messages?: Array<{
        [key: string]: unknown;
    }> | null;
    outputs?: {
        [key: string]: unknown;
    } | null;
    outputs_preview?: string | null;
    outputs_s3_urls?: {
        [key: string]: unknown;
    } | null;
    parent_run_id?: string | null;
    parent_run_ids?: Array<string> | null;
    price_model_id?: string | null;
    prompt_cost?: string | null;
    prompt_cost_details?: {
        [key: string]: string;
    } | null;
    prompt_token_details?: {
        [key: string]: number;
    } | null;
    prompt_tokens?: number;
    reference_dataset_id?: string | null;
    reference_example_id?: string | null;
    reserved_by?: Array<string>;
    s3_urls?: {
        [key: string]: unknown;
    } | null;
    serialized?: {
        [key: string]: unknown;
    } | null;
    share_token?: string | null;
    source_proposed_example_id?: string | null;
    start_time?: string;
    tags?: Array<string> | null;
    thread_id?: string | null;
    total_cost?: string | null;
    total_tokens?: number;
    trace_first_received_at?: string | null;
    trace_max_start_time?: string | null;
    trace_min_start_time?: string | null;
    trace_tier?: 'longlived' | 'shortlived' | null;
    trace_upgrade?: boolean;
    ttl_seconds?: number | null;
}
/**
 * AnnotationQueue schema with rubric.
 */
export interface AnnotationQueueRetrieveResponse {
    id: string;
    name: string;
    queue_type: 'single' | 'pairwise';
    tenant_id: string;
    assigned_reviewers?: Array<AnnotationQueueRetrieveResponse.AssignedReviewer>;
    created_at?: string;
    default_dataset?: string | null;
    description?: string | null;
    enable_reservations?: boolean | null;
    metadata?: {
        [key: string]: unknown;
    } | null;
    num_reviewers_per_item?: number | null;
    reservation_minutes?: number | null;
    reviewer_access_mode?: string;
    rubric_instructions?: string | null;
    rubric_items?: Array<AnnotationQueueRubricItemSchema> | null;
    run_rule_id?: string | null;
    source_rule_id?: string | null;
    updated_at?: string;
}
export declare namespace AnnotationQueueRetrieveResponse {
    /**
     * Identity info for an assigned reviewer on an annotation queue.
     */
    interface AssignedReviewer {
        id: string;
        email?: string | null;
        name?: string | null;
    }
}
export type AnnotationQueueUpdateResponse = unknown;
export type AnnotationQueueDeleteResponse = unknown;
export type AnnotationQueueCreateRunStatusResponse = unknown;
export type AnnotationQueueExportResponse = unknown;
export type AnnotationQueuePopulateResponse = unknown;
/**
 * AnnotationQueue schema with size.
 */
export interface AnnotationQueueRetrieveAnnotationQueuesResponse {
    id: string;
    name: string;
    queue_type: 'single' | 'pairwise';
    tenant_id: string;
    total_runs: number;
    assigned_reviewers?: Array<AnnotationQueueRetrieveAnnotationQueuesResponse.AssignedReviewer>;
    created_at?: string;
    default_dataset?: string | null;
    description?: string | null;
    enable_reservations?: boolean | null;
    metadata?: {
        [key: string]: unknown;
    } | null;
    num_reviewers_per_item?: number | null;
    reservation_minutes?: number | null;
    reviewer_access_mode?: string;
    run_rule_id?: string | null;
    source_rule_id?: string | null;
    updated_at?: string;
}
export declare namespace AnnotationQueueRetrieveAnnotationQueuesResponse {
    /**
     * Identity info for an assigned reviewer on an annotation queue.
     */
    interface AssignedReviewer {
        id: string;
        email?: string | null;
        name?: string | null;
    }
}
export type AnnotationQueueRetrieveQueuesResponse = Array<AnnotationQueueSchema>;
export interface AnnotationQueueUpdateParams {
    default_dataset?: string | null;
    description?: string | null;
    enable_reservations?: boolean | DatasetsAPI.Missing;
    metadata?: {
        [key: string]: unknown;
    } | DatasetsAPI.Missing | null;
    name?: string | null;
    num_reviewers_per_item?: number | DatasetsAPI.Missing | null;
    reservation_minutes?: number | DatasetsAPI.Missing | null;
    reviewer_access_mode?: 'any' | 'assigned' | null;
    rubric_instructions?: string | null;
    rubric_items?: Array<AnnotationQueueRubricItemSchema> | null;
}
export interface AnnotationQueueAnnotationQueuesParams {
    name: string;
    id?: string;
    created_at?: string;
    default_dataset?: string | null;
    description?: string | null;
    enable_reservations?: boolean | null;
    metadata?: {
        [key: string]: unknown;
    } | null;
    num_reviewers_per_item?: number | null;
    reservation_minutes?: number | null;
    reviewer_access_mode?: string;
    rubric_instructions?: string | null;
    rubric_items?: Array<AnnotationQueueRubricItemSchema> | null;
    session_ids?: Array<string> | null;
    updated_at?: string;
}
export interface AnnotationQueueCreateRunStatusParams {
    override_added_at?: string | null;
    status?: string | null;
}
export interface AnnotationQueueExportParams {
    end_time?: string | null;
    include_annotator_detail?: boolean;
    start_time?: string | null;
}
export interface AnnotationQueuePopulateParams {
    queue_id: string;
    session_ids: Array<string>;
    extend_trace_retention?: boolean;
}
export interface AnnotationQueueRetrieveAnnotationQueuesParams extends OffsetPaginationTopLevelArrayParams {
    assigned_to_me?: boolean;
    dataset_id?: string | null;
    ids?: Array<string> | null;
    name?: string | null;
    name_contains?: string | null;
    queue_type?: 'single' | 'pairwise' | null;
    sort_by?: string | null;
    sort_by_desc?: boolean;
    tag_value_id?: Array<string> | null;
}
export interface AnnotationQueueRetrieveRunParams {
    /**
     * Path param
     */
    queue_id: string;
    /**
     * Query param
     */
    include_extra?: boolean;
}
export interface AnnotationQueueRetrieveSizeParams {
    status?: 'needs_my_review' | 'needs_others_review' | 'completed' | null;
}
export interface AnnotationQueueRetrieveTotalArchivedParams {
    end_time?: string | null;
    start_time?: string | null;
}
export declare namespace AnnotationQueues {
    export { type AnnotationQueueRubricItemSchema as AnnotationQueueRubricItemSchema, type AnnotationQueueSchema as AnnotationQueueSchema, type AnnotationQueueSizeSchema as AnnotationQueueSizeSchema, type RunSchemaWithAnnotationQueueInfo as RunSchemaWithAnnotationQueueInfo, type AnnotationQueueRetrieveResponse as AnnotationQueueRetrieveResponse, type AnnotationQueueUpdateResponse as AnnotationQueueUpdateResponse, type AnnotationQueueDeleteResponse as AnnotationQueueDeleteResponse, type AnnotationQueueCreateRunStatusResponse as AnnotationQueueCreateRunStatusResponse, type AnnotationQueueExportResponse as AnnotationQueueExportResponse, type AnnotationQueuePopulateResponse as AnnotationQueuePopulateResponse, type AnnotationQueueRetrieveAnnotationQueuesResponse as AnnotationQueueRetrieveAnnotationQueuesResponse, type AnnotationQueueRetrieveQueuesResponse as AnnotationQueueRetrieveQueuesResponse, type AnnotationQueueRetrieveAnnotationQueuesResponsesOffsetPaginationTopLevelArray as AnnotationQueueRetrieveAnnotationQueuesResponsesOffsetPaginationTopLevelArray, type AnnotationQueueUpdateParams as AnnotationQueueUpdateParams, type AnnotationQueueAnnotationQueuesParams as AnnotationQueueAnnotationQueuesParams, type AnnotationQueueCreateRunStatusParams as AnnotationQueueCreateRunStatusParams, type AnnotationQueueExportParams as AnnotationQueueExportParams, type AnnotationQueuePopulateParams as AnnotationQueuePopulateParams, type AnnotationQueueRetrieveAnnotationQueuesParams as AnnotationQueueRetrieveAnnotationQueuesParams, type AnnotationQueueRetrieveRunParams as AnnotationQueueRetrieveRunParams, type AnnotationQueueRetrieveSizeParams as AnnotationQueueRetrieveSizeParams, type AnnotationQueueRetrieveTotalArchivedParams as AnnotationQueueRetrieveTotalArchivedParams, };
    export { Runs as Runs, type RunCreateResponse as RunCreateResponse, type RunUpdateResponse as RunUpdateResponse, type RunListResponse as RunListResponse, type RunCreateByKeyResponse as RunCreateByKeyResponse, type RunDeleteAllResponse as RunDeleteAllResponse, type RunDeleteQueueResponse as RunDeleteQueueResponse, type RunCreateParams as RunCreateParams, type RunUpdateParams as RunUpdateParams, type RunListParams as RunListParams, type RunCreateByKeyParams as RunCreateByKeyParams, type RunDeleteAllParams as RunDeleteAllParams, type RunDeleteQueueParams as RunDeleteQueueParams, };
    export { Items as Items, type ItemCreateResponse as ItemCreateResponse, type ItemUpdateResponse as ItemUpdateResponse, type ItemListResponse as ItemListResponse, type ItemCreateStatusResponse as ItemCreateStatusResponse, type ItemDeleteAllResponse as ItemDeleteAllResponse, type ItemRetrieveCountResponse as ItemRetrieveCountResponse, type ItemRetrievePlacementResponse as ItemRetrievePlacementResponse, type ItemListResponsesItemsCursorGetPagination as ItemListResponsesItemsCursorGetPagination, type ItemCreateParams as ItemCreateParams, type ItemUpdateParams as ItemUpdateParams, type ItemListParams as ItemListParams, type ItemCreateStatusParams as ItemCreateStatusParams, type ItemDeleteAllParams as ItemDeleteAllParams, type ItemRetrieveCountParams as ItemRetrieveCountParams, type ItemRetrievePlacementParams as ItemRetrievePlacementParams, };
}
//# sourceMappingURL=annotation-queues.d.ts.map