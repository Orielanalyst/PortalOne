"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.OnlineEvaluators = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class OnlineEvaluators extends resource_1.APIResource {
    /**
     * Create a new LLM or code evaluator for the current workspace.
     */
    create(body, options) {
        return this._client.post('/api/v1/platform/evaluators', { body, ...options });
    }
    /**
     * Retrieve a single evaluator by its ID.
     */
    retrieve(evaluatorID, options) {
        return this._client.get((0, path_1.path) `/api/v1/platform/evaluators/${evaluatorID}`, options);
    }
    /**
     * Update an existing evaluator's name, LLM configuration, or code configuration.
     * Returns 409 when a code evaluator build is ENQUEUED or BUILDING.
     */
    update(evaluatorID, body, options) {
        return this._client.patch((0, path_1.path) `/api/v1/platform/evaluators/${evaluatorID}`, { body, ...options });
    }
    /**
     * List evaluators for the current workspace, with optional filtering by type,
     * name, tag, feedback key, or resource ID.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v1/platform/evaluators', (pagination_1.OffsetPaginationOnlineEvaluators), { query, ...options });
    }
    /**
     * Delete an evaluator. Returns 409 when a code evaluator build is ENQUEUED or
     * BUILDING, or when run rules still reference the evaluator and delete_run_rules
     * is false. When delete_run_rules is true, all run rules referencing this
     * evaluator are deleted first (same tenant) if the build is not in flight.
     * Associated llm_evaluators and code_evaluators rows are removed by foreign-key
     * cascade when the evaluator row is deleted.
     */
    delete(evaluatorID, params = {}, options) {
        const { delete_run_rules } = params ?? {};
        return this._client.delete((0, path_1.path) `/api/v1/platform/evaluators/${evaluatorID}`, {
            query: { delete_run_rules },
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Delete multiple evaluators by their IDs. Returns per-item success/failure.
     */
    bulkDelete(params, options) {
        const { evaluator_ids, delete_run_rules } = params;
        return this._client.delete('/api/v1/platform/evaluators', {
            query: { evaluator_ids, delete_run_rules },
            ...options,
        });
    }
    /**
     * Returns per-day LLM evaluator spend for the requested 7-day period, grouped by
     * evaluator, resource, or run rule. Exactly one of group_by, evaluator_id,
     * session_id, or dataset_id is required. resource_id, type, feedback_key,
     * tag_value_id, and agent_id may be supplied with group_by to narrow listing
     * aggregations.
     */
    spend(query, options) {
        return this._client.get('/api/v1/platform/evaluators/spend', { query, ...options });
    }
}
exports.OnlineEvaluators = OnlineEvaluators;
//# sourceMappingURL=online-evaluators.js.map