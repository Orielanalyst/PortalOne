"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fleet = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ThreadsAPI = tslib_1.__importStar(require("./threads.js"));
const threads_1 = require("./threads.js");
class Fleet extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "threads", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ThreadsAPI.Threads(this._client)
        });
    }
}
exports.Fleet = Fleet;
Fleet.Threads = threads_1.Threads;
//# sourceMappingURL=fleet.js.map