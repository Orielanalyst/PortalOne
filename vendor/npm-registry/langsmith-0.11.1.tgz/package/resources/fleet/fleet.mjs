// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ThreadsAPI from "./threads.mjs";
import { Threads } from "./threads.mjs";
export class Fleet extends APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "threads", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ThreadsAPI.Threads(this._client)
        });
    }
}
Fleet.Threads = Threads;
//# sourceMappingURL=fleet.mjs.map