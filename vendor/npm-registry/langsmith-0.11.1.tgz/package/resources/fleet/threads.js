"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Threads = void 0;
const resource_1 = require("../../core/resource.js");
const path_1 = require("../../internal/utils/path.js");
class Threads extends resource_1.APIResource {
    /**
     * Starts or resumes the sandbox referenced by the thread and returns when it is
     * ready. The operation is idempotent. The thread must include
     * sandbox.sandbox_slug.
     */
    activateSandbox(threadID, options) {
        return this._client.post((0, path_1.path) `/v1/fleet/threads/${threadID}/sandbox-activation`, options);
    }
}
exports.Threads = Threads;
//# sourceMappingURL=threads.js.map