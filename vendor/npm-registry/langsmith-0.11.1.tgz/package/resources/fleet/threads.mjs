// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Threads extends APIResource {
    /**
     * Starts or resumes the sandbox referenced by the thread and returns when it is
     * ready. The operation is idempotent. The thread must include
     * sandbox.sandbox_slug.
     */
    activateSandbox(threadID, options) {
        return this._client.post(path `/v1/fleet/threads/${threadID}/sandbox-activation`, options);
    }
}
//# sourceMappingURL=threads.mjs.map