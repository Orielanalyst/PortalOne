import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Threads extends APIResource {
    /**
     * Starts or resumes the sandbox referenced by the thread and returns when it is
     * ready. The operation is idempotent. The thread must include
     * sandbox.sandbox_slug.
     */
    activateSandbox(threadID: string, options?: RequestOptions): APIPromise<ThreadActivateSandboxResponse>;
}
export interface ThreadActivateSandboxResponse {
    sandbox_slug: string;
    scope: 'agent' | 'thread';
    status: 'provisioning' | 'ready' | 'failed' | 'stopped' | 'deleting';
}
export declare namespace Threads {
    export { type ThreadActivateSandboxResponse as ThreadActivateSandboxResponse };
}
//# sourceMappingURL=threads.d.mts.map