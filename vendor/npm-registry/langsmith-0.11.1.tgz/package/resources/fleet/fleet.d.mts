import { APIResource } from "../../core/resource.mjs";
import * as ThreadsAPI from "./threads.mjs";
import { ThreadActivateSandboxResponse, Threads } from "./threads.mjs";
export declare class Fleet extends APIResource {
    threads: ThreadsAPI.Threads;
}
export declare namespace Fleet {
    export { Threads as Threads, type ThreadActivateSandboxResponse as ThreadActivateSandboxResponse };
}
//# sourceMappingURL=fleet.d.mts.map