"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agents = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Agents extends resource_1.APIResource {
    /**
     * Creates an Agent with a caller-assigned ID. Returns 409 if the ID already
     * exists. Creates all four environments unless production_only is set for a FLEET
     * agent. source_type defaults to EXTERNAL in this SDK. agent_type defaults to
     * CUSTOM. The authenticated user becomes the owner
     * when available. Requires permission to create projects. The response does not
     * include runtime bindings.
     */
    create(body, options) {
        return this._client.post('/api/v1/agents', {
            body: { ...body, source_type: body.source_type === undefined ? 'EXTERNAL' : body.source_type },
            ...options,
        });
    }
    /**
     * Returns an Agent with the environments visible to the caller. The path value is
     * the user-assigned Agent ID. Pass include=runtime_bindings to embed each
     * environment's runtime bindings.
     */
    retrieve(agentID, query = {}, options) {
        return this._client.get((0, path_1.path) `/api/v1/agents/${agentID}`, { query, ...options });
    }
    /**
     * Updates an Agent's name, source_type, agent_type, or owner_id. Omitted fields
     * keep their values. Changing or clearing owner_id additionally requires
     * workspaces:manage; assigning an owner also requires workspaces:read and active
     * workspace membership. Fleet ownership cannot be changed through this endpoint.
     * Changing agent_type requires workspaces:manage in addition to project update
     * access; repeating the current type is a no-op. Source type can change only for
     * an EXTERNAL Agent without runtime bindings. The id is immutable and is rejected
     * when present. Requires update permission on every environment project.
     */
    update(agentID, body, options) {
        return this._client.patch((0, path_1.path) `/api/v1/agents/${agentID}`, { body, ...options });
    }
    /**
     * Returns Agents visible to the caller. Each item is the same Agent shape as GET
     * /api/v1/agents/{agent_id}, including the environments the caller may read. The
     * list never embeds runtime bindings. An unknown query parameter, including limit,
     * returns 400; use page_size to set the page size.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v1/agents', (pagination_1.ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Permanently deletes an Agent, along with its environments, runtime bindings,
     * runtimes, and tracing projects. This cannot be undone. Deleting an Agent that
     * does not exist returns 204.
     */
    delete(agentID, options) {
        return this._client.delete((0, path_1.path) `/api/v1/agents/${agentID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Agents = Agents;
//# sourceMappingURL=agents.js.map