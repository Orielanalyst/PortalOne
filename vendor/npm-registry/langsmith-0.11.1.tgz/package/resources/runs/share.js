"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Share = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Share extends resource_1.APIResource {
    /**
     * Creates or returns a share token for a run. Child runs share their trace root.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const share = await client.runs.share.create(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   {
     *     session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *     trace_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *   },
     * );
     * ```
     */
    create(runID, body, options) {
        return this._client.post((0, path_1.path) `/api/v2/runs/${runID}/share`, { body, ...options });
    }
    /**
     * Deletes the share token for the trace identified by trace_id and session_id.
     * Idempotent: returns 204 whether or not a share token existed.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * await client.runs.share.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327' },
     * );
     * ```
     */
    delete(traceID, body, options) {
        return this._client.delete((0, path_1.path) `/api/v2/runs/${traceID}/share`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Share = Share;
//# sourceMappingURL=share.js.map