// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Share extends APIResource {
    /**
     * Creates or returns a share token for a run. Child runs share their trace root.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const share = await client.runs.share.create(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   {
     *     session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *     trace_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *   },
     * );
     * ```
     */
    create(runID, body, options) {
        return this._client.post(path `/api/v2/runs/${runID}/share`, { body, ...options });
    }
    /**
     * Deletes the share token for the trace identified by trace_id and session_id.
     * Idempotent: returns 204 whether or not a share token existed.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * await client.runs.share.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327' },
     * );
     * ```
     */
    delete(traceID, body, options) {
        return this._client.delete(path `/api/v2/runs/${traceID}/share`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=share.mjs.map