"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Runs = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ShareAPI = tslib_1.__importStar(require("./share.js"));
const share_1 = require("./share.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Runs extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "share", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new ShareAPI.Share(this._client)
        });
        Object.defineProperty(this, "retrieve", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this.retrieveV2
        });
        Object.defineProperty(this, "query", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this.queryV2
        });
    }
    /**
     * Returns the URL to view a specific run in the LangSmith UI. The caller must
     * supply the run's project_id and trace_id as query parameters; start_time is
     * optional.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const response = await client.runs.getURL(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { project_id: 'project_id', trace_id: 'trace_id' },
     * );
     * ```
     */
    getURL(runID, query, options) {
        return this._client.get((0, path_1.path) `/api/v2/runs/${runID}/url`, { query, ...options });
    }
    /**
     * Returns a paginated list of runs for the given projects within min/max
     * start_time. Supports filters, cursor pagination, and `selects` to select fields
     * to return.
     *
     * When `ai_search` is set, `Accept: text/event-stream` is required; requests
     * without it return 406. AI search is unavailable on deployments that route
     * queries to the v1 backend and returns 501 there.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const run of client.runs.queryV2()) {
     *   // ...
     * }
     * ```
     */
    queryV2(params, options) {
        const { Accept, ...body } = params;
        return this._client.getAPIList('/api/v2/runs/query', (pagination_1.ItemsCursorPostPagination), {
            body,
            method: 'post',
            ...options,
            headers: (0, headers_1.buildHeaders)([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
    /**
     * Returns one run by ID for the given session. Use the `selects` query parameter
     * (repeatable) to select fields to return.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const run = await client.runs.retrieveV2(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * );
     * ```
     */
    retrieveV2(runID, params, options) {
        const { Accept, ...query } = params;
        return this._client.get((0, path_1.path) `/api/v2/runs/${runID}`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
}
exports.Runs = Runs;
Runs.Share = share_1.Share;
//# sourceMappingURL=runs.js.map