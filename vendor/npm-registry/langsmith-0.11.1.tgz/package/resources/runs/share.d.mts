import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Share extends APIResource {
    /**
     * Creates or returns a share token for a run. Child runs share their trace root.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const share = await client.runs.share.create(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   {
     *     session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *     trace_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327',
     *   },
     * );
     * ```
     */
    create(runID: string, body: ShareCreateParams, options?: RequestOptions): APIPromise<ShareCreateResponse>;
    /**
     * Deletes the share token for the trace identified by trace_id and session_id.
     * Idempotent: returns 204 whether or not a share token existed.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * await client.runs.share.delete(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { session_id: '018e4c7e-a9fb-7ef0-a5b6-6ea3a82e9327' },
     * );
     * ```
     */
    delete(traceID: string, body: ShareDeleteParams, options?: RequestOptions): APIPromise<void>;
}
export interface ShareCreateResponse {
    share_token?: string;
}
export interface ShareCreateParams {
    /**
     * session_id is the tracing project UUID containing the trace.
     */
    session_id: string;
    /**
     * trace_id is the root trace UUID to share.
     */
    trace_id: string;
}
export interface ShareDeleteParams {
    /**
     * session_id is the tracing project UUID containing the trace.
     */
    session_id: string;
}
export declare namespace Share {
    export { type ShareCreateResponse as ShareCreateResponse, type ShareCreateParams as ShareCreateParams, type ShareDeleteParams as ShareDeleteParams, };
}
//# sourceMappingURL=share.d.mts.map