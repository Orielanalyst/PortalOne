"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Traces = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Traces extends resource_1.APIResource {
    /**
     * Returns runs for a trace ID within min/max start time. Optional `filter`;
     * repeatable `selects` to select fields to return.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const response = await client.traces.listRuns(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   { project_id: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e' },
     * );
     * ```
     */
    listRuns(traceID, params, options) {
        const { Accept, ...query } = params;
        return this._client.get((0, path_1.path) `/api/v2/traces/${traceID}/runs`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
    /**
     * Returns a paginated list of traces (root runs) for a single tracing project.
     * Each item carries the trace's root run plus optional trace-wide aggregates
     * (`total_tokens`, `total_cost`, `first_token_time`) under `trace_aggregates`, so
     * clients never have to merge by `trace_id`.
     *
     * Traces are scanned within a `start_time` window: `min_start_time` defaults to 24
     * hours before the request, `max_start_time` defaults to the request time. Set
     * either explicitly to widen or narrow the window.
     *
     * Supports filters (`trace_filter`, `tree_filter`), cursor pagination (`cursor`),
     * and field projection (`selects`).
     *
     * When `ai_search` is set, `Accept: text/event-stream` is required; requests
     * without it return 406. AI search is unavailable on deployments that route
     * queries to the v1 backend and returns 501 there.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const trace of client.traces.query()) {
     *   // ...
     * }
     * ```
     */
    query(params, options) {
        const { Accept, ...body } = params;
        return this._client.getAPIList('/api/v2/traces/query', (pagination_1.ItemsCursorPostPagination), {
            body,
            method: 'post',
            ...options,
            headers: (0, headers_1.buildHeaders)([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
}
exports.Traces = Traces;
//# sourceMappingURL=traces.js.map