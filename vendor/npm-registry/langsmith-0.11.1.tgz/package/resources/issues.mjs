// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { OffsetPaginationIssues } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class Issues extends APIResource {
    /**
     * **Beta:** This endpoint is in active development and may change without notice.
     *
     * Returns one issue for the authenticated tenant.
     */
    retrieve(id, query = {}, options) {
        return this._client.get(path `/api/v1/platform/issues/${id}`, { query, ...options });
    }
    /**
     * **Beta:** This endpoint is in active development and may change without notice.
     *
     * Returns issues for the authenticated tenant, optionally filtered by session,
     * status, severity, tag, linked trace, or last modified time.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v1/platform/issues', (OffsetPaginationIssues), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=issues.mjs.map