// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Info extends APIResource {
    /**
     * Returns information about the current LangSmith deployment: version, instance
     * feature flags, batch-ingest limits, and max SDK versions. Unauthenticated by
     * default; set FF_INFO_ENDPOINT_AUTH_REQUIRED=true to require auth.
     */
    list(options) {
        return this._client.get('/api/v1/info', options);
    }
}
//# sourceMappingURL=info.mjs.map