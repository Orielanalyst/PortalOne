// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Registries extends APIResource {
    /**
     * Create a sandbox registry for pulling private images.
     */
    create(body, options) {
        return this._client.post('/api/v2/sandboxes/registries', { body, ...options });
    }
    /**
     * Get a sandbox registry by name.
     */
    retrieve(name, options) {
        return this._client.get(path `/api/v2/sandboxes/registries/${name}`, options);
    }
    /**
     * Update a sandbox registry's name and/or credentials.
     */
    update(name, body, options) {
        return this._client.patch(path `/api/v2/sandboxes/registries/${name}`, { body, ...options });
    }
    /**
     * List sandbox registries for pulling private images. Page with page_size and
     * cursor, replaying next_cursor until it is null. Results are ordered newest
     * first, with stable ordering for equal creation times. Keep filters unchanged
     * between pages. Requests without page_size or cursor retain the legacy default of
     * 50 results. Cursor requests default to 20 results, with a maximum of 100.
     */
    list(query = {}, options) {
        return this._client.get('/api/v2/sandboxes/registries', { query, ...options });
    }
    /**
     * Delete a sandbox registry by name.
     */
    delete(name, options) {
        return this._client.delete(path `/api/v2/sandboxes/registries/${name}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=registries.mjs.map