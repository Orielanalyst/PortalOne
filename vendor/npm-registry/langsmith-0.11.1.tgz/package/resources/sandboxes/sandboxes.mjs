// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as BoxesAPI from "./boxes.mjs";
import { Boxes, } from "./boxes.mjs";
import * as RegistriesAPI from "./registries.mjs";
import { Registries, } from "./registries.mjs";
import * as SnapshotsAPI from "./snapshots.mjs";
import { Snapshots, } from "./snapshots.mjs";
import { ItemsCursorGetPagination, } from "../../core/pagination.mjs";
export class Sandboxes extends APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "boxes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new BoxesAPI.Boxes(this._client)
        });
        Object.defineProperty(this, "registries", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new RegistriesAPI.Registries(this._client)
        });
        Object.defineProperty(this, "snapshots", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new SnapshotsAPI.Snapshots(this._client)
        });
    }
    /**
     * Returns priced usage per sandbox or snapshot and UTC hour in the half-open
     * requested interval. LCU uses the recorded compute amount for sandboxes;
     * snapshots have zero LCU. LSU allocates the recorded workspace storage amount
     * proportionally to attributed bytes, including checkpoints on their sandbox and
     * snapshots as separate resources. Resource filters preserve each resource's
     * share. Rate changes do not reprice recorded amounts. An access-filtered page can
     * have no items and a non-null next_cursor; continue until next_cursor is null.
     */
    listUsageCosts(query, options) {
        return this._client.getAPIList('/api/v2/sandboxes/usage/costs', (ItemsCursorGetPagination), { query, ...options });
    }
}
Sandboxes.Boxes = Boxes;
Sandboxes.Registries = Registries;
Sandboxes.Snapshots = Snapshots;
//# sourceMappingURL=sandboxes.mjs.map