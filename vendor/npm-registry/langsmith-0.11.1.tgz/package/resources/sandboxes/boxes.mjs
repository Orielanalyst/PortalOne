// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { ItemsCursorGetPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Boxes extends APIResource {
    /**
     * Create a new sandbox from a snapshot. Provide at most one of `snapshot_id` or
     * `snapshot_name`; if neither is provided, the server uses the default snapshot.
     * `snapshot_name` accepts a Docker-style `name` or `name:tag` reference (a bare
     * name resolves to `name:latest`).
     */
    create(body, options) {
        return this._client.post('/api/v2/sandboxes/boxes', { body, ...options });
    }
    /**
     * Retrieve a sandbox by name. Stale provisioning sandboxes are auto-failed.
     */
    retrieve(name, options) {
        return this._client.get(path `/api/v2/sandboxes/boxes/${name}`, options);
    }
    /**
     * Update a sandbox's display name, retention, resources, tags, or proxy
     * configuration. The name must be unique within the tenant. Proxy configuration
     * sent to a sandbox that is not running is stored and applied when it next starts.
     */
    update(name, body, options) {
        return this._client.patch(path `/api/v2/sandboxes/boxes/${name}`, { body, ...options });
    }
    /**
     * List sandboxes for the authenticated tenant, with optional filtering, sorting,
     * and pagination. Page with page_size and cursor: replay the response's
     * next_cursor until it comes back null, which is the only signal that no pages
     * remain. Cursors are opaque and only valid on this endpoint; do not parse or
     * construct one.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v2/sandboxes/boxes', (ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Delete a sandbox by name or UUID. Tears down the sandbox runtime and removes the
     * DB record.
     */
    delete(name, options) {
        return this._client.delete(path `/api/v2/sandboxes/boxes/${name}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Create a snapshot by capturing the current state of a sandbox or promoting an
     * existing checkpoint.
     */
    createSnapshot(name, body, options) {
        return this._client.post(path `/api/v2/sandboxes/boxes/${name}/snapshot`, { body, ...options });
    }
    /**
     * Removes the sharing grant for one port, or for every port when port is omitted.
     * A LangSmith login URL stops working immediately. A previously minted service
     * token is not revoked and stays valid until it expires, but no new one can be
     * issued from the removed grant.
     */
    deleteServiceURL(name, params = {}, options) {
        const { port } = params ?? {};
        return this._client.delete(path `/api/v2/sandboxes/boxes/${name}/service-urls`, {
            query: { port },
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Generate a tokenized link that downloads a single file from a sandbox with no
     * further authentication. This mints a token rather than creating an addressable
     * resource, so it returns 200 with no Location header. The token pins the sandbox,
     * the file path, the response content type and disposition, and the sandbox flags,
     * so a link cannot be repointed at another file or served under a weaker policy.
     * The file is always served with a Content-Security-Policy: a sandbox directive,
     * plus a default-src holding every fetch to the file's own download host and a set
     * of pre-approved third-party origins. csp_sandbox_flags may loosen the sandbox
     * with allow-downloads, allow-forms, allow-modals, allow-orientation-lock,
     * allow-pointer-lock, allow-popups, allow-presentation, allow-same-origin,
     * allow-scripts, or allow-top-navigation-by-user-activation. Every file is served
     * from its own host, derived from the sandbox and the path, so allow-same-origin
     * gives a page localStorage and IndexedDB that no other file can read, and
     * re-minting a link for the same file keeps them. csp_sandbox set to false drops
     * the sandbox directive altogether, and csp_sandbox_flags must then be omitted.
     * csp_source_bundles selects the third-party origins: cdnjs, google-fonts,
     * jsdelivr, and unpkg are all allowed when the field is omitted, 'none' holds the
     * file to its own host, and 'any' sends no default-src at all. Links never expire
     * unless expires_in_seconds is set. The link is served from the sandbox service
     * domain, not the API host.
     */
    generateDownloadURL(name, body, options) {
        return this._client.post(path `/api/v2/sandboxes/boxes/${name}/download-url`, { body, ...options });
    }
    /**
     * Create a short-lived JWT for accessing an HTTP service running on a specific
     * port inside a sandbox. Returns a browser_url (sets auth cookie via redirect), a
     * service_url (for use with the X-Langsmith-Sandbox-Service-Token header), the raw
     * token, and its expiry. Set access=restricted|workspace to instead enable durable
     * LangSmith login (no token; users authenticate with their normal LangSmith
     * session), or access=off to disable it. With LangSmith login, embed_origins names
     * the pages that may show the URL in an iframe; a viewer signs in from inside the
     * frame through a LangSmith popup. LangSmith login and token access are mutually
     * exclusive per service URL.
     */
    generateServiceURL(name, body, options) {
        return this._client.post(path `/api/v2/sandboxes/boxes/${name}/service-url`, { body, ...options });
    }
    /**
     * Retrieve the lightweight status of a sandbox for polling.
     */
    getStatus(name, options) {
        return this._client.get(path `/api/v2/sandboxes/boxes/${name}/status`, options);
    }
    /**
     * Returns one entry per port the sandbox is currently reachable on, so a caller
     * can see what is shared before turning it off. Expired token grants are omitted.
     * Cursors are opaque and only valid on this endpoint; do not parse or construct
     * one.
     */
    listServiceURLs(name, query = {}, options) {
        return this._client.getAPIList(path `/api/v2/sandboxes/boxes/${name}/service-urls`, (ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Start a stopped or failed sandbox. This endpoint is not idempotent.
     */
    start(name, options) {
        return this._client.post(path `/api/v2/sandboxes/boxes/${name}/start`, options);
    }
    /**
     * Stop a ready sandbox. This endpoint is not idempotent; the filesystem is
     * preserved for later restart.
     */
    stop(name, options) {
        return this._client.post(path `/api/v2/sandboxes/boxes/${name}/stop`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=boxes.mjs.map