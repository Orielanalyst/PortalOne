// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { ItemsCursorGetPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Snapshots extends APIResource {
    /**
     * Create a snapshot from a Docker image (async build). Names use lowercase
     * registry-style components separated by slashes, up to 255 characters. The
     * system/ namespace is read-only.
     */
    create(body, options) {
        return this._client.post('/api/v2/sandboxes/snapshots', { body, ...options });
    }
    /**
     * Get a sandbox snapshot by ID or a registry-style reference, including
     * system/default:latest. URL-encode references containing slashes. A bare name
     * means name:latest, falling back to the newest ready untagged snapshot of that
     * name. To list the tags under a name, use
     * /api/v2/sandboxes/snapshots-by-name/{name}.
     */
    retrieve(snapshotID, options) {
        return this._client.get(path `/api/v2/sandboxes/snapshots/${snapshotID}`, options);
    }
    /**
     * List workspace and published system snapshots, with optional filtering, sorting,
     * and pagination. Page with page_size and cursor: replay the response's
     * next_cursor until it comes back null, which is the only signal that no pages
     * remain. Cursors are opaque and only valid on this endpoint; do not parse or
     * construct one.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/api/v2/sandboxes/snapshots', (ItemsCursorGetPagination), { query, ...options });
    }
    /**
     * Delete a snapshot by ID or by a Docker-style name[:tag] reference. The
     * underlying storage is reclaimed asynchronously.
     */
    delete(snapshotID, options) {
        return this._client.delete(path `/api/v2/sandboxes/snapshots/${snapshotID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Get a snapshot name and every tag under it, with the snapshot each tag resolves
     * to. To fetch one snapshot, use /api/v2/sandboxes/snapshots/{snapshot_id}.
     */
    retrieveByName(name, options) {
        return this._client.get(path `/api/v2/sandboxes/snapshots-by-name/${name}`, options);
    }
}
//# sourceMappingURL=snapshots.mjs.map