"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sandboxes = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const BoxesAPI = tslib_1.__importStar(require("./boxes.js"));
const boxes_1 = require("./boxes.js");
const RegistriesAPI = tslib_1.__importStar(require("./registries.js"));
const registries_1 = require("./registries.js");
const SnapshotsAPI = tslib_1.__importStar(require("./snapshots.js"));
const snapshots_1 = require("./snapshots.js");
const pagination_1 = require("../../core/pagination.js");
class Sandboxes extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "boxes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new BoxesAPI.Boxes(this._client)
        });
        Object.defineProperty(this, "registries", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new RegistriesAPI.Registries(this._client)
        });
        Object.defineProperty(this, "snapshots", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new SnapshotsAPI.Snapshots(this._client)
        });
    }
    /**
     * Returns priced usage per sandbox or snapshot and UTC hour in the half-open
     * requested interval. LCU uses the recorded compute amount for sandboxes;
     * snapshots have zero LCU. LSU allocates the recorded workspace storage amount
     * proportionally to attributed bytes, including checkpoints on their sandbox and
     * snapshots as separate resources. Resource filters preserve each resource's
     * share. Rate changes do not reprice recorded amounts. An access-filtered page can
     * have no items and a non-null next_cursor; continue until next_cursor is null.
     */
    listUsageCosts(query, options) {
        return this._client.getAPIList('/api/v2/sandboxes/usage/costs', (pagination_1.ItemsCursorGetPagination), { query, ...options });
    }
}
exports.Sandboxes = Sandboxes;
Sandboxes.Boxes = boxes_1.Boxes;
Sandboxes.Registries = registries_1.Registries;
Sandboxes.Snapshots = snapshots_1.Snapshots;
//# sourceMappingURL=sandboxes.js.map