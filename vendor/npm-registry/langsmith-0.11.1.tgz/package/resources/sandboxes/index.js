"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Snapshots = exports.Sandboxes = exports.Registries = exports.Boxes = void 0;
var boxes_1 = require("./boxes.js");
Object.defineProperty(exports, "Boxes", { enumerable: true, get: function () { return boxes_1.Boxes; } });
var registries_1 = require("./registries.js");
Object.defineProperty(exports, "Registries", { enumerable: true, get: function () { return registries_1.Registries; } });
var sandboxes_1 = require("./sandboxes.js");
Object.defineProperty(exports, "Sandboxes", { enumerable: true, get: function () { return sandboxes_1.Sandboxes; } });
var snapshots_1 = require("./snapshots.js");
Object.defineProperty(exports, "Snapshots", { enumerable: true, get: function () { return snapshots_1.Snapshots; } });
//# sourceMappingURL=index.js.map