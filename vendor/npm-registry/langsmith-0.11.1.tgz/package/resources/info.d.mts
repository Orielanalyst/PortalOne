import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Info extends APIResource {
    /**
     * Returns information about the current LangSmith deployment: version, instance
     * feature flags, batch-ingest limits, and max SDK versions. Unauthenticated by
     * default; set FF_INFO_ENDPOINT_AUTH_REQUIRED=true to require auth.
     */
    list(options?: RequestOptions): APIPromise<InfoListResponse>;
}
export interface InfoListResponse {
    batch_ingest_config?: InfoListResponse.BatchIngestConfig;
    /**
     * BillingInstallationID is the persistent per-installation identity for
     * self-hosted deployments.
     */
    billing_installation_id?: string;
    customer_info?: InfoListResponse.CustomerInfo;
    engine_github_web_base_url?: string;
    git_sha?: string;
    instance_flags?: {
        [key: string]: unknown;
    };
    license_expiration_time?: string;
    sdk_versions?: InfoListResponse.SDKVersions;
    version?: string;
}
export declare namespace InfoListResponse {
    interface BatchIngestConfig {
        scale_down_nempty_trigger?: number;
        scale_up_nthreads_limit?: number;
        scale_up_qsize_trigger?: number;
        size_limit?: number;
        size_limit_bytes?: number;
        use_multipart_endpoint?: boolean;
    }
    interface CustomerInfo {
        customer_id?: string;
        customer_name?: string;
    }
    interface SDKVersions {
        max_go_sdk_version?: string;
        max_java_sdk_version?: string;
        max_js_sdk_version?: string;
        max_python_sdk_version?: string;
    }
}
export declare namespace Info {
    export { type InfoListResponse as InfoListResponse };
}
//# sourceMappingURL=info.d.mts.map