import { APIResource } from "../../core/resource.mjs";
import * as RunsAPI from "./runs.mjs";
import { RunQueryParams, RunQueryResponse, RunRetrieveParams, Runs } from "./runs.mjs";
export declare class Public extends APIResource {
    runs: RunsAPI.Runs;
}
export declare namespace Public {
    export { Runs as Runs, type RunQueryResponse as RunQueryResponse, type RunRetrieveParams as RunRetrieveParams, type RunQueryParams as RunQueryParams, };
}
//# sourceMappingURL=public.d.mts.map