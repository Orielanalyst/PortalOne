// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Runs extends APIResource {
    /**
     * Returns one run within the trace identified by the share token. The request
     * supplies only the run ID and that run's exact start_time coordinate.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const run = await client.public.runs.retrieve(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *   {
     *     share_token: '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     *     selects: ['string'],
     *     start_time: '2019-12-27T18:11:19.117Z',
     *   },
     * );
     * ```
     */
    retrieve(runID, params, options) {
        const { share_token, Accept, ...query } = params;
        return this._client.get(path `/api/v2/public/${share_token}/run/${runID}`, {
            query,
            ...options,
            headers: buildHeaders([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
    /**
     * Returns all runs within the trace identified by the share token. The share token
     * supplies the tenant, project, and trace scope.
     *
     * Self-hosted deployments require LangSmith `v0.16` or later.
     *
     * @example
     * ```ts
     * const response = await client.public.runs.query(
     *   '182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e',
     * );
     * ```
     */
    query(shareToken, params, options) {
        const { Accept, ...body } = params;
        return this._client.post(path `/api/v2/public/${shareToken}/runs/query`, {
            body,
            ...options,
            headers: buildHeaders([{ ...(Accept != null ? { Accept: Accept } : undefined) }, options?.headers]),
        });
    }
}
//# sourceMappingURL=runs.mjs.map