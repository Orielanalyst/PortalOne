"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Public = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const RunsAPI = tslib_1.__importStar(require("./runs.js"));
const runs_1 = require("./runs.js");
class Public extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "runs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new RunsAPI.Runs(this._client)
        });
    }
}
exports.Public = Public;
Public.Runs = runs_1.Runs;
//# sourceMappingURL=public.js.map