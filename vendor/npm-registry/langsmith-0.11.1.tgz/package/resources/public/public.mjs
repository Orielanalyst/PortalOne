// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as RunsAPI from "./runs.mjs";
import { Runs } from "./runs.mjs";
export class Public extends APIResource {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "runs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new RunsAPI.Runs(this._client)
        });
    }
}
Public.Runs = Runs;
//# sourceMappingURL=public.mjs.map