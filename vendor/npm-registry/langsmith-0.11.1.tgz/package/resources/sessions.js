"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sessions = void 0;
const resource_1 = require("../core/resource.js");
class Sessions extends resource_1.APIResource {
    /**
     * **Beta:** This endpoint is in active development and may change without notice.
     * Returns the tracing project (session) an address names. An address is an AGENT
     * (`id` and `environment`), an EXPERIMENT (`id`), or an EVALUATOR (no `id`:
     * evaluator traces share one project per workspace). Send `kind` and `environment`
     * in upper case, as listed; they are matched case-insensitively, while the Agent
     * `id` is case-sensitive. An address that does not exist, or whose project you
     * cannot read, is a 404. Pass the returned `session_id` to any endpoint that takes
     * a project (session) ID. This is not supported on a BYOC data plane yet, and is a
     * 501 there.
     */
    resolve(query, options) {
        return this._client.get('/api/v1/sessions/resolutions', { query, ...options });
    }
}
exports.Sessions = Sessions;
//# sourceMappingURL=sessions.js.map