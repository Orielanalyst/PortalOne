"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Info = void 0;
const resource_1 = require("../core/resource.js");
class Info extends resource_1.APIResource {
    /**
     * Returns information about the current LangSmith deployment: version, instance
     * feature flags, batch-ingest limits, and max SDK versions. Unauthenticated by
     * default; set FF_INFO_ENDPOINT_AUTH_REQUIRED=true to require auth.
     */
    list(options) {
        return this._client.get('/api/v1/info', options);
    }
}
exports.Info = Info;
//# sourceMappingURL=info.js.map