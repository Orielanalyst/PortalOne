"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductFeedback = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class ProductFeedback extends resource_1.APIResource {
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     *
     * Submits concise product feedback with optional non-sensitive client details.
     */
    create(params, options) {
        const { 'Idempotency-Key': idempotencyKey, ...body } = params;
        return this._client.post('/api/v1/platform/product-feedbacks', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(idempotencyKey != null ? { 'Idempotency-Key': idempotencyKey } : undefined) },
                options?.headers,
            ]),
        });
    }
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/api/v1/platform/product-feedbacks/${id}`, options);
    }
}
exports.ProductFeedback = ProductFeedback;
//# sourceMappingURL=product-feedback.js.map