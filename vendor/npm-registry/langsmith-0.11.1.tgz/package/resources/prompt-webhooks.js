"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptWebhooks = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class PromptWebhooks extends resource_1.APIResource {
    /**
     * Create a new prompt webhook.
     *
     * LangSmith sends a POST request to the webhook URL for each event listed in
     * triggers on the prompts it matches. A workspace can have one prompt webhook
     * unless its limit was raised; creating one past the limit returns 400.
     */
    create(body, options) {
        return this._client.post('/api/v1/prompt-webhooks', { body, ...options });
    }
    /**
     * Get a specific prompt webhook.
     */
    retrieve(webhookID, options) {
        return this._client.get((0, path_1.path) `/api/v1/prompt-webhooks/${webhookID}`, options);
    }
    /**
     * Update a specific prompt webhook.
     *
     * Omitted fields keep their current values; list fields and headers that are set
     * replace the stored values.
     */
    update(webhookID, body, options) {
        return this._client.patch((0, path_1.path) `/api/v1/prompt-webhooks/${webhookID}`, { body, ...options });
    }
    /**
     * List all prompt webhooks for the current tenant.
     */
    list(options) {
        return this._client.get('/api/v1/prompt-webhooks', options);
    }
    /**
     * Delete a specific prompt webhook.
     */
    delete(webhookID, options) {
        return this._client.delete((0, path_1.path) `/api/v1/prompt-webhooks/${webhookID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Test a specific prompt webhook.
     *
     * Sends the sample payload to the webhook configuration in the request body
     * without saving it, but only if the webhook's triggers include the payload's
     * event and its prompt filters match the payload's prompt. Otherwise nothing is
     * sent. Fails if the destination does not accept the payload.
     */
    test(body, options) {
        return this._client.post('/api/v1/prompt-webhooks/test', { body, ...options });
    }
}
exports.PromptWebhooks = PromptWebhooks;
//# sourceMappingURL=prompt-webhooks.js.map