// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class ProductFeedback extends APIResource {
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     *
     * Submits concise product feedback with optional non-sensitive client details.
     */
    create(params, options) {
        const { 'Idempotency-Key': idempotencyKey, ...body } = params;
        return this._client.post('/api/v1/platform/product-feedbacks', {
            body,
            ...options,
            headers: buildHeaders([
                { ...(idempotencyKey != null ? { 'Idempotency-Key': idempotencyKey } : undefined) },
                options?.headers,
            ]),
        });
    }
    /**
     * **Alpha:** This endpoint is in active development and may change without notice.
     */
    retrieve(id, options) {
        return this._client.get(path `/api/v1/platform/product-feedbacks/${id}`, options);
    }
}
//# sourceMappingURL=product-feedback.mjs.map