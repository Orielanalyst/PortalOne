// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import * as qs from "../qs/stringify.mjs";
export function stringifyQuery(query) {
    return qs.stringify(query, { arrayFormat: 'repeat' });
}
//# sourceMappingURL=query.mjs.map