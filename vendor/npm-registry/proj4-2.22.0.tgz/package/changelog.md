## Change log

- 2.22.0: Support latlong, latlon and lonlat as aliases of longlat; preserve z when enforceAxis=true for omerc and robin; apply false easting in ortho projections
- 2.21.0: Add support for `+lon_wrap`
- 2.20.9: Add Eckert VI (eck6) projection; add geotiff@3 support (geotiff is now an optional peer dependency); fix unknown datum handling to match PROJ behavior; fix gamma without alpha in omerc; fix ob_tran lam offset and +over handling; fix enforceAxis for z and arbitrary axis orders

- 2.20.8: Add back TypeScript type definitions to the npm package (accidentally removed in 2.20.7)

- 2.20.7: GitHub releases now contain a separate dist.zip file, so users don't have to find the dist folder in the downloaded source code any more; removed bower.json and component.json; trusted OIDC publishing for the npm package; added security policy; vitest instead of mocha for the tests; removed grunt; renamed main branch to main

- 2.20.0: Include WGS84 UTM zones 1-60 North/South and WGS84 UPS North/South; add support for `+over`; add general oblique transformation; make projjson work with `proj4.defs(code, projjson)`

- 2.19.0: TypeScript type definitions are now included. When upgrading, please uninstall the `@types/proj4` package.

- 2.2.1: Documentation fixes and added proj4.defs('name') as an alias for proj4.defs['name'];

- 2.1.4: dist folder is added back in after accidentally omitting it in 2.1.1

- 2.1.3: skipped as issues with the dist folder are ironed out.

- 2.1.2: added sensible defaults for false eastings/northings

- 2.1.1: tweaks to how we publish it, fixes related to errors with the OSGB36 and Reseau National Belge 1972 datums, we took the first steps towards depreciating the proj4.Point class.

- 2.1.0: targeted builds for projections are now supported, and internally projection creation is more modular.

- 2.0.3: mgrs is broken out into it's own module loaded via npm.

- 2.0.2: module common is broken up into a collection of smaller modules. 

- 2.0.1: fix typo in eqc projection.

- 2.0.0: we start the change log.