```diff
===================================================================
--- plan-v1.md	published draft
+++ plan-v2.md	revised after evaluation
@@ -4,19 +4,21 @@
 ## Intervention areas
 The acquired OpenStreetMap/HOT extract (community-map-v1) covers bounds [10.1, 5.9, 10.3, 6.1] EPSG:4326 and contains 5,111 road-related features, 16 named settlement candidates and 7 health features; coverage, current road passability and facility operation are unverified [E5393b16f3d]. Sixteen settlement reference points are mapped; none locates an incident or defines an intervention boundary [Eb75c454ba2][Eba738e5db8][E1f47d2f678][Ecce97a3c99][E11e20e8c10][E1a349f1f49][E10e0b9a622][Ed7211b43f1][E0f04c086ff][E40a61a6afc][E29fcfd4f45][E00b963decd][E77e75cc459][E717752d0c4][E0c4bc0ad3a][E1e28383352]. Duplicate settlement names exist: Balewa appears at two coordinate pairs requiring local clarification [E11e20e8c10][E0f04c086ff]. The intervention_zones polygon layer is intentionally empty; no surveyed intervention boundaries or approved delivery zones were supplied [Eed74370b77]. Unknown requested areas outside the acquired corridor are coverage gaps.
 
 ## Actions
-| # | Action | Accountable | Trigger / Gate | Evidence |
-|---|--------|-------------|----------------|----------|
-| 1 | Verify facility capacity, operating hours, services and current availability for each of the seven mapped health features | Health-sector lead | Direct confirmation from facility or health authority | [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9][Eed74370b77] |
-| 2 | Ground-truth road passability for each corridor segment and confirm any blockages with coordinates | Logistics/engineering lead | Field assessment or trusted local report with usable coordinates | [E5393b16f3d][Eed74370b77] |
-| 3 | Resolve duplicate Balewa coordinates through local clarification | Community liaison | Local stakeholder input confirming single authoritative location | [E11e20e8c10][E0f04c086ff][Eed74370b77] |
-| 4 | Define surveyed intervention boundaries and approved delivery zones | Operations lead | Authorized operator decision and stakeholder agreement | [Eed74370b77] |
-| 5 | Confirm current warehouse stock and fleet availability (existing observations expired 2026-10-24 11:00 UTC) | Logistics lead | Current warehouse/fleet confirmation | [Eee9e4d9449][Eed74370b77] |
-| 6 | Obtain cargo quantities, beneficiary requirements, dispatch resources, deadlines and authorized operator decision | Operations lead | Operator authorization | [Eed74370b77] |
-| 7 | Treat all demonstration reports as unverified; do not use for operational decisions | All leads | Evidence review gate | [E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][Eed74370b77] |
-| 8 | Produce GIS pack with facility inventory, road network, settlement references, empty intervention_zones layer and gap annotations | GIS analyst | Operations lead confirms Actions 1–4 complete | [E5393b16f3d][Eed74370b77] |
+| # | Action | Proposed accountable entity | Trigger / Gate | Depends on | Unlocks | Evidence |
+|---|--------|-----------------------------|----------------|------------|---------|----------|
+| 1 | Verify facility capacity, operating hours, services and current availability for each of the seven mapped health features | Mezam Health District (Ministry of Health) | Direct confirmation from facility or health authority | — | Operational dispatch; GIS pack facility attributes | [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9][Eed74370b77] |
+| 2 | Ground-truth road passability for each corridor segment and confirm any blockages with coordinates | Bamenda Logistics Cluster (NGO logistics unit) | Field assessment or trusted local report with usable coordinates | 3 | Operational dispatch; GIS pack road status layer | [E5393b16f3d][Eed74370b77] |
+| 3 | Resolve duplicate Balewa coordinates through local clarification | Bambili Council / Community Health Workers | Local stakeholder input confirming single authoritative location | — | Action 2; Action 4 | [E11e20e8c10][E0f04c086ff][Eed74370b77] |
+| 4 | Define surveyed intervention boundaries and approved delivery zones | Operations lead (authorized operator) | Authorized operator decision and stakeholder agreement | 2, 3 | Operational dispatch; GIS pack intervention_zones layer | [Eed74370b77] |
+| 5 | Confirm current warehouse stock and fleet availability (existing observations expired 2026-10-24 11:00 UTC) | Bamenda Logistics Cluster (NGO logistics unit) | Current warehouse/fleet confirmation | — | Operational dispatch | [Eee9e4d9449][Eed74370b77] |
+| 6 | Obtain cargo quantities, beneficiary requirements, dispatch resources, deadlines and authorized operator decision | Operations lead (authorized operator) | Operator authorization | 4, 5 | Operational dispatch | [Eed74370b77] |
+| 7 | Treat all demonstration reports as unverified; do not use for operational decisions | All leads | Evidence review gate | — | — | [E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][Eed74370b77] |
+| 8 | Produce evidence-only GIS pack (facility inventory, road network, settlement references, empty intervention_zones layer, gap annotations) | GIS analyst | Immediate — no field verification required | — | Evaluator review and revisions | [E5393b16f3d][E577d71ac5c][Eed74370b77] |
 
+**Sequencing summary**: Critical path — 3 → 2 → 4 → 6. Parallel tracks — 1 and 5 can run concurrently with the critical path. Action 8 is decoupled and deliverable now for evaluator review; operational dispatch remains HOLD until Actions 1–6 are satisfied [Eed74370b77].
+
 ## Access and health facilities
 Seven health features are mapped, all with coordinate basis noted as not a verified entrance and no capacity, operating hours, services or current availability provided [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9][Eed74370b77]:
 - School's Hospital (hospital) [E551163564a]
 - Doctor Azang (doctor) [Ec0c6314836]
@@ -38,6 +40,12 @@
 - Duplicate Balewa coordinates require local clarification before use [E11e20e8c10][E0f04c086ff][Eed74370b77].
 
 ## Decision gates
 - Operational dispatch remains HOLD until Actions 1–6 are satisfied and an authorized operator decision is recorded [Eed74370b77].
-- GIS pack delivery is gated on completion of Actions 1–4 [Eed74370b77].
-- Any use of demonstration reports for operational decisions is prohibited [E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][Eed74370b77].
\ No newline at end of file
+- Evidence-only GIS pack (Action 8) is deliverable immediately for evaluator review; operational-use GIS pack requires Actions 1–4 complete [E577d71ac5c][Eed74370b77].
+- Any use of demonstration reports for operational decisions is prohibited [E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][Eed74370b77].
+
+## What changed and why
+- **Decoupled GIS pack export from field verification gates**: Action 8 now produces an evidence-only GIS pack immediately for evaluator review, per the objective [E577d71ac5c]; operational dispatch stays HOLD until Actions 1–6 are satisfied [Eed74370b77].
+- **Added explicit sequencing and dependencies**: Critical path 3 → 2 → 4 → 6 with parallel tracks (1, 5) shown in the action table; each action lists what it unlocks (GIS pack vs. operational dispatch) [Eed74370b77].
+- **Proposed concrete role candidates**: Generic labels replaced with proposed responsible entities (Mezam Health District, Bamenda Logistics Cluster, Bambili Council/Community Health Workers, Operations lead as authorized operator) as assignments to be confirmed [Eed74370b77].
+- **Updated Action 5 evidence citation**: Corrected to reference the independently queryable community/resource context showing expired synthetic stock/fleet [Eee9e4d9449][Eed74370b77].
\ No newline at end of file

```