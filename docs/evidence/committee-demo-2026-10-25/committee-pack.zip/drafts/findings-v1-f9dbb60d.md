# Mission scope

Map hospitals and health facilities, assess road access and capacity evidence, and produce a committee proposal and GIS pack for evaluator review and revisions for the Bamenda–Bambili corridor. The acquired OpenStreetMap/HOT extract (community-map-v1) covers the corridor bounds [10.1, 5.9, 10.3, 6.1] EPSG:4326 and contains 5,111 road-related features, 16 named settlement candidates and 7 health features; coverage, current road passability and facility operation are unverified [E5393b16f3d]. The intervention_zones polygon layer is intentionally empty; no surveyed intervention boundaries or approved delivery zones were supplied [Eed74370b77]. Unknown requested areas outside the acquired corridor are coverage gaps. The mission objective is documented under request E577d71ac5c [E577d71ac5c].

# Findings

Seven health features are mapped in the corridor, all with coordinate basis noted as not a verified entrance and no capacity, operating hours, services or current availability provided [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9]:
- School's Hospital (hospital) [E551163564a]
- Doctor Azang (doctor) [Ec0c6314836]
- St Louis Clinic (clinic) [E20c1a4200b]
- Unnamed health feature way/685675038 (yes) [Ee76d9d3147]
- Bamenda Regional Hospital (hospital) [E3c858731c6]
- Mezam Clinic (dentist) [E4359e3d965]
- Bamenda Polyclinic (hospital) [E62810be1d9]

Sixteen settlement reference points are mapped; none locates an incident or defines an intervention boundary [Eb75c454ba2][Eba738e5db8][E1f47d2f678][Ecce97a3c99][E11e20e8c10][E1a349f1f49][E10e0b9a622][Ed7211b43f1][E0f04c086ff][E40a61a6afc][E29fcfd4f45][E00b963decd][E77e75cc459][E717752d0c4][E0c4bc0ad3a][E1e28383352]. Duplicate settlement names exist: Balewa appears at two coordinate pairs requiring local clarification [E11e20e8c10][E0f04c086ff].

Current road passability, exact incident locations and affected road segments are unverified; no road is certified open or impassable by this map [E5393b16f3d][Eed74370b77]. The reported road blockage for Bambili has no usable incident coordinate and is excluded from the blockage point layer [E0c4ddd1199][Eed74370b77].

# Evidence limits

Mapped health features are not an exhaustive hospital inventory; capacity, operating hours, services and current availability require direct confirmation from facility or health authority [Eed74370b77]. Current road passability, exact incident locations and affected road segments are unverified; no road is certified open or impassable [E5393b16f3d][Eed74370b77]. No surveyed intervention boundaries or approved delivery zones were supplied; the intervention_zones polygon layer is intentionally empty [Eed74370b77]. Cargo quantities, beneficiary requirements, dispatch resources, deadlines and an authorized operator decision must be supplied before executable delivery planning [Eed74370b77]. Demonstration reports cannot corroborate an actual incident [E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][Eed74370b77]. Registered stock and fleet are synthetic; their values do not establish actual NGO resources [Eed74370b77]. Registered resource observations have expired and require a current warehouse/fleet confirmation [Eed74370b77]. Duplicate settlement names retain multiple coordinate candidates; local clarification is required [Eed74370b77]. A reported road blockage for Bambili has no usable incident coordinate; it is excluded from the blockage point layer [Eed74370b77].

# Questions for planning

- Has direct confirmation been obtained for facility capacity, operating hours, services and current availability at each of the seven mapped health features [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9]?
- Has road passability been ground-truthed for each corridor segment, and have any blockages been confirmed with usable coordinates [E5393b16f3d][Eed74370b77]?
- Has the duplicate Balewa coordinate been resolved through local stakeholder clarification to a single authoritative location [E11e20e8c10][E0f04c086ff][Eed74370b77]?
- Have surveyed intervention boundaries and approved delivery zones been defined with authorized operator decision and stakeholder agreement [Eed74370b77]?
- Has current warehouse stock and fleet availability been confirmed, noting that existing observations expired 2026-10-24 11:00 UTC [Eed74370b77]?
- Have cargo quantities, beneficiary requirements, dispatch resources, deadlines and an authorized operator decision been obtained to enable executable delivery planning [Eed74370b77]?