RELIEFINTEL COMMITTEE DRAFT - OPERATIONAL HOLD
Evidence revision: eb7369156c103285e5e04c819b799b7432d04d300551783f9754b111ec32c340
Captured: 2026-10-25T15:59:17.698Z
Open mission.qgz in QGIS. Source CRS: EPSG:4326; map display: EPSG:32632.
GeoJSON equivalents and per-layer QML styles are included. Capacity and operating status are unverified.
Empty blockage/intervention-zone layers are evidence gaps, not an all-clear. Facility polygon reference points are source boundary vertices, not verified entrances.
© OpenStreetMap contributors; distributed through Humanitarian OpenStreetMap Team / HDX | ODbL 1.0
