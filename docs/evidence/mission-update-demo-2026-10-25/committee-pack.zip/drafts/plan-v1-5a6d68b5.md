## Objective
Map hospitals and health facilities, assess road access and capacity evidence, and produce a committee proposal and GIS pack for evaluator review and revisions for the Bamenda–Bambili corridor [E577d71ac5c].

## Intervention areas
The acquired OpenStreetMap/HOT extract (community-map-v1) covers the corridor with 5,111 road-related features, 16 named settlement candidates and 7 health features; coverage, current road passability and facility operation are unverified [E5393b16f3d]. The intervention_zones polygon layer is intentionally empty; no surveyed intervention boundaries or approved delivery zones were supplied [E5807d651bc]. Unknown requested areas outside the acquired corridor are coverage gaps [E5393b16f3d].

## Actions
| # | Action | Accountable | Trigger / Gate | Evidence |
|---|--------|-------------|----------------|----------|
| 1 | Verify facility capacity, operating hours, services and current availability for each of the seven mapped health features via health-district contact and direct facility contact; document non-response as a gap | Health-sector lead | Direct confirmation from facility or health authority per feature | [E551163564a][Ec0c6314836][E20c1a4200b][Ee76d9d3147][E3c858731c6][E4359e3d965][E62810be1d9][E5807d651bc] |
| 2a | Ground-truth road passability for corridor segments Bamenda–Bambui and Bambui–Bambili; confirm any blockages with usable coordinates | Logistics/engineering lead | Field assessment or trusted local report with usable coordinates per segment | [E5393b16f3d][E5807d651bc][E0c4ddd1199][E1b7c32ac23][E8ddfaf4364][E83be860d48] |
| 2b | Obtain segment reporting deadline from the operator | Logistics/engineering lead | Operator-supplied deadline | [E5807d651bc] |
| 3 | Resolve duplicate Balewa coordinates through local clarification at both coordinate pairs; return a single attributed coordinate | Community liaison | Local stakeholder input delivering a single coordinate pair with source attribution | [E11e20e8c10][E0f04c086ff][E5807d651bc] |
| 4 | Define surveyed intervention boundaries and approved delivery zones | Operations lead | Authorized operator decision and stakeholder agreement | [E5807d651bc] |
| 5 | Confirm current warehouse stock and fleet for Bambili against the expired observation baseline (2026-10-24 11:00 UTC) | Logistics lead | Current warehouse/fleet confirmation from operator | [E56fbe33deb][E5807d651bc] |
| 6a | Obtain operator-supplied cargo quantities, beneficiary requirements and dispatch resources | Operations lead | Operator authorization and documented decision | [E5807d651bc] |
| 6b | Obtain operator-supplied mission/reporting deadline | Operations lead | Operator authorization and documented decision | [E5807d651bc] |

## Access and health facilities
Seven health features are mapped (e.g., School's Hospital, Bamenda Regional Hospital); all lack capacity, operating hours, services or current availability [E551163564a]–[E62810be1d9][E5807d651bc]. Sixteen settlement reference points are mapped; none locates an incident or defines an intervention boundary [Eb75c454ba2]–[E1e28383352]. Duplicate settlement name Balewa appears at two coordinate pairs requiring local clarification [E11e20e8c10][E0f04c086ff]. Current road passability, exact incident locations and affected road segments are unverified; no road is certified open or impassable by this map [E5393b16f3d][E5807d651bc]. Three reported access observations have submitted coordinate references and are retained in the reported-access layer; one other lacks usable coordinates and is excluded [E5807d651bc]. Retained points remain unverified and may be demonstrations [E5807d651bc][E47b134eaf2][E06e9de224d][E21d75f8985]. Demonstration reports cannot corroborate an actual incident [E5807d651bc][E06e9de224d][E21d75f8985][Ec5461d631e][E0c4ddd1199][E1b7c32ac23][E8ddfaf4364][E83be860d48]. Registered stock and fleet are synthetic; their values do not establish actual NGO resources, and registered resource observations have expired (2026-10-24 11:00 UTC) requiring current warehouse/fleet confirmation [E56fbe33deb][E5807d651bc].

## Risks
- Facility capacity and operating status remain unconfirmed; mapped health features are not an exhaustive hospital inventory [E5807d651bc].
- Current road passability, exact incident locations and affected road segments are unverified; no road is certified open or impassable by this map [E5807d651bc].
- No surveyed intervention boundaries or approved delivery zones were supplied; the intervention_zones polygon layer is intentionally empty [E5807d651bc].
- Cargo quantities, beneficiary requirements, dispatch resources, deadlines and an authorized operator decision must be supplied before executable delivery planning [E5807d651bc].
- Demonstration reports cannot corroborate an actual incident [E5807d651bc].
- Registered stock and fleet are synthetic; their values do not establish actual NGO resources, and registered resource observations have expired and require a current warehouse/fleet confirmation [E5807d651bc].
- Duplicate settlement names retain multiple coordinate candidates; local clarification is required [E5807d651bc].
- Reported road blockage has no usable incident coordinate; it is excluded from the blockage point layer [E83be860d48].

## Decision gates
Operational dispatch remains HOLD. The following inputs must be resolved before any executable delivery planning:
- Current warehouse stock and fleet confirmation for Bambili (Action 5) [E56fbe33deb][E5807d651bc].
- Operator-supplied cargo quantities, beneficiary requirements, dispatch resources and mission/reporting deadline (Actions 6a, 6b) [E5807d651bc].
- Authorized operator decision and surveyed intervention boundaries (Action 4) [E5807d651bc].
- Verified facility capacity and operating status (Action 1) [E551163564a]–[E62810be1d9][E5807d651bc].
- Ground-truthed road passability with usable coordinates for blockages (Action 2a) [E5393b16f3d][E5807d651bc][E0c4ddd1199][E1b7c32ac23][E8ddfaf4364][E83be860d48].
- Resolved Balewa duplicate coordinates (Action 3) [E11e20e8c10][E0f04c086ff][E5807d651bc].