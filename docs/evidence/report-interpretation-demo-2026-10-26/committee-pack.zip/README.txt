RELIEFINTEL COMMITTEE DRAFT - OPERATIONAL HOLD
Evidence revision: 9801188968c682f007f0c273c149e2e27f8dbdd801fadf47cfa08e523d2832ce
Captured: 2026-10-25T23:32:10.956Z
Open mission.qgz in QGIS. Source CRS: EPSG:4326; map display: EPSG:32632.
GeoJSON equivalents and per-layer QML styles are included. Capacity and operating status are unverified.
Empty blockage/intervention-zone layers are evidence gaps, not an all-clear. Facility polygon reference points are source boundary vertices, not verified entrances.
© OpenStreetMap contributors; distributed through Humanitarian OpenStreetMap Team / HDX | ODbL 1.0
