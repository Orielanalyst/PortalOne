RELIEFINTEL COMMITTEE DRAFT - OPERATIONAL HOLD
Evidence revision: 3ec0df7a1183b78c457b83d7089cad1e2e9c08f3b57806682715860701a017b0
Captured: 2026-10-26T05:32:07.221Z
Open mission.qgz in QGIS. Source CRS: EPSG:4326; map display: EPSG:32632.
GeoJSON equivalents and per-layer QML styles are included. Capacity and operating status are unverified.
Empty blockage/intervention-zone layers are evidence gaps, not an all-clear. Facility polygon reference points are source boundary vertices, not verified entrances.
© OpenStreetMap contributors; distributed through Humanitarian OpenStreetMap Team / HDX | ODbL 1.0
